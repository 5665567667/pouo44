package loliland.graphics.util;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.joml.Vector2f;
import org.joml.Vector2fc;
import org.joml.Vector4f;
import org.joml.Vector4fc;

@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u0019\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u000b\u001a\u00020\f¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000e¨\u0006\u000f"},
   d2 = {"Lloliland/graphics/util/TextShadow;", "", "offset", "Lorg/joml/Vector2fc;", "color", "Lorg/joml/Vector4fc;", "(Lorg/joml/Vector2fc;Lorg/joml/Vector4fc;)V", "getColor", "()Lorg/joml/Vector4fc;", "getOffset", "()Lorg/joml/Vector2fc;", "originalColor", "Lorg/joml/Vector4f;", "getOriginalColor", "()Lorg/joml/Vector4f;", "loligraphics-1.7.10"}
)
public final class TextShadow {
   @NotNull
   private final Vector2fc offset;
   @NotNull
   private final Vector4fc color;
   @NotNull
   private final Vector4f originalColor;

   public TextShadow(@NotNull Vector2fc offset, @NotNull Vector4fc color) {
      Intrinsics.checkNotNullParameter(offset, "offset");
      Intrinsics.checkNotNullParameter(color, "color");
      super();
      this.offset = offset;
      this.color = color;
      this.originalColor = new Vector4f();
   }

   // $FF: synthetic method
   public TextShadow(Vector2fc var1, Vector4fc var2, int var3, DefaultConstructorMarker var4) {
      if ((var3 & 1) != 0) {
         var1 = (Vector2fc)(new Vector2f(1.0F, 1.0F));
      }

      if ((var3 & 2) != 0) {
         var2 = (Vector4fc)(new Vector4f(0.0F, 0.0F, 0.0F, 0.55F));
      }

      this(var1, var2);
   }

   @NotNull
   public final Vector2fc getOffset() {
      return this.offset;
   }

   @NotNull
   public final Vector4fc getColor() {
      return this.color;
   }

   @NotNull
   public final Vector4f getOriginalColor() {
      return this.originalColor;
   }

   public TextShadow() {
      this((Vector2fc)null, (Vector4fc)null, 3, (DefaultConstructorMarker)null);
   }
}

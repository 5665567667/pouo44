package loliland.graphics.tool;

import java.awt.Insets;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.io.CloseableKt;
import kotlin.io.TextStreamsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.MutablePropertyReference0;
import kotlin.jvm.internal.MutablePropertyReference0Impl;
import kotlin.jvm.internal.Reflection;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.properties.Delegates;
import kotlin.properties.ReadWriteProperty;
import kotlin.ranges.RangesKt;
import kotlin.reflect.KProperty;
import kotlin.sequences.Sequence;
import kotlin.text.Charsets;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import loliland.graphics.renderer.font.FontGlyph;
import org.jetbrains.annotations.NotNull;
import org.joml.Vector2f;

@Metadata(
   mv = {1, 9, 0},
   k = 2,
   xi = 48,
   d1 = {"\u00000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\u001a\u0016\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005\u001a\u0019\u0010\u0006\u001a\u00020\u00012\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\t0\b¢\u0006\u0002\u0010\n¨\u0006\u000b²\u0006\n\u0010\f\u001a\u00020\rX\u008a\u008e\u0002²\u0006\n\u0010\u000e\u001a\u00020\u000fX\u008a\u008e\u0002²\u0006\n\u0010\u0010\u001a\u00020\u000fX\u008a\u008e\u0002²\u0006\n\u0010\u0011\u001a\u00020\rX\u008a\u008e\u0002"},
   d2 = {"convertFont", "", "input", "Ljava/io/InputStream;", "output", "Ljava/io/OutputStream;", "main", "args", "", "", "([Ljava/lang/String;)V", "loligraphics-1.7.10", "fontSize", "", "bold", "", "italic", "lineHeight"}
)
@SourceDebugExtension({"SMAP\nFontConverter.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FontConverter.kt\nloliland/graphics/tool/FontConverterKt\n+ 2 _Sequences.kt\nkotlin/sequences/SequencesKt___SequencesKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,101:1\n1313#2:102\n1314#2:116\n1549#3:103\n1620#3,3:104\n766#3:107\n857#3,2:108\n1179#3,2:110\n1253#3,4:112\n1855#3,2:117\n*S KotlinDebug\n*F\n+ 1 FontConverter.kt\nloliland/graphics/tool/FontConverterKt\n*L\n44#1:102\n44#1:116\n45#1:103\n45#1:104,3\n45#1:107\n45#1:108,2\n46#1:110,2\n46#1:112,4\n90#1:117,2\n*E\n"})
public final class FontConverterKt {
   // $FF: synthetic field
   static final KProperty<Object>[] $$delegatedProperties;

   public static final void main(@NotNull String[] args) {
      Intrinsics.checkNotNullParameter(args, "args");
      Files.walk(Paths.get(args[0])).filter(FontConverterKt::main$lambda$0).forEach(FontConverterKt::main$lambda$1);
   }

   public static final void convertFont(@NotNull InputStream input, @NotNull OutputStream output) {
      Intrinsics.checkNotNullParameter(input, "input");
      Intrinsics.checkNotNullParameter(output, "output");
      Charset var3 = Charsets.UTF_8;
      Reader var4 = (Reader)(new InputStreamReader(input, var3));
      int var5 = 8192;
      Closeable var2 = (Closeable)(var4 instanceof BufferedReader ? (BufferedReader)var4 : new BufferedReader(var4, var5));
      Throwable var46 = null;

      try {
         BufferedReader reader = (BufferedReader)var2;
         var5 = 0;
         ReadWriteProperty fontSize$delegate = Delegates.INSTANCE.notNull();
         ReadWriteProperty bold$delegate = Delegates.INSTANCE.notNull();
         ReadWriteProperty italic$delegate = Delegates.INSTANCE.notNull();
         Object padding = null;
         ReadWriteProperty lineHeight$delegate = Delegates.INSTANCE.notNull();
         Object imageSize = null;
         Map glyphs = (Map)(new LinkedHashMap());
         Sequence $this$forEach$iv = TextStreamsKt.lineSequence(reader);
         int $i$f$forEach = 0;

         for(Object element$iv : $this$forEach$iv) {
            String line = (String)element$iv;
            int var18 = 0;
            CharSequence it = (CharSequence)line;
            Regex var20 = new Regex("\\s+");
            int capacity$iv = 0;
            Iterable $this$filter$iv = (Iterable)var20.split(it, capacity$iv);
            int $i$f$map = 0;
            Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$filter$iv, 10)));
            int $i$f$mapTo = 0;

            for(Object item$iv$iv : $this$filter$iv) {
               String it = (String)item$iv$iv;
               int var28 = 0;
               CharSequence var10000 = (CharSequence)it;
               char[] var29 = new char[]{'='};
               destination$iv$iv.add(StringsKt.split$default(var10000, var29, false, 0, 6, (Object)null));
            }

            $this$filter$iv = (Iterable)((List)destination$iv$iv);
            $i$f$map = 0;
            destination$iv$iv = (Collection)(new ArrayList());
            $i$f$mapTo = 0;

            for(Object element$iv$iv : $this$filter$iv) {
               List it = (List)element$iv$iv;
               int var84 = 0;
               if (it.size() == 2) {
                  destination$iv$iv.add(element$iv$iv);
               }
            }

            $this$filter$iv = (Iterable)((List)destination$iv$iv);
            $i$f$map = 0;
            capacity$iv = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault($this$filter$iv, 10)), 16);
            Map destination$iv$iv = (Map)(new LinkedHashMap(capacity$iv));
            int $i$f$associateTo = 0;

            for(Object element$iv$iv : $this$filter$iv) {
               List it = (List)element$iv$iv;
               int var30 = 0;
               Pair var86 = TuplesKt.to(it.get(0), it.get(1));
               destination$iv$iv.put(var86.getFirst(), var86.getSecond());
            }

            if (StringsKt.startsWith$default(line, "info ", false, 2, (Object)null)) {
               Object var10001 = destination$iv$iv.get("size");
               Intrinsics.checkNotNull(var10001);
               convertFont$lambda$15$lambda$3(fontSize$delegate, Integer.parseInt((String)var10001));
               var10001 = destination$iv$iv.get("bold");
               Intrinsics.checkNotNull(var10001);
               convertFont$lambda$15$lambda$5(bold$delegate, Integer.parseInt((String)var10001) != 0);
               var10001 = destination$iv$iv.get("italic");
               Intrinsics.checkNotNull(var10001);
               convertFont$lambda$15$lambda$7(italic$delegate, Integer.parseInt((String)var10001) != 0);
               Object var87 = destination$iv$iv.get("padding");
               Intrinsics.checkNotNull(var87);
               CharSequence var88 = (CharSequence)var87;
               char[] it = new char[]{','};
               List it = StringsKt.split$default(var88, it, false, 0, 6, (Object)null);
               capacity$iv = 0;
               padding = new Insets(Integer.parseInt((String)it.get(0)), Integer.parseInt((String)it.get(1)), Integer.parseInt((String)it.get(2)), Integer.parseInt((String)it.get(3)));
            } else if (StringsKt.startsWith$default(line, "common ", false, 2, (Object)null)) {
               Object var93 = destination$iv$iv.get("lineHeight");
               Intrinsics.checkNotNull(var93);
               convertFont$lambda$15$lambda$9(lineHeight$delegate, Integer.parseInt((String)var93));
               Object var10002 = destination$iv$iv.get("scaleW");
               Intrinsics.checkNotNull(var10002);
               float var94 = Float.parseFloat((String)var10002);
               Object var10003 = destination$iv$iv.get("scaleH");
               Intrinsics.checkNotNull(var10003);
               imageSize = new Vector2f(var94, Float.parseFloat((String)var10003));
            } else if (StringsKt.startsWith$default(line, "char ", false, 2, (Object)null)) {
               Object var89 = destination$iv$iv.get("id");
               Intrinsics.checkNotNull(var89);
               int code = Integer.parseInt((String)var89);
               Integer var74 = code;
               FontGlyph var95 = new FontGlyph;
               Object var10007 = destination$iv$iv.get("x");
               Intrinsics.checkNotNull(var10007);
               float var97 = Float.parseFloat((String)var10007);
               Object var10008 = destination$iv$iv.get("y");
               Intrinsics.checkNotNull(var10008);
               Vector2f var10005 = new Vector2f(var97, Float.parseFloat((String)var10008));
               var10008 = destination$iv$iv.get("width");
               Intrinsics.checkNotNull(var10008);
               float var100 = Float.parseFloat((String)var10008);
               Object var10009 = destination$iv$iv.get("height");
               Intrinsics.checkNotNull(var10009);
               Vector2f var10006 = new Vector2f(var100, Float.parseFloat((String)var10009));
               var10009 = destination$iv$iv.get("xoffset");
               Intrinsics.checkNotNull(var10009);
               float var104 = Float.parseFloat((String)var10009);
               Object var10010 = destination$iv$iv.get("yoffset");
               Intrinsics.checkNotNull(var10010);
               Vector2f var98 = new Vector2f(var104, Float.parseFloat((String)var10010));
               Object var101 = destination$iv$iv.get("xadvance");
               Intrinsics.checkNotNull(var101);
               int var102 = Integer.parseInt((String)var101);
               Object var105 = padding;
               if (padding == null) {
                  Intrinsics.throwUninitializedPropertyAccessException("padding");
                  var105 = null;
               }

               var95.<init>(code, var10005, var10006, var98, var102 - (((Insets)var105).left + ((Insets)padding).right));
               glyphs.put(var74, var95);
            }
         }

         FontMetadata var90 = new FontMetadata;
         Object var96 = imageSize;
         if (imageSize == null) {
            Intrinsics.throwUninitializedPropertyAccessException("imageSize");
            var96 = null;
         }

         var90.<init>((Vector2f)var96, convertFont$lambda$15$lambda$2(fontSize$delegate), convertFont$lambda$15$lambda$8(lineHeight$delegate), convertFont$lambda$15$lambda$4(bold$delegate), convertFont$lambda$15$lambda$6(italic$delegate), glyphs);
         var50 = var90;
      } catch (Throwable var43) {
         var46 = var43;
         throw var43;
      } finally {
         CloseableKt.closeFinally(var2, var46);
      }

      FontMetadata metadata = var50;
      short var47 = 8192;
      var2 = (Closeable)(new DataOutputStream((OutputStream)(output instanceof BufferedOutputStream ? (BufferedOutputStream)output : new BufferedOutputStream(output, var47))));
      Throwable var48 = null;

      try {
         DataOutputStream writer = (DataOutputStream)var2;
         var5 = 0;
         Vector2f $this$forEach$iv = metadata.getImageSize();
         int var58 = 0;
         writer.writeFloat($this$forEach$iv.x);
         writer.writeFloat($this$forEach$iv.y);
         writer.writeInt(metadata.getFontSize());
         writer.writeInt(metadata.getLineHeight());
         writer.writeBoolean(metadata.getBold());
         writer.writeBoolean(metadata.getItalic());
         writer.writeInt(metadata.getGlyphs().size());
         Iterable $this$forEach$iv = (Iterable)metadata.getGlyphs().values();
         int $i$f$forEach = 0;

         for(Object element$iv : $this$forEach$iv) {
            FontGlyph it = (FontGlyph)element$iv;
            int var62 = 0;
            writer.writeInt(it.getCode());
            writer.writeFloat(it.getPosition().x);
            writer.writeFloat(it.getPosition().y);
            writer.writeFloat(it.getSize().x);
            writer.writeFloat(it.getSize().y);
            writer.writeFloat(it.getOffset().x);
            writer.writeFloat(it.getOffset().y);
            writer.writeInt(it.getAdvance());
         }

         Unit var52 = Unit.INSTANCE;
      } catch (Throwable var41) {
         var48 = var41;
         throw var41;
      } finally {
         CloseableKt.closeFinally(var2, var48);
      }

   }

   private static final boolean main$lambda$0(Function1 $tmp0, Object p0) {
      Intrinsics.checkNotNullParameter($tmp0, "$tmp0");
      return (Boolean)$tmp0.invoke(p0);
   }

   private static final void main$lambda$1(Function1 $tmp0, Object p0) {
      Intrinsics.checkNotNullParameter($tmp0, "$tmp0");
      $tmp0.invoke(p0);
   }

   private static final int convertFont$lambda$15$lambda$2(ReadWriteProperty<Object, Integer> $fontSize$delegate) {
      return ((Number)$fontSize$delegate.getValue((Object)null, $$delegatedProperties[0])).intValue();
   }

   private static final void convertFont$lambda$15$lambda$3(ReadWriteProperty<Object, Integer> $fontSize$delegate, int value) {
      $fontSize$delegate.setValue((Object)null, $$delegatedProperties[0], value);
   }

   private static final boolean convertFont$lambda$15$lambda$4(ReadWriteProperty<Object, Boolean> $bold$delegate) {
      return (Boolean)$bold$delegate.getValue((Object)null, $$delegatedProperties[1]);
   }

   private static final void convertFont$lambda$15$lambda$5(ReadWriteProperty<Object, Boolean> $bold$delegate, boolean value) {
      $bold$delegate.setValue((Object)null, $$delegatedProperties[1], value);
   }

   private static final boolean convertFont$lambda$15$lambda$6(ReadWriteProperty<Object, Boolean> $italic$delegate) {
      return (Boolean)$italic$delegate.getValue((Object)null, $$delegatedProperties[2]);
   }

   private static final void convertFont$lambda$15$lambda$7(ReadWriteProperty<Object, Boolean> $italic$delegate, boolean value) {
      $italic$delegate.setValue((Object)null, $$delegatedProperties[2], value);
   }

   private static final int convertFont$lambda$15$lambda$8(ReadWriteProperty<Object, Integer> $lineHeight$delegate) {
      return ((Number)$lineHeight$delegate.getValue((Object)null, $$delegatedProperties[3])).intValue();
   }

   private static final void convertFont$lambda$15$lambda$9(ReadWriteProperty<Object, Integer> $lineHeight$delegate, int value) {
      $lineHeight$delegate.setValue((Object)null, $$delegatedProperties[3], value);
   }

   static {
      KProperty[] var0 = new KProperty[]{Reflection.mutableProperty0((MutablePropertyReference0)(new MutablePropertyReference0Impl(FontConverterKt.class, "fontSize", "<v#0>", 1))), Reflection.mutableProperty0((MutablePropertyReference0)(new MutablePropertyReference0Impl(FontConverterKt.class, "bold", "<v#1>", 1))), Reflection.mutableProperty0((MutablePropertyReference0)(new MutablePropertyReference0Impl(FontConverterKt.class, "italic", "<v#2>", 1))), Reflection.mutableProperty0((MutablePropertyReference0)(new MutablePropertyReference0Impl(FontConverterKt.class, "lineHeight", "<v#3>", 1)))};
      $$delegatedProperties = var0;
   }
}

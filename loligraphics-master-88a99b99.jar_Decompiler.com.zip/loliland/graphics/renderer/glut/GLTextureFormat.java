package loliland.graphics.renderer.glut;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public enum GLTextureFormat {
   Alpha,
   Intensity,
   LuminanceAlpha,
   RGB565,
   RGBA4444,
   RGB888,
   RGBA8888;

   public int getGLFormat() {
      switch (this) {
         case Alpha:
         case Intensity:
            return 6406;
         case LuminanceAlpha:
            return 6410;
         case RGB565:
         case RGB888:
            return 6407;
         case RGBA4444:
         case RGBA8888:
            return 6408;
         default:
            throw new UnsupportedOperationException("Unknown format: " + this);
      }
   }

   public int getGLType() {
      switch (this) {
         case Alpha:
         case Intensity:
         case LuminanceAlpha:
         case RGB888:
         case RGBA8888:
            return 5121;
         case RGB565:
            return 33635;
         case RGBA4444:
            return 32819;
         default:
            throw new UnsupportedOperationException("Unknown format: " + this);
      }
   }
}

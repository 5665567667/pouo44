package loliland.graphics.renderer;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.HashMap;
import java.util.Map;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000J\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0003\u0018\u0000 (2\u00020\u0001:\u0001(B\u000f\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u000e\u0010\u0012\u001a\u00020\u00072\u0006\u0010\u0013\u001a\u00020\u0003J\u0006\u0010\u0014\u001a\u00020\u0015J&\u0010\u0016\u001a\u00020\u00072\u0006\u0010\u0012\u001a\u00020\u00032\u0006\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u00032\u0006\u0010\u001a\u001a\u00020\u0003J\u0016\u0010\u001b\u001a\u00020\u00072\u0006\u0010\u001c\u001a\u00020\u001d2\u0006\u0010\u001a\u001a\u00020\u0003J&\u0010\u001e\u001a\u00020\u00072\u0006\u0010\u0012\u001a\u00020\u00032\u0006\u0010\u0017\u001a\u00020\u001d2\u0006\u0010\u0019\u001a\u00020\u00032\u0006\u0010\u001a\u001a\u00020\u0003J\u0006\u0010\u001f\u001a\u00020 J\u0013\u0010!\u001a\u00020 2\b\u0010\"\u001a\u0004\u0018\u00010\u0001H\u0096\u0002J\b\u0010#\u001a\u00020\u0003H\u0016J\u0006\u0010$\u001a\u00020 J\b\u0010%\u001a\u00020&H\u0016J\u0006\u0010'\u001a\u00020\u0015R*\u0010\u0005\u001a\u001e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00070\u0006j\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0007`\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u001e\u0010\n\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\u0003@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\"\u0010\r\u001a\u0004\u0018\u00010\u00072\b\u0010\t\u001a\u0004\u0018\u00010\u0007@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u001e\u0010\u0010\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\u0003@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\f¨\u0006)"},
   d2 = {"Lloliland/graphics/renderer/VAO;", "", "vaoId", "", "(I)V", "attributes", "Ljava/util/HashMap;", "Lloliland/graphics/renderer/VBO;", "Lkotlin/collections/HashMap;", "<set-?>", "id", "getId", "()I", "indexAttribute", "getIndexAttribute", "()Lloliland/graphics/renderer/VBO;", "indexCount", "getIndexCount", "attribute", "index", "bind", "", "createAttribute", "data", "Ljava/nio/FloatBuffer;", "attrSize", "drawMode", "createIndexBuffer", "indices", "Ljava/nio/IntBuffer;", "createIntAttribute", "dispose", "", "equals", "other", "hashCode", "isEmpty", "toString", "", "unbind", "Companion", "loligraphics-1.7.10"}
)
@SourceDebugExtension({"SMAP\nVAO.kt\nKotlin\n*S Kotlin\n*F\n+ 1 VAO.kt\nloliland/graphics/renderer/VAO\n+ 2 _Maps.kt\nkotlin/collections/MapsKt___MapsKt\n*L\n1#1,107:1\n215#2,2:108\n*S KotlinDebug\n*F\n+ 1 VAO.kt\nloliland/graphics/renderer/VAO\n*L\n85#1:108,2\n*E\n"})
public final class VAO {
   @NotNull
   public static final Companion Companion = new Companion((DefaultConstructorMarker)null);
   private int id;
   @NotNull
   private final HashMap<Integer, VBO> attributes;
   @Nullable
   private VBO indexAttribute;
   private int indexCount;
   @NotNull
   private static final VAO EMPTY = new VAO(-1);

   public VAO(int vaoId) {
      this.id = vaoId;
      this.attributes = new HashMap();
      this.indexCount = -1;
   }

   // $FF: synthetic method
   public VAO(int var1, int var2, DefaultConstructorMarker var3) {
      if ((var2 & 1) != 0) {
         var1 = GLCompatible.genVertexArrays();
      }

      this(var1);
   }

   public final int getId() {
      return this.id;
   }

   @Nullable
   public final VBO getIndexAttribute() {
      return this.indexAttribute;
   }

   public final int getIndexCount() {
      return this.indexCount;
   }

   @NotNull
   public final VBO createIndexBuffer(@NotNull IntBuffer indices, int drawMode) {
      Intrinsics.checkNotNullParameter(indices, "indices");
      if (this.indexAttribute != null) {
         int var3 = 0;
         String $this$createIndexBuffer_u24lambda_u241 = "Index buffer already created for this VAO";
         throw new IllegalStateException($this$createIndexBuffer_u24lambda_u241.toString());
      } else {
         VBO $this$createIndexBuffer_u24lambda_u241 = new VBO(GLCompatible.genBuffers(), GLCompatible.GL_ELEMENT_ARRAY_BUFFER, drawMode);
         int var5 = 0;
         $this$createIndexBuffer_u24lambda_u241.bind();
         $this$createIndexBuffer_u24lambda_u241.bufferData(indices);
         this.indexCount = indices.capacity();
         this.indexAttribute = $this$createIndexBuffer_u24lambda_u241;
         return $this$createIndexBuffer_u24lambda_u241;
      }
   }

   @NotNull
   public final VBO createAttribute(int attribute, @NotNull FloatBuffer data, int attrSize, int drawMode) {
      Intrinsics.checkNotNullParameter(data, "data");
      Integer var5 = attribute;
      if (((Map)this.attributes).containsKey(var5)) {
         int $this$createAttribute_u24lambda_u243 = 0;
         String var10 = "Attribute " + attribute + " already created for this VAO";
         throw new IllegalStateException(var10.toString());
      } else {
         VBO $this$createAttribute_u24lambda_u243 = new VBO(GLCompatible.genBuffers(), GLCompatible.GL_ARRAY_BUFFER, drawMode);
         int var7 = 0;
         $this$createAttribute_u24lambda_u243.bind();
         $this$createAttribute_u24lambda_u243.bufferData(data);
         GLCompatible.enableVertexAttribArray(attribute);
         GLCompatible.vertexAttribPointer(attribute, attrSize, 5126, false, attrSize * 4, 0L);
         Integer var8 = attribute;
         ((Map)this.attributes).put(var8, $this$createAttribute_u24lambda_u243);
         $this$createAttribute_u24lambda_u243.unbind();
         return $this$createAttribute_u24lambda_u243;
      }
   }

   @NotNull
   public final VBO createIntAttribute(int attribute, @NotNull IntBuffer data, int attrSize, int drawMode) {
      Intrinsics.checkNotNullParameter(data, "data");
      Integer var5 = attribute;
      if (((Map)this.attributes).containsKey(var5)) {
         int $this$createIntAttribute_u24lambda_u245 = 0;
         String var10 = "Attribute " + attribute + " already created for this VAO";
         throw new IllegalStateException(var10.toString());
      } else {
         VBO $this$createIntAttribute_u24lambda_u245 = new VBO(GLCompatible.genBuffers(), GLCompatible.GL_ARRAY_BUFFER, drawMode);
         int var7 = 0;
         $this$createIntAttribute_u24lambda_u245.bind();
         $this$createIntAttribute_u24lambda_u245.bufferData(data);
         GLCompatible.enableVertexAttribArray(attribute);
         GLCompatible.vertexAttribPointer(attribute, attrSize, 5124, false, attrSize * 4, 0L);
         Integer var8 = attribute;
         ((Map)this.attributes).put(var8, $this$createIntAttribute_u24lambda_u245);
         $this$createIntAttribute_u24lambda_u245.unbind();
         return $this$createIntAttribute_u24lambda_u245;
      }
   }

   @NotNull
   public final VBO attribute(int index) {
      Object var10000 = this.attributes.get(index);
      Intrinsics.checkNotNull(var10000);
      return (VBO)var10000;
   }

   public final void bind() {
      GLCompatible.bindVertexArray(this.id);
   }

   public final void unbind() {
      GLCompatible.bindVertexArray(0);
   }

   public final boolean dispose() {
      if (this.id != -1) {
         return false;
      } else {
         Map $this$forEach$iv = (Map)this.attributes;
         int $i$f$forEach = 0;

         for(Map.Entry element$iv : $this$forEach$iv.entrySet()) {
            int var6 = 0;
            VBO vbo = (VBO)element$iv.getValue();
            vbo.dispose();
         }

         VBO var10000 = this.indexAttribute;
         if (var10000 != null) {
            var10000.dispose();
         }

         this.indexCount = -1;
         this.unbind();
         GLCompatible.deleteVertexArrays(this.id);
         this.id = -1;
         return true;
      }
   }

   public final boolean isEmpty() {
      return this.id == -1;
   }

   public boolean equals(@Nullable Object other) {
      if (this == other) {
         return true;
      } else if (!(other instanceof VBO)) {
         return false;
      } else {
         return this.id == ((VBO)other).getId();
      }
   }

   public int hashCode() {
      return this.id;
   }

   @NotNull
   public String toString() {
      return "VAO(id=" + this.id + ", vbos=" + this.attributes + ", indexVbo=" + this.indexAttribute + ", indexCount=" + this.indexCount + ')';
   }

   public VAO() {
      this(0, 1, (DefaultConstructorMarker)null);
   }

   @Metadata(
      mv = {1, 9, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u0011\u0010\u0003\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006¨\u0006\u0007"},
      d2 = {"Lloliland/graphics/renderer/VAO$Companion;", "", "()V", "EMPTY", "Lloliland/graphics/renderer/VAO;", "getEMPTY", "()Lloliland/graphics/renderer/VAO;", "loligraphics-1.7.10"}
   )
   public static final class Companion {
      private Companion() {
      }

      @NotNull
      public final VAO getEMPTY() {
         return VAO.EMPTY;
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}

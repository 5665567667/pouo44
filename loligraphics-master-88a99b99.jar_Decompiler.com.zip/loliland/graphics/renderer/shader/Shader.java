package loliland.graphics.renderer.shader;

import java.lang.reflect.Constructor;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import loliland.graphics.renderer.GLCompatible;
import loliland.graphics.renderer.shader.uniform.Uniform;
import net.minecraft.util.ResourceLocation;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010#\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0007\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\"\n\u0002\b\u0002\n\u0002\u0010%\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u000b\b&\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u000e\u0010 \u001a\u00020!2\u0006\u0010\"\u001a\u00020\u0007J+\u0010#\u001a\u0002H$\"\b\b\u0000\u0010$*\u00020\u001d2\f\u0010%\u001a\b\u0012\u0004\u0012\u0002H$0&2\u0006\u0010'\u001a\u00020\u0007¢\u0006\u0002\u0010(J\"\u0010#\u001a\u0002H$\"\n\b\u0000\u0010$\u0018\u0001*\u00020\u001d2\u0006\u0010'\u001a\u00020\u0007H\u0086\b¢\u0006\u0002\u0010)J\b\u0010*\u001a\u00020\u000bH\u0016J\u0013\u0010+\u001a\u00020\u000b2\b\u0010,\u001a\u0004\u0018\u00010\u0001H\u0096\u0002J\b\u0010-\u001a\u00020\u0013H\u0016J\b\u0010.\u001a\u00020!H\u0016J\b\u0010/\u001a\u00020!H\u0016J\b\u00100\u001a\u00020\u0007H\u0016R\u0017\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u001a\u0010\n\u001a\u00020\u000bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\r\"\u0004\b\u000e\u0010\u000fR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u001a\u0010\u0012\u001a\u00020\u0013X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0014\u0010\u0015\"\u0004\b\u0016\u0010\u0017R\u0018\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00130\u0019X¦\u0004¢\u0006\u0006\u001a\u0004\b\u001a\u0010\tR\u001d\u0010\u001b\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u001d0\u001c¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u001f¨\u00061"},
   d2 = {"Lloliland/graphics/renderer/shader/Shader;", "", "location", "Lnet/minecraft/util/ResourceLocation;", "(Lnet/minecraft/util/ResourceLocation;)V", "attributes", "", "", "getAttributes", "()Ljava/util/Set;", "loaded", "", "getLoaded", "()Z", "setLoaded", "(Z)V", "getLocation", "()Lnet/minecraft/util/ResourceLocation;", "programId", "", "getProgramId", "()I", "setProgramId", "(I)V", "types", "", "getTypes", "uniforms", "", "Lloliland/graphics/renderer/shader/uniform/Uniform;", "getUniforms", "()Ljava/util/Map;", "createAttribute", "", "attribute", "createUniform", "T", "type", "Ljava/lang/Class;", "name", "(Ljava/lang/Class;Ljava/lang/String;)Lloliland/graphics/renderer/shader/uniform/Uniform;", "(Ljava/lang/String;)Lloliland/graphics/renderer/shader/uniform/Uniform;", "dispose", "equals", "other", "hashCode", "onBind", "onUnbind", "toString", "loligraphics-1.7.10"}
)
@SourceDebugExtension({"SMAP\nShader.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Shader.kt\nloliland/graphics/renderer/shader/Shader\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,59:1\n1#2:60\n1855#3,2:61\n*S KotlinDebug\n*F\n+ 1 Shader.kt\nloliland/graphics/renderer/shader/Shader\n*L\n46#1:61,2\n*E\n"})
public abstract class Shader {
   @NotNull
   private final ResourceLocation location;
   private int programId;
   private boolean loaded;
   @NotNull
   private final Set<String> attributes;
   @NotNull
   private final Map<String, Uniform> uniforms;

   public Shader(@NotNull ResourceLocation location) {
      Intrinsics.checkNotNullParameter(location, "location");
      super();
      this.location = location;
      this.programId = -1;
      this.attributes = (Set)(new LinkedHashSet());
      this.uniforms = (Map)(new LinkedHashMap());
   }

   @NotNull
   public final ResourceLocation getLocation() {
      return this.location;
   }

   public final int getProgramId() {
      return this.programId;
   }

   public final void setProgramId(int var1) {
      this.programId = var1;
   }

   public final boolean getLoaded() {
      return this.loaded;
   }

   public final void setLoaded(boolean var1) {
      this.loaded = var1;
   }

   @NotNull
   public abstract Set<Integer> getTypes();

   @NotNull
   public final Set<String> getAttributes() {
      return this.attributes;
   }

   @NotNull
   public final Map<String, Uniform> getUniforms() {
      return this.uniforms;
   }

   @NotNull
   public final <T extends Uniform> T createUniform(@NotNull Class<T> type, @NotNull String name) {
      Intrinsics.checkNotNullParameter(type, "type");
      Intrinsics.checkNotNullParameter(name, "name");
      if (this.uniforms.containsKey(name)) {
         int var8 = 0;
         String var9 = "Duplicate uniform in shader: " + name;
         throw new IllegalArgumentException(var9.toString());
      } else {
         Class[] var3 = new Class[]{Shader.class, String.class};
         Constructor var10000 = type.getConstructor(var3);
         Object var6 = new Object[]{this, name};
         var6 = var10000.newInstance((Object[])var6);
         Uniform $this$createUniform_u24lambda_u241 = (Uniform)var6;
         int var5 = 0;
         Map var10 = this.uniforms;
         Intrinsics.checkNotNull($this$createUniform_u24lambda_u241);
         var10.put(name, $this$createUniform_u24lambda_u241);
         Intrinsics.checkNotNullExpressionValue(var6, "apply(...)");
         return (T)(var6);
      }
   }

   // $FF: synthetic method
   public final <T extends Uniform> T createUniform(String name) {
      Intrinsics.checkNotNullParameter(name, "name");
      int $i$f$createUniform = 0;
      Intrinsics.reifiedOperationMarker(4, "T");
      return (T)this.createUniform(Uniform.class, name);
   }

   public final void createAttribute(@NotNull String attribute) {
      Intrinsics.checkNotNullParameter(attribute, "attribute");
      if (this.attributes.contains(attribute)) {
         int var2 = 0;
         String var3 = "Duplicate attribute in shader: " + attribute;
         throw new IllegalArgumentException(var3.toString());
      } else {
         this.attributes.add(attribute);
      }
   }

   public void onBind() {
   }

   public void onUnbind() {
   }

   public boolean dispose() {
      this.loaded = false;
      if (this.programId <= 0) {
         return false;
      } else {
         Iterable $this$forEach$iv = (Iterable)this.uniforms.values();
         int $i$f$forEach = 0;

         for(Object element$iv : $this$forEach$iv) {
            Uniform it = (Uniform)element$iv;
            int var6 = 0;
            it.dispose();
         }

         GLCompatible.useProgram(0);
         GLCompatible.deleteProgram(this.programId);
         this.programId = -1;
         return true;
      }
   }

   public boolean equals(@Nullable Object other) {
      return other instanceof Shader && Intrinsics.areEqual(this.location, ((Shader)other).location);
   }

   public int hashCode() {
      return this.location.hashCode();
   }

   @NotNull
   public String toString() {
      return "Shader(location='" + this.location + "', programId=" + this.programId + ')';
   }
}

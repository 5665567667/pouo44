package loliland.graphics.renderer.shader.uniform;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import loliland.graphics.renderer.GLCompatible;
import loliland.graphics.renderer.shader.Shader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0007\n\u0002\u0010\u0002\n\u0002\b\u0002\b&\u0018\u0000 \u00172\u00020\u0001:\u0001\u0017B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\b\u0010\u0014\u001a\u00020\bH\u0016J\u0006\u0010\u0015\u001a\u00020\u0016R\u001a\u0010\u0007\u001a\u00020\bX\u0084\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\t\u0010\n\"\u0004\b\u000b\u0010\fR\u001e\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\r\u001a\u00020\u000e@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0018"},
   d2 = {"Lloliland/graphics/renderer/shader/uniform/Uniform;", "", "shader", "Lloliland/graphics/renderer/shader/Shader;", "name", "", "(Lloliland/graphics/renderer/shader/Shader;Ljava/lang/String;)V", "firstUpload", "", "getFirstUpload", "()Z", "setFirstUpload", "(Z)V", "<set-?>", "", "location", "getLocation", "()I", "getName", "()Ljava/lang/String;", "dispose", "initialize", "", "Companion", "loligraphics-1.7.10"}
)
public abstract class Uniform {
   @NotNull
   public static final Companion Companion = new Companion((DefaultConstructorMarker)null);
   @NotNull
   private final Shader shader;
   @NotNull
   private final String name;
   private boolean firstUpload;
   private int location;
   public static final int NOT_INITIALIZED_LOCATION = -2;
   @NotNull
   private static final Logger log;

   public Uniform(@NotNull Shader shader, @NotNull String name) {
      Intrinsics.checkNotNullParameter(shader, "shader");
      Intrinsics.checkNotNullParameter(name, "name");
      super();
      this.shader = shader;
      this.name = name;
      this.firstUpload = true;
      this.location = -2;
   }

   @NotNull
   public final String getName() {
      return this.name;
   }

   protected final boolean getFirstUpload() {
      return this.firstUpload;
   }

   protected final void setFirstUpload(boolean var1) {
      this.firstUpload = var1;
   }

   public final int getLocation() {
      return this.location;
   }

   public final void initialize() {
      this.location = GLCompatible.getUniformLocation(this.shader.getProgramId(), (CharSequence)this.name);
      if (this.location == -1) {
         log.warn("No uniform variable called '" + this.name + "' found in shaders: " + this.shader.getLocation());
      }

   }

   public boolean dispose() {
      this.location = -2;
      this.firstUpload = true;
      return true;
   }

   static {
      Logger var10000 = LogManager.getLogger("Shaders");
      Intrinsics.checkNotNullExpressionValue(var10000, "getLogger(...)");
      log = var10000;
   }

   @Metadata(
      mv = {1, 9, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\b¨\u0006\t"},
      d2 = {"Lloliland/graphics/renderer/shader/uniform/Uniform$Companion;", "", "()V", "NOT_INITIALIZED_LOCATION", "", "log", "Lorg/apache/logging/log4j/Logger;", "getLog", "()Lorg/apache/logging/log4j/Logger;", "loligraphics-1.7.10"}
   )
   public static final class Companion {
      private Companion() {
      }

      @NotNull
      public final Logger getLog() {
         return Uniform.log;
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}

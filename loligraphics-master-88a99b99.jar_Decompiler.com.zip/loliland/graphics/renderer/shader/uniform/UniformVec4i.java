package loliland.graphics.renderer.shader.uniform;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import loliland.graphics.renderer.GLCompatible;
import loliland.graphics.renderer.shader.Shader;
import org.jetbrains.annotations.NotNull;
import org.joml.Vector4i;
import org.joml.Vector4ic;

@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J&\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0010\u001a\u00020\u000e2\u0006\u0010\u0011\u001a\u00020\u000eJ\u000e\u0010\u000b\u001a\u00020\f2\u0006\u0010\u0012\u001a\u00020\u0013R\u0011\u0010\u0007\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\u0014"},
   d2 = {"Lloliland/graphics/renderer/shader/uniform/UniformVec4i;", "Lloliland/graphics/renderer/shader/uniform/Uniform;", "shader", "Lloliland/graphics/renderer/shader/Shader;", "name", "", "(Lloliland/graphics/renderer/shader/Shader;Ljava/lang/String;)V", "currentValue", "Lorg/joml/Vector4ic;", "getCurrentValue", "()Lorg/joml/Vector4ic;", "set", "", "i1", "", "i2", "i3", "i4", "value", "Lorg/joml/Vector4i;", "loligraphics-1.7.10"}
)
public final class UniformVec4i extends Uniform {
   @NotNull
   private final Vector4ic currentValue;

   public UniformVec4i(@NotNull Shader shader, @NotNull String name) {
      Intrinsics.checkNotNullParameter(shader, "shader");
      Intrinsics.checkNotNullParameter(name, "name");
      super(shader, name);
      this.currentValue = (Vector4ic)(new Vector4i());
   }

   @NotNull
   public final Vector4ic getCurrentValue() {
      return this.currentValue;
   }

   public final void set(@NotNull Vector4i value) {
      Intrinsics.checkNotNullParameter(value, "value");
      this.set(value.x, value.y, value.z, value.w);
   }

   public final void set(int i1, int i2, int i3, int i4) {
      if (!this.currentValue.equals(i1, i2, i3, i4) || this.getFirstUpload()) {
         GLCompatible.uniform4i(this.getLocation(), i1, i2, i3, i4);
         Vector4ic var10000 = this.currentValue;
         Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type org.joml.Vector4i");
         ((Vector4i)var10000).set(i1, i2, i3, i4);
         this.setFirstUpload(false);
      }

   }
}

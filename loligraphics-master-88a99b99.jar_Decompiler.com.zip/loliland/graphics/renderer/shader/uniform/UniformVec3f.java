package loliland.graphics.renderer.shader.uniform;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import loliland.graphics.renderer.GLCompatible;
import loliland.graphics.renderer.shader.Shader;
import org.jetbrains.annotations.NotNull;
import org.joml.Vector3f;
import org.joml.Vector3fc;

@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\u001e\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0010\u001a\u00020\u000eJ\u000e\u0010\u000b\u001a\u00020\f2\u0006\u0010\u0011\u001a\u00020\u0012R\u0011\u0010\u0007\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\u0013"},
   d2 = {"Lloliland/graphics/renderer/shader/uniform/UniformVec3f;", "Lloliland/graphics/renderer/shader/uniform/Uniform;", "shader", "Lloliland/graphics/renderer/shader/Shader;", "name", "", "(Lloliland/graphics/renderer/shader/Shader;Ljava/lang/String;)V", "currentValue", "Lorg/joml/Vector3fc;", "getCurrentValue", "()Lorg/joml/Vector3fc;", "set", "", "f1", "", "f2", "f3", "value", "Lorg/joml/Vector3f;", "loligraphics-1.7.10"}
)
public final class UniformVec3f extends Uniform {
   @NotNull
   private final Vector3fc currentValue;

   public UniformVec3f(@NotNull Shader shader, @NotNull String name) {
      Intrinsics.checkNotNullParameter(shader, "shader");
      Intrinsics.checkNotNullParameter(name, "name");
      super(shader, name);
      this.currentValue = (Vector3fc)(new Vector3f());
   }

   @NotNull
   public final Vector3fc getCurrentValue() {
      return this.currentValue;
   }

   public final void set(@NotNull Vector3f value) {
      Intrinsics.checkNotNullParameter(value, "value");
      this.set(value.x, value.y, value.z);
   }

   public final void set(float f1, float f2, float f3) {
      if (!this.currentValue.equals(f1, f2, f3) || this.getFirstUpload()) {
         GLCompatible.uniform3f(this.getLocation(), f1, f2, f3);
         Vector3fc var10000 = this.currentValue;
         Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type org.joml.Vector3f");
         ((Vector3f)var10000).set(f1, f2, f3);
         this.setFirstUpload(false);
      }

   }
}

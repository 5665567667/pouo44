package loliland.graphics;

import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.EventHandler;
import cpw.mods.fml.common.Mod.InstanceFactory;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.InputEvent;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;
import loliland.graphics.renderer.GLCompatible;
import loliland.graphics.renderer.font.FontManager;
import loliland.graphics.renderer.shader.ShaderManager;
import loliland.graphics.renderer.texture.TextureManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.resources.IReloadableResourceManager;
import net.minecraft.client.resources.IResourceManager;
import net.minecraftforge.common.MinecraftForge;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;
import org.lwjglx.input.Keyboard;

@Mod(
   modid = "loligraphics",
   name = "LoliGraphics",
   version = "0.1.0",
   acceptableRemoteVersions = "*"
)
@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\bÇ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\b\u0010\u0013\u001a\u00020\u0014H\u0007J\b\u0010\u0015\u001a\u00020\u0000H\u0007J\u0010\u0010\u0016\u001a\u00020\u00142\u0006\u0010\u0017\u001a\u00020\u0018H\u0007J\u0010\u0010\u0019\u001a\u00020\u00142\u0006\u0010\u001a\u001a\u00020\u001bH\u0007J\u0010\u0010\u001c\u001a\u00020\u00142\u0006\u0010\u001d\u001a\u00020\u001eH\u0007R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u001e\u0010\b\u001a\u00020\u00072\u0006\u0010\u0006\u001a\u00020\u0007@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u001a\u0010\u000b\u001a\u00020\u0007X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\n\"\u0004\b\r\u0010\u000eR\u0011\u0010\u000f\u001a\u00020\u0010¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012¨\u0006\u001f"},
   d2 = {"Lloliland/graphics/LoliGraphics;", "", "()V", "MOD_ID", "", "MOD_NAME", "<set-?>", "", "initialized", "getInitialized", "()Z", "loadingScreenActive", "getLoadingScreenActive", "setLoadingScreenActive", "(Z)V", "logger", "Lorg/apache/logging/log4j/Logger;", "getLogger", "()Lorg/apache/logging/log4j/Logger;", "initCapability", "", "instance", "onKeyInput", "e", "Lcpw/mods/fml/common/gameevent/InputEvent$KeyInputEvent;", "preInit", "event", "Lcpw/mods/fml/common/event/FMLPreInitializationEvent;", "registerReloadListeners", "manager", "Lnet/minecraft/client/resources/IReloadableResourceManager;", "loligraphics-1.7.10"}
)
public final class LoliGraphics {
   @NotNull
   public static final LoliGraphics INSTANCE = new LoliGraphics();
   @NotNull
   public static final String MOD_ID = "loligraphics";
   @NotNull
   public static final String MOD_NAME = "LoliGraphics";
   @NotNull
   private static final Logger logger;
   private static boolean loadingScreenActive;
   private static boolean initialized;

   private LoliGraphics() {
   }

   @JvmStatic
   @InstanceFactory
   @NotNull
   public static final LoliGraphics instance() {
      return INSTANCE;
   }

   @NotNull
   public final Logger getLogger() {
      return logger;
   }

   public final boolean getLoadingScreenActive() {
      return loadingScreenActive;
   }

   public final void setLoadingScreenActive(boolean var1) {
      loadingScreenActive = var1;
   }

   public final boolean getInitialized() {
      return initialized;
   }

   @SideOnly(Side.CLIENT)
   public final void registerReloadListeners(@NotNull IReloadableResourceManager manager) {
      Intrinsics.checkNotNullParameter(manager, "manager");
      if (!initialized) {
         initialized = true;
         manager.func_110542_a(TextureManager.INSTANCE);
         manager.func_110542_a(ShaderManager.INSTANCE);
         manager.func_110542_a(FontManager.INSTANCE);
      }
   }

   @SideOnly(Side.CLIENT)
   public final void initCapability() {
      GLCompatible.error = GLCompatible.init();
      String var10000 = GLCompatible.error;
      Intrinsics.checkNotNullExpressionValue(var10000, "error");
      if (((CharSequence)var10000).length() == 0) {
         logger.log(Level.INFO, "Advanced rendering fully supported");
      } else {
         Logger var2 = logger;
         Level var10001 = Level.WARN;
         Object[] var1 = new Object[]{GLCompatible.error};
         var2.log(var10001, "Advanced rendering not supported: {}", var1);
      }

   }

   @EventHandler
   @SideOnly(Side.CLIENT)
   public final void preInit(@NotNull FMLPreInitializationEvent event) {
      Intrinsics.checkNotNullParameter(event, "event");
      MinecraftForge.EVENT_BUS.register(this);
      FMLCommonHandler.instance().bus().register(this);
   }

   @SubscribeEvent
   @SideOnly(Side.CLIENT)
   public final void onKeyInput(@NotNull InputEvent.KeyInputEvent e) {
      Intrinsics.checkNotNullParameter(e, "e");
      if (GuiScreen.func_146271_m() && GuiScreen.func_146272_n() && Keyboard.isKeyDown(35)) {
         ShaderManager var10000 = ShaderManager.INSTANCE;
         IResourceManager var10001 = Minecraft.func_71410_x().func_110442_L();
         Intrinsics.checkNotNullExpressionValue(var10001, "getResourceManager(...)");
         var10000.func_110549_a(var10001);
         logger.info("ShaderManager reloaded successfully.");
      }

   }

   static {
      Logger var10000 = LogManager.getLogger("LoliGraphics");
      Intrinsics.checkNotNullExpressionValue(var10000, "getLogger(...)");
      logger = var10000;
   }
}

package loliland.graphics.renderer.font.shader;

import java.util.Set;
import kotlin.Metadata;
import kotlin.collections.SetsKt;
import kotlin.jvm.internal.SourceDebugExtension;
import loliland.graphics.renderer.GLCompatible;
import loliland.graphics.renderer.shader.Shader;
import loliland.graphics.renderer.shader.uniform.UniformFloat;
import loliland.graphics.renderer.shader.uniform.UniformMatrix4;
import loliland.graphics.renderer.shader.uniform.UniformVec2f;
import loliland.graphics.renderer.shader.uniform.UniformVec3f;
import loliland.graphics.renderer.shader.uniform.UniformVec4f;
import net.minecraft.util.ResourceLocation;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\"\n\u0002\u0010\b\n\u0002\b\u0005\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u0011\u0010\u0003\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R\u0011\u0010\u0007\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\u0006R\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\r\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u0006R\u0011\u0010\u000f\u001a\u00020\u0010¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0013\u001a\u00020\u0014¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016R\u0011\u0010\u0017\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0006R\u0011\u0010\u0019\u001a\u00020\u001a¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u001cR\u0011\u0010\u001d\u001a\u00020\u001a¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u001cR\u0011\u0010\u001f\u001a\u00020\u0010¢\u0006\b\n\u0000\u001a\u0004\b \u0010\u0012R\u001a\u0010!\u001a\b\u0012\u0004\u0012\u00020#0\"X\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b$\u0010%R\u0011\u0010&\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b'\u0010\u0006¨\u0006("},
   d2 = {"Lloliland/graphics/renderer/font/shader/FontShaderActual;", "Lloliland/graphics/renderer/shader/Shader;", "()V", "borderEdge", "Lloliland/graphics/renderer/shader/uniform/UniformFloat;", "getBorderEdge", "()Lloliland/graphics/renderer/shader/uniform/UniformFloat;", "borderWidth", "getBorderWidth", "color", "Lloliland/graphics/renderer/shader/uniform/UniformVec4f;", "getColor", "()Lloliland/graphics/renderer/shader/uniform/UniformVec4f;", "edge", "getEdge", "modelViewMatrix", "Lloliland/graphics/renderer/shader/uniform/UniformMatrix4;", "getModelViewMatrix", "()Lloliland/graphics/renderer/shader/uniform/UniformMatrix4;", "offset", "Lloliland/graphics/renderer/shader/uniform/UniformVec2f;", "getOffset", "()Lloliland/graphics/renderer/shader/uniform/UniformVec2f;", "opacity", "getOpacity", "outlineColor", "Lloliland/graphics/renderer/shader/uniform/UniformVec3f;", "getOutlineColor", "()Lloliland/graphics/renderer/shader/uniform/UniformVec3f;", "position", "getPosition", "projectionMatrix", "getProjectionMatrix", "types", "", "", "getTypes", "()Ljava/util/Set;", "width", "getWidth", "loligraphics-1.7.10"}
)
@SourceDebugExtension({"SMAP\nFontShaderActual.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FontShaderActual.kt\nloliland/graphics/renderer/font/shader/FontShaderActual\n+ 2 Shader.kt\nloliland/graphics/renderer/shader/Shader\n*L\n1#1,30:1\n25#2:31\n25#2:32\n25#2:33\n25#2:34\n25#2:35\n25#2:36\n25#2:37\n25#2:38\n25#2:39\n25#2:40\n25#2:41\n*S KotlinDebug\n*F\n+ 1 FontShaderActual.kt\nloliland/graphics/renderer/font/shader/FontShaderActual\n*L\n19#1:31\n20#1:32\n21#1:33\n22#1:34\n23#1:35\n24#1:36\n25#1:37\n26#1:38\n27#1:39\n28#1:40\n29#1:41\n*E\n"})
public final class FontShaderActual extends Shader {
   @NotNull
   public static final FontShaderActual INSTANCE = new FontShaderActual();
   @NotNull
   private static final Set<Integer> types;
   @NotNull
   private static final UniformVec4f color;
   @NotNull
   private static final UniformVec3f outlineColor;
   @NotNull
   private static final UniformMatrix4 modelViewMatrix;
   @NotNull
   private static final UniformMatrix4 projectionMatrix;
   @NotNull
   private static final UniformVec3f position;
   @NotNull
   private static final UniformFloat width;
   @NotNull
   private static final UniformFloat edge;
   @NotNull
   private static final UniformFloat borderWidth;
   @NotNull
   private static final UniformFloat borderEdge;
   @NotNull
   private static final UniformVec2f offset;
   @NotNull
   private static final UniformFloat opacity;

   private FontShaderActual() {
      super(new ResourceLocation("shaders/font/actual"));
   }

   @NotNull
   public Set<Integer> getTypes() {
      return types;
   }

   @NotNull
   public final UniformVec4f getColor() {
      return color;
   }

   @NotNull
   public final UniformVec3f getOutlineColor() {
      return outlineColor;
   }

   @NotNull
   public final UniformMatrix4 getModelViewMatrix() {
      return modelViewMatrix;
   }

   @NotNull
   public final UniformMatrix4 getProjectionMatrix() {
      return projectionMatrix;
   }

   @NotNull
   public final UniformVec3f getPosition() {
      return position;
   }

   @NotNull
   public final UniformFloat getWidth() {
      return width;
   }

   @NotNull
   public final UniformFloat getEdge() {
      return edge;
   }

   @NotNull
   public final UniformFloat getBorderWidth() {
      return borderWidth;
   }

   @NotNull
   public final UniformFloat getBorderEdge() {
      return borderEdge;
   }

   @NotNull
   public final UniformVec2f getOffset() {
      return offset;
   }

   @NotNull
   public final UniformFloat getOpacity() {
      return opacity;
   }

   static {
      Integer[] var0 = new Integer[]{GLCompatible.GL_VERTEX_SHADER, GLCompatible.GL_FRAGMENT_SHADER};
      types = SetsKt.setOf(var0);
      INSTANCE.createAttribute("position");
      INSTANCE.createAttribute("textureCoords");
      Shader this_$iv = INSTANCE;
      String name$iv = "color";
      int $i$f$createUniform = 0;
      color = (UniformVec4f)this_$iv.createUniform(UniformVec4f.class, name$iv);
      this_$iv = INSTANCE;
      name$iv = "outlineColor";
      $i$f$createUniform = 0;
      outlineColor = (UniformVec3f)this_$iv.createUniform(UniformVec3f.class, name$iv);
      this_$iv = INSTANCE;
      name$iv = "modelViewMatrix";
      $i$f$createUniform = 0;
      modelViewMatrix = (UniformMatrix4)this_$iv.createUniform(UniformMatrix4.class, name$iv);
      this_$iv = INSTANCE;
      name$iv = "projectionMatrix";
      $i$f$createUniform = 0;
      projectionMatrix = (UniformMatrix4)this_$iv.createUniform(UniformMatrix4.class, name$iv);
      this_$iv = INSTANCE;
      name$iv = "position";
      $i$f$createUniform = 0;
      position = (UniformVec3f)this_$iv.createUniform(UniformVec3f.class, name$iv);
      this_$iv = INSTANCE;
      name$iv = "width";
      $i$f$createUniform = 0;
      width = (UniformFloat)this_$iv.createUniform(UniformFloat.class, name$iv);
      this_$iv = INSTANCE;
      name$iv = "edge";
      $i$f$createUniform = 0;
      edge = (UniformFloat)this_$iv.createUniform(UniformFloat.class, name$iv);
      this_$iv = INSTANCE;
      name$iv = "borderWidth";
      $i$f$createUniform = 0;
      borderWidth = (UniformFloat)this_$iv.createUniform(UniformFloat.class, name$iv);
      this_$iv = INSTANCE;
      name$iv = "borderEdge";
      $i$f$createUniform = 0;
      borderEdge = (UniformFloat)this_$iv.createUniform(UniformFloat.class, name$iv);
      this_$iv = INSTANCE;
      name$iv = "offset";
      $i$f$createUniform = 0;
      offset = (UniformVec2f)this_$iv.createUniform(UniformVec2f.class, name$iv);
      this_$iv = INSTANCE;
      name$iv = "opacity";
      $i$f$createUniform = 0;
      opacity = (UniformFloat)this_$iv.createUniform(UniformFloat.class, name$iv);
   }
}

package loliland.graphics.renderer.texture;

import cpw.mods.fml.common.ProgressManager;
import java.io.IOException;
import java.nio.IntBuffer;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import loliland.graphics.LoliGraphics;
import loliland.graphics.renderer.texture.png.PNGDecoder;
import net.minecraft.client.renderer.texture.TextureUtil;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.client.resources.IResourceManagerReloadListener;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.util.ReportedException;
import net.minecraft.util.ResourceLocation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.lwjglx.BufferUtils;

@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010%\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001:\u0001-B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u000e\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\fJ\u000e\u0010\u000f\u001a\u00020\f2\u0006\u0010\u0012\u001a\u00020\bJ\u0010\u0010\u0013\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\fH\u0002J\u0018\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u00172\b\b\u0002\u0010\u0018\u001a\u00020\u0019J\u000e\u0010\u001a\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\fJ\u0010\u0010\u001a\u001a\u0004\u0018\u00010\f2\u0006\u0010\u0012\u001a\u00020\bJ\u0006\u0010\u001b\u001a\u00020\u001cJ\u000e\u0010\u001d\u001a\u00020\f2\u0006\u0010\u0012\u001a\u00020\bJ\u0010\u0010\u001e\u001a\u0004\u0018\u00010\f2\u0006\u0010\u0012\u001a\u00020\bJ\u000e\u0010\u001f\u001a\u00020\u001c2\u0006\u0010\u0011\u001a\u00020\fJ\u000e\u0010 \u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\fJ\u0010\u0010!\u001a\u00020\u00102\u0006\u0010\"\u001a\u00020#H\u0016J\u000e\u0010$\u001a\u00020\u00102\u0006\u0010\u0012\u001a\u00020\bJ\u000e\u0010%\u001a\u00020\u00102\u0006\u0010\u0012\u001a\u00020\bJ\u000e\u0010&\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\fJ\u000e\u0010&\u001a\u00020\u00102\u0006\u0010\u0012\u001a\u00020\bJN\u0010'\u001a\u0002H(\"\b\b\u0000\u0010(*\u00020\f2\u0006\u0010\u0011\u001a\u0002H(2\b\b\u0002\u0010)\u001a\u00020\u001c2\u0012\u0010*\u001a\u000e\u0012\u0004\u0012\u0002H(\u0012\u0004\u0012\u00020\u00100+H\u0086\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0003 \u0001¢\u0006\u0002\u0010,J?\u0010'\u001a\u00020\f2\u0006\u0010\u0012\u001a\u00020\b2\b\b\u0002\u0010)\u001a\u00020\u001c2\u0012\u0010*\u001a\u000e\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\u00100+H\u0086\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0003 \u0001R\u0016\u0010\u0003\u001a\n \u0005*\u0004\u0018\u00010\u00040\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u001e\u0010\u0006\u001a\u0012\u0012\u0004\u0012\u00020\b0\u0007j\b\u0012\u0004\u0012\u00020\b`\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u001d\u0010\n\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\f0\u000b¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000e\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006."},
   d2 = {"Lloliland/graphics/renderer/texture/TextureManager;", "Lnet/minecraft/client/resources/IResourceManagerReloadListener;", "()V", "log", "Lorg/apache/logging/log4j/Logger;", "kotlin.jvm.PlatformType", "scheduledPreloads", "Ljava/util/LinkedHashSet;", "Lnet/minecraft/util/ResourceLocation;", "Lkotlin/collections/LinkedHashSet;", "textures", "", "Lloliland/graphics/renderer/texture/Texture;", "getTextures", "()Ljava/util/Map;", "bindTexture", "", "texture", "textureLocation", "bindTextureGL", "decodeTexture", "Lloliland/graphics/renderer/texture/TextureManager$TextureData;", "decoder", "Lloliland/graphics/renderer/texture/png/PNGDecoder;", "format", "Lloliland/graphics/renderer/texture/png/PNGDecoder$Format;", "deleteTexture", "dispose", "", "getOrLoadTexture", "getTexture", "isTextureLoaded", "loadTexture", "onResourceManagerReload", "resourceManager", "Lnet/minecraft/client/resources/IResourceManager;", "schedulePreload", "schedulePreloadOnReload", "unbindTexture", "useTexture", "T", "unbind", "block", "Lkotlin/Function1;", "(Lloliland/graphics/renderer/texture/Texture;ZLkotlin/jvm/functions/Function1;)Lloliland/graphics/renderer/texture/Texture;", "TextureData", "loligraphics-1.7.10"}
)
@SourceDebugExtension({"SMAP\nTextureManager.kt\nKotlin\n*S Kotlin\n*F\n+ 1 TextureManager.kt\nloliland/graphics/renderer/texture/TextureManager\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 _Maps.kt\nkotlin/collections/MapsKt___MapsKt\n*L\n1#1,181:1\n1855#2,2:182\n1855#2,2:186\n215#3,2:184\n*S KotlinDebug\n*F\n+ 1 TextureManager.kt\nloliland/graphics/renderer/texture/TextureManager\n*L\n119#1:182,2\n136#1:186,2\n124#1:184,2\n*E\n"})
public final class TextureManager implements IResourceManagerReloadListener {
   @NotNull
   public static final TextureManager INSTANCE = new TextureManager();
   private static final Logger log = LogManager.getLogger("Texture Manager");
   @NotNull
   private static final Map<ResourceLocation, Texture> textures = (Map)(new LinkedHashMap());
   @NotNull
   private static final LinkedHashSet<ResourceLocation> scheduledPreloads = new LinkedHashSet();

   private TextureManager() {
   }

   @NotNull
   public final Map<ResourceLocation, Texture> getTextures() {
      return textures;
   }

   public final void loadTexture(@NotNull Texture texture) {
      Intrinsics.checkNotNullParameter(texture, "texture");
      texture.dispose();
      textures.put(texture.getLocation(), texture);

      try {
         texture.load();
         Logger var10000 = log;
         Object[] var2 = new Object[]{texture.getLocation(), texture.getClass().getName()};
         var10000.debug("Loaded texture: {} # {}", var2);
      } catch (IOException e) {
         log.warn("Failed to load texture: " + texture.getLocation(), (Throwable)e);
         texture.dispose();
         textures.put(texture.getLocation(), MissingTexture.INSTANCE);
      } catch (Throwable e) {
         CrashReport report = CrashReport.func_85055_a(e, "Registering texture");
         CrashReportCategory category = report.func_85058_a("Resource location being registered");
         category.func_71507_a("Resource location", texture.getLocation());
         category.func_71500_a("Texture object class", TextureManager::loadTexture$lambda$1);
         throw new ReportedException(report);
      }

   }

   public final void schedulePreload(@NotNull ResourceLocation textureLocation) {
      Intrinsics.checkNotNullParameter(textureLocation, "textureLocation");
      this.getOrLoadTexture(textureLocation);
   }

   public final void schedulePreloadOnReload(@NotNull ResourceLocation textureLocation) {
      Intrinsics.checkNotNullParameter(textureLocation, "textureLocation");
      scheduledPreloads.add(textureLocation);
   }

   public final void bindTexture(@NotNull Texture texture) {
      Intrinsics.checkNotNullParameter(texture, "texture");
      if (!textures.containsKey(texture.getLocation())) {
         this.loadTexture(texture);
      }

      this.bindTextureGL(texture);
   }

   @NotNull
   public final Texture bindTexture(@NotNull ResourceLocation textureLocation) {
      Intrinsics.checkNotNullParameter(textureLocation, "textureLocation");
      Texture it = this.getOrLoadTexture(textureLocation);
      int var4 = 0;
      INSTANCE.bindTextureGL(it);
      return it;
   }

   @NotNull
   public final Texture getOrLoadTexture(@NotNull ResourceLocation textureLocation) {
      Intrinsics.checkNotNullParameter(textureLocation, "textureLocation");
      Texture var10000 = this.getTexture(textureLocation);
      if (var10000 == null) {
         SimpleTexture it = new SimpleTexture(textureLocation, 0, 0.0F, (Function1)null, 14, (DefaultConstructorMarker)null);
         int var4 = 0;
         INSTANCE.loadTexture(it);
         var10000 = it;
      }

      return var10000;
   }

   public final void unbindTexture(@NotNull ResourceLocation textureLocation) {
      Intrinsics.checkNotNullParameter(textureLocation, "textureLocation");
      Texture var10000 = this.getTexture(textureLocation);
      if (var10000 != null) {
         Texture it = var10000;
         int var4 = 0;
         it.unbind();
      }

   }

   public final void unbindTexture(@NotNull Texture texture) {
      Intrinsics.checkNotNullParameter(texture, "texture");
      this.unbindTexture(texture.getLocation());
   }

   @Nullable
   public final Texture deleteTexture(@NotNull ResourceLocation textureLocation) {
      Intrinsics.checkNotNullParameter(textureLocation, "textureLocation");
      Texture var10000 = (Texture)textures.remove(textureLocation);
      if (var10000 != null) {
         Texture it = var10000;
         int var4 = 0;
         it.dispose();
         var10000 = it;
      } else {
         var10000 = null;
      }

      return var10000;
   }

   public final void deleteTexture(@NotNull Texture texture) {
      Intrinsics.checkNotNullParameter(texture, "texture");
      this.deleteTexture(texture.getLocation());
   }

   @Nullable
   public final Texture getTexture(@NotNull ResourceLocation textureLocation) {
      Intrinsics.checkNotNullParameter(textureLocation, "textureLocation");
      return (Texture)textures.get(textureLocation);
   }

   public final boolean isTextureLoaded(@NotNull Texture texture) {
      Intrinsics.checkNotNullParameter(texture, "texture");
      return textures.containsKey(texture.getLocation());
   }

   public void func_110549_a(@NotNull IResourceManager resourceManager) {
      Intrinsics.checkNotNullParameter(resourceManager, "resourceManager");
      if (!LoliGraphics.INSTANCE.getLoadingScreenActive()) {
         HashMap reloaded = new HashMap(textures);
         Iterable $this$forEach$iv = (Iterable)scheduledPreloads;
         int $i$f$forEach = 0;

         for(Object element$iv : $this$forEach$iv) {
            ResourceLocation location = (ResourceLocation)element$iv;
            int var8 = 0;
            reloaded.putIfAbsent(location, new SimpleTexture(location, 0, 0.0F, (Function1)null, 14, (DefaultConstructorMarker)null));
         }

         textures.clear();
         ProgressManager.ProgressBar bar = ProgressManager.push("Reloading Texture Manager", reloaded.size(), true);
         Map $this$forEach$iv = (Map)reloaded;
         int $i$f$forEach = 0;

         for(Map.Entry element$iv : $this$forEach$iv.entrySet()) {
            int var9 = 0;
            ResourceLocation location = (ResourceLocation)element$iv.getKey();
            Texture texture = (Texture)element$iv.getValue();
            bar.step(location.toString());
            TextureManager var10000 = INSTANCE;
            Intrinsics.checkNotNull(texture);
            var10000.loadTexture(texture);
         }

         ProgressManager.pop(bar);
      }
   }

   private final void bindTextureGL(Texture texture) {
      texture.bind();
   }

   public final boolean dispose() {
      Iterable $this$forEach$iv = (Iterable)textures.values();
      int $i$f$forEach = 0;

      for(Object element$iv : $this$forEach$iv) {
         Texture it = (Texture)element$iv;
         int var6 = 0;
         it.dispose();
      }

      textures.clear();
      scheduledPreloads.clear();
      return true;
   }

   @NotNull
   public final <T extends Texture> T useTexture(@NotNull T texture, boolean unbind, @NotNull Function1<? super T, Unit> block) {
      Intrinsics.checkNotNullParameter(texture, "texture");
      Intrinsics.checkNotNullParameter(block, "block");
      int $i$f$useTexture = 0;
      this.bindTexture(texture);
      block.invoke(texture);
      if (unbind) {
         this.unbindTexture(texture);
      }

      return (T)texture;
   }

   // $FF: synthetic method
   public static Texture useTexture$default(TextureManager $this, Texture texture, boolean unbind, Function1 block, int $i$f$useTexture, Object var5) {
      if (($i$f$useTexture & 2) != 0) {
         unbind = false;
      }

      Intrinsics.checkNotNullParameter(texture, "texture");
      Intrinsics.checkNotNullParameter(block, "block");
      $i$f$useTexture = 0;
      $this.bindTexture(texture);
      block.invoke(texture);
      if (unbind) {
         $this.unbindTexture(texture);
      }

      return texture;
   }

   @NotNull
   public final Texture useTexture(@NotNull ResourceLocation textureLocation, boolean unbind, @NotNull Function1<? super Texture, Unit> block) {
      Intrinsics.checkNotNullParameter(textureLocation, "textureLocation");
      Intrinsics.checkNotNullParameter(block, "block");
      int $i$f$useTexture = 0;
      Texture texture = this.bindTexture(textureLocation);
      block.invoke(texture);
      if (unbind) {
         this.unbindTexture(textureLocation);
      }

      return texture;
   }

   // $FF: synthetic method
   public static Texture useTexture$default(TextureManager $this, ResourceLocation textureLocation, boolean unbind, Function1 block, int $i$f$useTexture, Object texture) {
      if (($i$f$useTexture & 2) != 0) {
         unbind = false;
      }

      Intrinsics.checkNotNullParameter(textureLocation, "textureLocation");
      Intrinsics.checkNotNullParameter(block, "block");
      $i$f$useTexture = 0;
      Texture texture = $this.bindTexture(textureLocation);
      block.invoke(texture);
      if (unbind) {
         $this.unbindTexture(textureLocation);
      }

      return texture;
   }

   @NotNull
   public final TextureData decodeTexture(@NotNull PNGDecoder decoder, @NotNull PNGDecoder.Format format) {
      Intrinsics.checkNotNullParameter(decoder, "decoder");
      Intrinsics.checkNotNullParameter(format, "format");
      IntBuffer pixels = BufferUtils.createIntBuffer(decoder.getWidth() * decoder.getHeight());
      decoder.decode(pixels, decoder.getWidth(), format);
      pixels.flip();
      int var10002 = decoder.getWidth();
      int var10003 = decoder.getHeight();
      Intrinsics.checkNotNull(pixels);
      return new TextureData(var10002, var10003, pixels);
   }

   // $FF: synthetic method
   public static TextureData decodeTexture$default(TextureManager var0, PNGDecoder var1, PNGDecoder.Format var2, int var3, Object var4) {
      if ((var3 & 2) != 0) {
         var2 = PNGDecoder.Format.ARGB;
      }

      return var0.decodeTexture(var1, var2);
   }

   private static final Object loadTexture$lambda$1(Texture $texture) {
      Intrinsics.checkNotNullParameter($texture, "$texture");
      return $texture.getClass().getName();
   }

   static {
      MissingTexture $this$_init__u24lambda_u240 = MissingTexture.INSTANCE;
      int var2 = 0;
      $this$_init__u24lambda_u240.setId(TextureUtil.field_111001_a.func_110552_b());
      $this$_init__u24lambda_u240.setWidth(16);
      $this$_init__u24lambda_u240.setHeight(16);
   }

   @Metadata(
      mv = {1, 9, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006¢\u0006\u0002\u0010\u0007R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\t¨\u0006\r"},
      d2 = {"Lloliland/graphics/renderer/texture/TextureManager$TextureData;", "", "width", "", "height", "pixels", "Ljava/nio/IntBuffer;", "(IILjava/nio/IntBuffer;)V", "getHeight", "()I", "getPixels", "()Ljava/nio/IntBuffer;", "getWidth", "loligraphics-1.7.10"}
   )
   public static final class TextureData {
      private final int width;
      private final int height;
      @NotNull
      private final IntBuffer pixels;

      public TextureData(int width, int height, @NotNull IntBuffer pixels) {
         Intrinsics.checkNotNullParameter(pixels, "pixels");
         super();
         this.width = width;
         this.height = height;
         this.pixels = pixels;
      }

      public final int getWidth() {
         return this.width;
      }

      public final int getHeight() {
         return this.height;
      }

      @NotNull
      public final IntBuffer getPixels() {
         return this.pixels;
      }
   }
}

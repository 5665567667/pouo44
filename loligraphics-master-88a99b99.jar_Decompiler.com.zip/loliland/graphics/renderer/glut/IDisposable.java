package loliland.graphics.renderer.glut;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public interface IDisposable {
   void dispose();
}

package loliland.graphics.renderer.font;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.properties.ObservableProperty;
import kotlin.reflect.KProperty;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0019\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J)\u0010\u0002\u001a\u00020\u00032\n\u0010\u0004\u001a\u0006\u0012\u0002\b\u00030\u00052\u0006\u0010\u0006\u001a\u00028\u00002\u0006\u0010\u0007\u001a\u00028\u0000H\u0014¢\u0006\u0002\u0010\b¨\u0006\t¸\u0006\u0000"},
   d2 = {"kotlin/properties/Delegates$observable$1", "Lkotlin/properties/ObservableProperty;", "afterChange", "", "property", "Lkotlin/reflect/KProperty;", "oldValue", "newValue", "(Lkotlin/reflect/KProperty;Ljava/lang/Object;Ljava/lang/Object;)V", "kotlin-stdlib"}
)
@SourceDebugExtension({"SMAP\nDelegates.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Delegates.kt\nkotlin/properties/Delegates$observable$1\n+ 2 FontText.kt\nloliland/graphics/renderer/font/FontText\n*L\n1#1,73:1\n748#2,4:74\n*E\n"})
public final class FontText$changeable$$inlined$observable$1 extends ObservableProperty<T> {
   // $FF: synthetic field
   final FontText this$0;

   public FontText$changeable$$inlined$observable$1(Object $initialValue, FontText var2) {
      super($initialValue);
      this.this$0 = var2;
   }

   protected void afterChange(@NotNull KProperty<?> property, T oldValue, T newValue) {
      Intrinsics.checkNotNullParameter(property, "property");
      int var6 = 0;
      if (!Intrinsics.areEqual(newValue, oldValue)) {
         FontText.access$setChanged$p(this.this$0, true);
      }

   }
}

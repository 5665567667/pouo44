package loliland.graphics.renderer.font;

import gnu.trove.list.array.TFloatArrayList;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.LazyThreadSafetyMode;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.SetsKt;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.MutablePropertyReference1;
import kotlin.jvm.internal.MutablePropertyReference1Impl;
import kotlin.jvm.internal.Ref;
import kotlin.jvm.internal.Reflection;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.properties.Delegates;
import kotlin.properties.ReadWriteProperty;
import kotlin.ranges.RangesKt;
import kotlin.reflect.KProperty;
import kotlin.text.CharsKt;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import loliland.graphics.LoliGraphics;
import loliland.graphics.renderer.GLCompatible;
import loliland.graphics.renderer.VAO;
import loliland.graphics.renderer.VBO;
import loliland.graphics.renderer.font.shader.FontShaderActual;
import loliland.graphics.renderer.font.shader.FontShaderLegacy;
import loliland.graphics.renderer.font.shader.FontShaderSuperLegacy;
import loliland.graphics.util.ChatUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Vector2f;
import org.joml.Vector2fc;
import org.joml.Vector3f;
import org.joml.Vector3fc;
import org.joml.Vector4f;
import org.joml.Vector4fc;
import org.lwjglx.BufferUtils;
import org.lwjglx.opengl.GL11;
import org.lwjglx.util.Dimension;
import org.lwjglx.util.ReadableDimension;

@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000¼\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u000f\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0012\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0018\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b!\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\f\n\u0002\b$\u0018\u0000 Ê\u00012\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0016È\u0001É\u0001Ê\u0001Ë\u0001Ì\u0001Í\u0001Î\u0001Ï\u0001Ð\u0001Ñ\u0001Ò\u0001B\u0017\b\u0016\u0012\u0006\u0010\u0002\u001a\u00020\u0000\u0012\u0006\u0010\u0003\u001a\u00020\u0004¢\u0006\u0002\u0010\u0005B\u0019\b\u0007\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\b\b\u0002\u0010\u0003\u001a\u00020\u0004¢\u0006\u0002\u0010\bJ\n\u0010\u0091\u0001\u001a\u00030\u0092\u0001H\u0002J\"\u0010\u0093\u0001\u001a\b\u0012\u0004\u0012\u00020`0_2\b\b\u0002\u0010\u0003\u001a\u00020\u00042\t\b\u0002\u0010\u0094\u0001\u001a\u00020\nJ.\u0010\u0095\u0001\u001a\u00030\u0096\u00012$\b\u0002\u0010\u0097\u0001\u001a\u001d\u0012\u0005\u0012\u00030\u0099\u0001\u0012\u0004\u0012\u00020i\u0012\u0004\u0012\u000203\u0012\u0005\u0012\u00030\u0096\u00010\u0098\u0001J1\u0010\u009a\u0001\u001a\u0013\u0012\u0007\u0012\u0005\u0018\u00010\u009c\u0001\u0012\u0005\u0012\u0003H\u009d\u00010\u009b\u0001\"\u0005\b\u0000\u0010\u009d\u00012\b\u0010\u009e\u0001\u001a\u0003H\u009d\u0001H\u0002¢\u0006\u0003\u0010\u009f\u0001J\u0014\u0010 \u0001\u001a\u00030¡\u00012\u0007\u0010¢\u0001\u001a\u00020\u0000H\u0096\u0002JA\u0010£\u0001\u001a\u00020\u00002\u0006\u0010z\u001a\u00020\n2\u0007\u0010\u008a\u0001\u001a\u00020\n2\u0006\u0010C\u001a\u00020\n2\u001d\b\u0002\u0010¤\u0001\u001a\u0016\u0012\u0004\u0012\u00020\u0000\u0012\u0005\u0012\u00030\u0096\u00010¥\u0001¢\u0006\u0003\b¦\u0001H\u0007J1\u0010£\u0001\u001a\u00020\u00002\u0007\u0010§\u0001\u001a\u00020S2\u001d\b\u0002\u0010¤\u0001\u001a\u0016\u0012\u0004\u0012\u00020\u0000\u0012\u0005\u0012\u00030\u0096\u00010¥\u0001¢\u0006\u0003\b¦\u0001H\u0007J\n\u0010¨\u0001\u001a\u00030\u0096\u0001H\u0002J \u0010©\u0001\u001a\b\u0012\u0004\u0012\u00020\u00040_2\u0006\u0010\u0003\u001a\u00020\u00042\u0007\u0010\u008d\u0001\u001a\u00020.H\u0002J\u0017\u0010ª\u0001\u001a\b\u0012\u0004\u0012\u00020\u00040_2\u0006\u0010\u0003\u001a\u00020\u0004H\u0002J\u0017\u0010«\u0001\u001a\b\u0012\u0004\u0012\u00020\u00040_2\u0006\u0010\u0003\u001a\u00020\u0004H\u0002J\u0007\u0010¬\u0001\u001a\u00020.J\u0011\u0010\u00ad\u0001\u001a\u00020\n2\b\u0010®\u0001\u001a\u00030¯\u0001J\u0014\u0010°\u0001\u001a\u00030\u0099\u00012\b\u0010®\u0001\u001a\u00030¯\u0001H\u0002J\u0013\u0010±\u0001\u001a\u00020\n2\b\u0010²\u0001\u001a\u00030\u0099\u0001H\u0002J\u0011\u0010³\u0001\u001a\u00020\n2\b\u0010´\u0001\u001a\u00030¡\u0001J\u0018\u0010³\u0001\u001a\u00020\n2\u000f\b\u0002\u0010µ\u0001\u001a\b\u0012\u0004\u0012\u00020`0_J\u0011\u0010¶\u0001\u001a\u00020\n2\b\b\u0002\u0010\u0003\u001a\u00020\u0004J\n\u0010·\u0001\u001a\u00030\u0096\u0001H\u0002J\b\u0010¸\u0001\u001a\u00030\u0096\u0001J\b\u0010¹\u0001\u001a\u00030\u0096\u0001J\b\u0010º\u0001\u001a\u00030\u0096\u0001J\b\u0010»\u0001\u001a\u00030\u0096\u0001J\u0012\u0010¼\u0001\u001a\u00030\u0096\u00012\b\u0010½\u0001\u001a\u00030¡\u0001J\u0011\u0010¾\u0001\u001a\u00030\u0096\u00012\u0007\u0010¿\u0001\u001a\u00020\nJ\u0012\u0010À\u0001\u001a\u00030\u0096\u00012\b\u0010½\u0001\u001a\u00030¡\u0001J!\u0010Á\u0001\u001a\u00030\u0096\u00012\u0006\u0010z\u001a\u00020\n2\u0007\u0010\u008a\u0001\u001a\u00020\n2\u0006\u0010C\u001a\u00020\nJ\u0018\u0010Â\u0001\u001a\b\u0012\u0004\u0012\u00020\u00040_2\u0007\u0010Ã\u0001\u001a\u00020\u0004H\u0002J\b\u0010Ä\u0001\u001a\u00030\u0096\u0001J2\u0010Å\u0001\u001a\u0003HÆ\u0001\"\u0005\b\u0000\u0010Æ\u00012\u001b\u0010¤\u0001\u001a\u0016\u0012\u0004\u0012\u00020\u0000\u0012\u0005\u0012\u0003HÆ\u00010¥\u0001¢\u0006\u0003\b¦\u0001¢\u0006\u0003\u0010Ç\u0001R\u001a\u0010\t\u001a\u00020\nX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\f\"\u0004\b\r\u0010\u000eR\u001a\u0010\u000f\u001a\u00020\nX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\f\"\u0004\b\u0011\u0010\u000eR+\u0010\u0014\u001a\u00020\u00132\u0006\u0010\u0012\u001a\u00020\u00138F@FX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b\u0019\u0010\u001a\u001a\u0004\b\u0015\u0010\u0016\"\u0004\b\u0017\u0010\u0018R/\u0010\u001c\u001a\u0004\u0018\u00010\u001b2\b\u0010\u0012\u001a\u0004\u0018\u00010\u001b8F@FX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b!\u0010\u001a\u001a\u0004\b\u001d\u0010\u001e\"\u0004\b\u001f\u0010 R\u0011\u0010\"\u001a\u00020\n8F¢\u0006\u0006\u001a\u0004\b#\u0010\fR\u0011\u0010$\u001a\u00020\n8F¢\u0006\u0006\u001a\u0004\b%\u0010\fR+\u0010&\u001a\u00020\n2\u0006\u0010\u0012\u001a\u00020\n8F@FX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b)\u0010\u001a\u001a\u0004\b'\u0010\f\"\u0004\b(\u0010\u000eR+\u0010*\u001a\u00020\n2\u0006\u0010\u0012\u001a\u00020\n8F@FX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b-\u0010\u001a\u001a\u0004\b+\u0010\f\"\u0004\b,\u0010\u000eR\u001e\u0010/\u001a\u00020.2\u0006\u0010\u0012\u001a\u00020.@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b0\u00101R\u0011\u00102\u001a\u000203¢\u0006\b\n\u0000\u001a\u0004\b4\u00105R\u0012\u00106\u001a\u00020\n8Æ\u0002¢\u0006\u0006\u001a\u0004\b7\u0010\fR+\u00108\u001a\u00020\u00042\u0006\u0010\u0012\u001a\u00020\u00048F@FX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b=\u0010\u001a\u001a\u0004\b9\u0010:\"\u0004\b;\u0010<R\u001e\u0010>\u001a\u00020\n2\u0006\u0010\u0012\u001a\u00020\n@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b?\u0010\fR\u001e\u0010@\u001a\u00020\n2\u0006\u0010\u0012\u001a\u00020\n@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\bA\u0010\fR\u000e\u0010B\u001a\u000203X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010C\u001a\u00020\nX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bD\u0010\f\"\u0004\bE\u0010\u000eR\u0011\u0010F\u001a\u00020.8F¢\u0006\u0006\u001a\u0004\bG\u00101R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\bH\u0010IR\u0012\u0010J\u001a\u00020\n8Æ\u0002¢\u0006\u0006\u001a\u0004\bK\u0010\fR+\u0010M\u001a\u00020L2\u0006\u0010\u0012\u001a\u00020L8F@FX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\bR\u0010\u001a\u001a\u0004\bN\u0010O\"\u0004\bP\u0010QR\u001e\u0010T\u001a\u00020S2\u0006\u0010\u0012\u001a\u00020S@BX\u0086.¢\u0006\b\n\u0000\u001a\u0004\bU\u0010VR+\u0010W\u001a\u00020\n2\u0006\u0010\u0012\u001a\u00020\n8F@FX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\bZ\u0010\u001a\u001a\u0004\bX\u0010\f\"\u0004\bY\u0010\u000eR+\u0010[\u001a\u00020\n2\u0006\u0010\u0012\u001a\u00020\n8F@FX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b^\u0010\u001a\u001a\u0004\b\\\u0010\f\"\u0004\b]\u0010\u000eR*\u0010a\u001a\b\u0012\u0004\u0012\u00020`0_2\f\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020`0_@BX\u0086.¢\u0006\b\n\u0000\u001a\u0004\bb\u0010cR\u0010\u0010d\u001a\u0004\u0018\u00010eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010f\u001a\u00020gX\u0082\u0004¢\u0006\u0002\n\u0000R\u0011\u0010h\u001a\u00020i¢\u0006\b\n\u0000\u001a\u0004\bj\u0010kR\u001a\u0010l\u001a\u00020\nX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bm\u0010\f\"\u0004\bn\u0010\u000eR\u0011\u0010o\u001a\u00020p¢\u0006\b\n\u0000\u001a\u0004\bq\u0010rR\u0011\u0010s\u001a\u00020p¢\u0006\b\n\u0000\u001a\u0004\bt\u0010rR\u000e\u0010u\u001a\u00020gX\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010v\u001a\u00020.X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bw\u00101\"\u0004\bx\u0010yR+\u0010z\u001a\u00020\n2\u0006\u0010\u0012\u001a\u00020\n8F@FX\u0086\u008e\u0002¢\u0006\u0012\n\u0004\b}\u0010\u001a\u001a\u0004\b{\u0010\f\"\u0004\b|\u0010\u000eR-\u0010~\u001a\u00020.2\u0006\u0010\u0012\u001a\u00020.8F@FX\u0086\u008e\u0002¢\u0006\u0014\n\u0005\b\u0081\u0001\u0010\u001a\u001a\u0004\b\u007f\u00101\"\u0005\b\u0080\u0001\u0010yR/\u0010\u0082\u0001\u001a\u00020.2\u0006\u0010\u0012\u001a\u00020.8F@FX\u0086\u008e\u0002¢\u0006\u0015\n\u0005\b\u0085\u0001\u0010\u001a\u001a\u0005\b\u0083\u0001\u00101\"\u0005\b\u0084\u0001\u0010yR/\u0010\u0086\u0001\u001a\u00020L2\u0006\u0010\u0012\u001a\u00020L8F@FX\u0086\u008e\u0002¢\u0006\u0015\n\u0005\b\u0089\u0001\u0010\u001a\u001a\u0005\b\u0087\u0001\u0010O\"\u0005\b\u0088\u0001\u0010QR\u001d\u0010\u008a\u0001\u001a\u00020\nX\u0086\u000e¢\u0006\u0010\n\u0000\u001a\u0005\b\u008b\u0001\u0010\f\"\u0005\b\u008c\u0001\u0010\u000eR/\u0010\u008d\u0001\u001a\u00020.2\u0006\u0010\u0012\u001a\u00020.8F@FX\u0086\u008e\u0002¢\u0006\u0015\n\u0005\b\u0090\u0001\u0010\u001a\u001a\u0005\b\u008e\u0001\u00101\"\u0005\b\u008f\u0001\u0010y¨\u0006Ó\u0001"},
   d2 = {"Lloliland/graphics/renderer/font/FontText;", "", "parent", "string", "", "(Lloliland/graphics/renderer/font/FontText;Ljava/lang/String;)V", "font", "Lloliland/graphics/renderer/font/Font;", "(Lloliland/graphics/renderer/font/Font;Ljava/lang/String;)V", "borderEdge", "", "getBorderEdge", "()F", "setBorderEdge", "(F)V", "borderWidth", "getBorderWidth", "setBorderWidth", "<set-?>", "Lorg/lwjgl/util/ReadableDimension;", "bounds", "getBounds", "()Lorg/lwjgl/util/ReadableDimension;", "setBounds", "(Lorg/lwjgl/util/ReadableDimension;)V", "bounds$delegate", "Lkotlin/properties/ReadWriteProperty;", "Lloliland/graphics/renderer/font/FontText$Bounds;", "boundsF", "getBoundsF", "()Lloliland/graphics/renderer/font/FontText$Bounds;", "setBoundsF", "(Lloliland/graphics/renderer/font/FontText$Bounds;)V", "boundsF$delegate", "boundsHeight", "getBoundsHeight", "boundsWidth", "getBoundsWidth", "centerOffsetX", "getCenterOffsetX", "setCenterOffsetX", "centerOffsetX$delegate", "centerOffsetY", "getCenterOffsetY", "setCenterOffsetY", "centerOffsetY$delegate", "", "changed", "getChanged", "()Z", "color", "Lorg/joml/Vector4f;", "getColor", "()Lorg/joml/Vector4f;", "colorAlpha", "getColorAlpha", "content", "getContent", "()Ljava/lang/String;", "setContent", "(Ljava/lang/String;)V", "content$delegate", "contentHeight", "getContentHeight", "contentWidth", "getContentWidth", "currentGlyphColor", "edge", "getEdge", "setEdge", "empty", "getEmpty", "getFont", "()Lloliland/graphics/renderer/font/Font;", "fontHeight", "getFontHeight", "Lloliland/graphics/renderer/font/FontText$Alignment;", "horizontalAlignment", "getHorizontalAlignment", "()Lloliland/graphics/renderer/font/FontText$Alignment;", "setHorizontalAlignment", "(Lloliland/graphics/renderer/font/FontText$Alignment;)V", "horizontalAlignment$delegate", "Lloliland/graphics/renderer/font/FontText$InitialData;", "initialData", "getInitialData", "()Lloliland/graphics/renderer/font/FontText$InitialData;", "letterSpacing", "getLetterSpacing", "setLetterSpacing", "letterSpacing$delegate", "lineHeight", "getLineHeight", "setLineHeight", "lineHeight$delegate", "", "Lloliland/graphics/renderer/font/FontText$Line;", "lines", "getLines", "()Ljava/util/List;", "mesh", "Lloliland/graphics/renderer/font/FontText$TextBuffer;", "modelViewMatrix", "Lorg/joml/Matrix4f;", "offset", "Lorg/joml/Vector2f;", "getOffset", "()Lorg/joml/Vector2f;", "opacity", "getOpacity", "setOpacity", "outlineColor", "Lorg/joml/Vector3f;", "getOutlineColor", "()Lorg/joml/Vector3f;", "position", "getPosition", "projectionMatrix", "renderEmpty", "getRenderEmpty", "setRenderEmpty", "(Z)V", "size", "getSize", "setSize", "size$delegate", "splitNextLine", "getSplitNextLine", "setSplitNextLine", "splitNextLine$delegate", "splitNextLineByChar", "getSplitNextLineByChar", "setSplitNextLineByChar", "splitNextLineByChar$delegate", "verticalAlignment", "getVerticalAlignment", "setVerticalAlignment", "verticalAlignment$delegate", "width", "getWidth", "setWidth", "wrap", "getWrap", "setWrap", "wrap$delegate", "buildTextData", "Lloliland/graphics/renderer/font/FontText$TextData;", "calculateLines", "lineWidth", "calculateText", "", "glyphAction", "Lkotlin/Function3;", "Lloliland/graphics/renderer/font/FontGlyph;", "changeable", "Lkotlin/properties/ReadWriteProperty;", "", "T", "initialValue", "(Ljava/lang/Object;)Lkotlin/properties/ReadWriteProperty;", "compareTo", "", "other", "configure", "block", "Lkotlin/Function1;", "Lkotlin/ExtensionFunctionType;", "data", "createMesh", "decodeLangNewlines", "decodeLangNewlinesWithWrap", "decodeLangNewlinesWithoutWrap", "dispose", "getCharWidth", "char", "", "getGlyph", "getGlyphWidth", "glyph", "getStringHeight", "linesCount", "inputLines", "getStringWidth", "rebuildMesh", "renderActual", "renderLegacy", "renderSuperLegacy", "resetTextOptions", "setColorARGB", "value", "setColorAlpha", "alpha", "setOutlineColorARGB", "setTextOptions", "splitWordRuns", "s", "updateMesh", "withoutChanges", "R", "(Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;", "Alignment", "Bounds", "Companion", "InitialData", "Line", "TextAbstractBufferVBO", "TextBuffer", "TextBufferSuperLegacyVBO", "TextBufferVAO", "TextBufferVBO", "TextData", "loligraphics-1.7.10"}
)
@SourceDebugExtension({"SMAP\nFontText.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FontText.kt\nloliland/graphics/renderer/font/FontText\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 4 _Strings.kt\nkotlin/text/StringsKt___StringsKt\n+ 5 ChatUtils.kt\nloliland/graphics/util/ChatUtils\n+ 6 ColorUtils.kt\nloliland/graphics/util/ColorUtils\n+ 7 Delegates.kt\nkotlin/properties/Delegates\n*L\n1#1,976:1\n78#1:977\n78#1:978\n78#1:1013\n1855#2:979\n1855#2,2:980\n1856#2:982\n1855#2:984\n1864#2,3:985\n1856#2:988\n1855#2:989\n1856#2:992\n1#3:983\n1174#4,2:990\n122#5,20:993\n6#6:1014\n18#6:1015\n9#6,10:1016\n12#6,7:1026\n15#6,4:1033\n6#6:1037\n18#6:1038\n9#6,10:1039\n6#6:1052\n18#6:1053\n9#6,10:1054\n12#6,7:1064\n33#7,3:1049\n*S KotlinDebug\n*F\n+ 1 FontText.kt\nloliland/graphics/renderer/font/FontText\n*L\n79#1:977\n358#1:978\n707#1:1013\n373#1:979\n449#1:980,2\n373#1:982\n495#1:984\n508#1:985,3\n495#1:988\n540#1:989\n540#1:992\n546#1:990,2\n688#1:993,20\n718#1:1014\n718#1:1015\n719#1:1016,10\n720#1:1026,7\n721#1:1033,4\n731#1:1037\n731#1:1038\n731#1:1039,10\n406#1:1052\n406#1:1053\n407#1:1054,10\n408#1:1064,7\n747#1:1049,3\n*E\n"})
public final class FontText implements Comparable<FontText> {
   @NotNull
   public static final Companion Companion;
   // $FF: synthetic field
   static final KProperty<Object>[] $$delegatedProperties;
   @NotNull
   private final Font font;
   @Nullable
   private TextBuffer mesh;
   private float width;
   private float edge;
   private float borderWidth;
   private float borderEdge;
   @NotNull
   private final Vector3f position;
   @NotNull
   private final Vector2f offset;
   @NotNull
   private final Vector4f color;
   @NotNull
   private final Vector3f outlineColor;
   private float opacity;
   @NotNull
   private final ReadWriteProperty size$delegate;
   @NotNull
   private final ReadWriteProperty content$delegate;
   @NotNull
   private final ReadWriteProperty letterSpacing$delegate;
   @NotNull
   private final ReadWriteProperty lineHeight$delegate;
   @NotNull
   private final ReadWriteProperty horizontalAlignment$delegate;
   @NotNull
   private final ReadWriteProperty verticalAlignment$delegate;
   @NotNull
   private final ReadWriteProperty bounds$delegate;
   @NotNull
   private final ReadWriteProperty boundsF$delegate;
   private boolean changed;
   private float contentHeight;
   private float contentWidth;
   private InitialData initialData;
   private boolean renderEmpty;
   private List<Line> lines;
   @NotNull
   private final ReadWriteProperty splitNextLine$delegate;
   @NotNull
   private final ReadWriteProperty splitNextLineByChar$delegate;
   @NotNull
   private final ReadWriteProperty wrap$delegate;
   @NotNull
   private final Matrix4f modelViewMatrix;
   @NotNull
   private final Matrix4f projectionMatrix;
   @NotNull
   private final Vector4f currentGlyphColor;
   @NotNull
   private final ReadWriteProperty centerOffsetX$delegate;
   @NotNull
   private final ReadWriteProperty centerOffsetY$delegate;
   private static final int ATTRIBUTE_VERTICES = 0;
   private static final int ATTRIBUTE_UVS = 1;
   private static final int ATTRIBUTE_COLORS = 2;
   @NotNull
   private static final Regex SPLIT_WORDS_REGEX;
   private static FloatBuffer buffer;
   private static final FloatBuffer modelViewMatrixBuffer;
   private static final FloatBuffer projectionMatrixBuffer;
   @NotNull
   private static final Set<Character> IGNORED_FORMATTING_CODES;

   @JvmOverloads
   public FontText(@NotNull Font font, @NotNull String string) {
      Intrinsics.checkNotNullParameter(font, "font");
      Intrinsics.checkNotNullParameter(string, "string");
      super();
      this.font = FontManager.INSTANCE.getOrLoadFont(font);
      this.width = 0.5F;
      this.edge = 0.1F;
      this.borderEdge = 0.1F;
      this.position = new Vector3f();
      this.offset = new Vector2f();
      this.color = new Vector4f();
      this.outlineColor = new Vector3f();
      this.opacity = 1.0F;
      this.size$delegate = this.changeable(0.3F);
      this.content$delegate = this.changeable(string);
      this.letterSpacing$delegate = this.changeable(1.0F);
      this.lineHeight$delegate = this.changeable(1.0F);
      this.horizontalAlignment$delegate = this.changeable(FontText.Alignment.LEFT);
      this.verticalAlignment$delegate = this.changeable(FontText.Alignment.TOP);
      this.bounds$delegate = this.changeable(new Dimension(-1, -1));
      this.boundsF$delegate = this.changeable((Object)null);
      int $i$f$getFontHeight = 0;
      this.contentHeight = (float)this.getFont().getMetadata().getLineHeight() * this.getSize();
      this.splitNextLine$delegate = this.changeable(true);
      this.splitNextLineByChar$delegate = this.changeable(false);
      this.wrap$delegate = this.changeable(true);
      this.modelViewMatrix = new Matrix4f();
      this.projectionMatrix = new Matrix4f();
      this.currentGlyphColor = new Vector4f(-1.0F);
      this.centerOffsetX$delegate = this.changeable(1.0F);
      this.centerOffsetY$delegate = this.changeable(1.0F);
   }

   // $FF: synthetic method
   public FontText(Font var1, String var2, int var3, DefaultConstructorMarker var4) {
      if ((var3 & 2) != 0) {
         var2 = "";
      }

      this(var1, var2);
   }

   @NotNull
   public final Font getFont() {
      return this.font;
   }

   public FontText(@NotNull FontText parent, @NotNull String string) {
      Intrinsics.checkNotNullParameter(parent, "parent");
      Intrinsics.checkNotNullParameter(string, "string");
      this(parent.font, string);
      configure$default(this, parent.getSize(), parent.width, parent.edge, (Function1)null, 8, (Object)null);
      this.borderWidth = parent.borderWidth;
      this.borderEdge = parent.borderEdge;
      this.setLetterSpacing(parent.getLetterSpacing());
      this.position.set((Vector3fc)parent.position);
      this.offset.set((Vector2fc)parent.offset);
      this.color.set((Vector4fc)parent.color);
      this.outlineColor.set((Vector3fc)parent.outlineColor);
      this.setLineHeight(parent.getLineHeight());
      this.setHorizontalAlignment(parent.getHorizontalAlignment());
      this.setVerticalAlignment(parent.getVerticalAlignment());
      this.setBounds((ReadableDimension)(new Dimension(parent.getBounds())));
      Bounds var10001 = parent.getBoundsF();
      this.setBoundsF(var10001 != null ? FontText.Bounds.copy$default(var10001, 0.0F, 0.0F, 3, (Object)null) : null);
      this.setSplitNextLine(parent.getSplitNextLine());
      this.setSplitNextLineByChar(parent.getSplitNextLineByChar());
      this.setCenterOffsetX(parent.getCenterOffsetX());
      this.setCenterOffsetY(parent.getCenterOffsetY());
   }

   public final float getWidth() {
      return this.width;
   }

   public final void setWidth(float var1) {
      this.width = var1;
   }

   public final float getEdge() {
      return this.edge;
   }

   public final void setEdge(float var1) {
      this.edge = var1;
   }

   public final float getBorderWidth() {
      return this.borderWidth;
   }

   public final void setBorderWidth(float var1) {
      this.borderWidth = var1;
   }

   public final float getBorderEdge() {
      return this.borderEdge;
   }

   public final void setBorderEdge(float var1) {
      this.borderEdge = var1;
   }

   @NotNull
   public final Vector3f getPosition() {
      return this.position;
   }

   @NotNull
   public final Vector2f getOffset() {
      return this.offset;
   }

   @NotNull
   public final Vector4f getColor() {
      return this.color;
   }

   @NotNull
   public final Vector3f getOutlineColor() {
      return this.outlineColor;
   }

   public final float getOpacity() {
      return this.opacity;
   }

   public final void setOpacity(float var1) {
      this.opacity = var1;
   }

   public final float getSize() {
      return ((Number)this.size$delegate.getValue(this, $$delegatedProperties[0])).floatValue();
   }

   public final void setSize(float var1) {
      this.size$delegate.setValue(this, $$delegatedProperties[0], var1);
   }

   @NotNull
   public final String getContent() {
      return (String)this.content$delegate.getValue(this, $$delegatedProperties[1]);
   }

   public final void setContent(@NotNull String var1) {
      Intrinsics.checkNotNullParameter(var1, "<set-?>");
      this.content$delegate.setValue(this, $$delegatedProperties[1], var1);
   }

   public final float getLetterSpacing() {
      return ((Number)this.letterSpacing$delegate.getValue(this, $$delegatedProperties[2])).floatValue();
   }

   public final void setLetterSpacing(float var1) {
      this.letterSpacing$delegate.setValue(this, $$delegatedProperties[2], var1);
   }

   public final float getLineHeight() {
      return ((Number)this.lineHeight$delegate.getValue(this, $$delegatedProperties[3])).floatValue();
   }

   public final void setLineHeight(float var1) {
      this.lineHeight$delegate.setValue(this, $$delegatedProperties[3], var1);
   }

   @NotNull
   public final Alignment getHorizontalAlignment() {
      return (Alignment)this.horizontalAlignment$delegate.getValue(this, $$delegatedProperties[4]);
   }

   public final void setHorizontalAlignment(@NotNull Alignment var1) {
      Intrinsics.checkNotNullParameter(var1, "<set-?>");
      this.horizontalAlignment$delegate.setValue(this, $$delegatedProperties[4], var1);
   }

   @NotNull
   public final Alignment getVerticalAlignment() {
      return (Alignment)this.verticalAlignment$delegate.getValue(this, $$delegatedProperties[5]);
   }

   public final void setVerticalAlignment(@NotNull Alignment var1) {
      Intrinsics.checkNotNullParameter(var1, "<set-?>");
      this.verticalAlignment$delegate.setValue(this, $$delegatedProperties[5], var1);
   }

   @NotNull
   public final ReadableDimension getBounds() {
      return (ReadableDimension)this.bounds$delegate.getValue(this, $$delegatedProperties[6]);
   }

   public final void setBounds(@NotNull ReadableDimension var1) {
      Intrinsics.checkNotNullParameter(var1, "<set-?>");
      this.bounds$delegate.setValue(this, $$delegatedProperties[6], var1);
   }

   @Nullable
   public final Bounds getBoundsF() {
      return (Bounds)this.boundsF$delegate.getValue(this, $$delegatedProperties[7]);
   }

   public final void setBoundsF(@Nullable Bounds var1) {
      this.boundsF$delegate.setValue(this, $$delegatedProperties[7], var1);
   }

   public final boolean getChanged() {
      return this.changed;
   }

   public final float getFontHeight() {
      int $i$f$getFontHeight = 0;
      return (float)this.getFont().getMetadata().getLineHeight() * this.getSize();
   }

   public final float getContentHeight() {
      return this.contentHeight;
   }

   public final float getContentWidth() {
      return this.contentWidth;
   }

   @NotNull
   public final InitialData getInitialData() {
      InitialData var10000 = this.initialData;
      if (var10000 != null) {
         return var10000;
      } else {
         Intrinsics.throwUninitializedPropertyAccessException("initialData");
         return null;
      }
   }

   public final boolean getEmpty() {
      return StringsKt.isBlank((CharSequence)this.getContent());
   }

   public final boolean getRenderEmpty() {
      return this.renderEmpty;
   }

   public final void setRenderEmpty(boolean var1) {
      this.renderEmpty = var1;
   }

   @NotNull
   public final List<Line> getLines() {
      List var10000 = this.lines;
      if (var10000 != null) {
         return var10000;
      } else {
         Intrinsics.throwUninitializedPropertyAccessException("lines");
         return null;
      }
   }

   public final boolean getSplitNextLine() {
      return (Boolean)this.splitNextLine$delegate.getValue(this, $$delegatedProperties[8]);
   }

   public final void setSplitNextLine(boolean var1) {
      this.splitNextLine$delegate.setValue(this, $$delegatedProperties[8], var1);
   }

   public final boolean getSplitNextLineByChar() {
      return (Boolean)this.splitNextLineByChar$delegate.getValue(this, $$delegatedProperties[9]);
   }

   public final void setSplitNextLineByChar(boolean var1) {
      this.splitNextLineByChar$delegate.setValue(this, $$delegatedProperties[9], var1);
   }

   public final boolean getWrap() {
      return (Boolean)this.wrap$delegate.getValue(this, $$delegatedProperties[10]);
   }

   public final void setWrap(boolean var1) {
      this.wrap$delegate.setValue(this, $$delegatedProperties[10], var1);
   }

   public final float getColorAlpha() {
      int $i$f$getColorAlpha = 0;
      return this.getColor().w;
   }

   public final float getBoundsWidth() {
      Bounds var10000 = this.getBoundsF();
      return var10000 != null ? var10000.getWidth() : (float)this.getBounds().getWidth();
   }

   public final float getBoundsHeight() {
      Bounds var10000 = this.getBoundsF();
      return var10000 != null ? var10000.getHeight() : (float)this.getBounds().getHeight();
   }

   public final float getCenterOffsetX() {
      return ((Number)this.centerOffsetX$delegate.getValue(this, $$delegatedProperties[11])).floatValue();
   }

   public final void setCenterOffsetX(float var1) {
      this.centerOffsetX$delegate.setValue(this, $$delegatedProperties[11], var1);
   }

   public final float getCenterOffsetY() {
      return ((Number)this.centerOffsetY$delegate.getValue(this, $$delegatedProperties[12])).floatValue();
   }

   public final void setCenterOffsetY(float var1) {
      this.centerOffsetY$delegate.setValue(this, $$delegatedProperties[12], var1);
   }

   @JvmOverloads
   @NotNull
   public final FontText configure(@NotNull InitialData data, @NotNull Function1<? super FontText, Unit> block) {
      Intrinsics.checkNotNullParameter(data, "data");
      Intrinsics.checkNotNullParameter(block, "block");
      this.initialData = data;
      this.setTextOptions(data.getSize(), data.getWidth(), data.getEdge());
      block.invoke(this);
      calculateText$default(this, (Function3)null, 1, (Object)null);
      return this;
   }

   // $FF: synthetic method
   public static FontText configure$default(FontText var0, InitialData var1, Function1 var2, int var3, Object var4) {
      if ((var3 & 2) != 0) {
         var2 = null.INSTANCE;
      }

      return var0.configure(var1, var2);
   }

   @JvmOverloads
   @NotNull
   public final FontText configure(float size, float width, float edge, @NotNull Function1<? super FontText, Unit> block) {
      Intrinsics.checkNotNullParameter(block, "block");
      return this.configure(new InitialData(size, width, edge), block);
   }

   // $FF: synthetic method
   public static FontText configure$default(FontText var0, float var1, float var2, float var3, Function1 var4, int var5, Object var6) {
      if ((var5 & 8) != 0) {
         var4 = null.INSTANCE;
      }

      return var0.configure(var1, var2, var3, var4);
   }

   public final void setTextOptions(float size, float width, float edge) {
      this.setSize(size);
      this.width = width;
      this.edge = edge;
   }

   public final void resetTextOptions() {
      this.setTextOptions(this.getInitialData().getSize(), this.getInitialData().getWidth(), this.getInitialData().getEdge());
   }

   public final void renderActual() {
      if (!this.getEmpty() || this.renderEmpty) {
         this.updateMesh();
         if (this.mesh == null) {
            LoliGraphics.INSTANCE.getLogger().error("Mesh is empty after build, WTF?");
         } else {
            GL11.glGetFloat(2982, modelViewMatrixBuffer);
            GL11.glGetFloat(2983, projectionMatrixBuffer);
            this.modelViewMatrix.set(modelViewMatrixBuffer);
            this.projectionMatrix.set(projectionMatrixBuffer);
            TextBuffer var10000 = this.mesh;
            Intrinsics.checkNotNull(var10000);
            TextBuffer $this$renderActual_u24lambda_u240 = var10000;
            int var3 = 0;
            $this$renderActual_u24lambda_u240.bind();
            FontShaderActual.INSTANCE.getModelViewMatrix().set(this.modelViewMatrix);
            FontShaderActual.INSTANCE.getProjectionMatrix().set(this.projectionMatrix);
            FontShaderActual.INSTANCE.getPosition().set(this.position);
            FontShaderActual.INSTANCE.getOffset().set(this.offset);
            FontShaderActual.INSTANCE.getColor().set(this.color);
            FontShaderActual.INSTANCE.getOutlineColor().set(this.outlineColor);
            FontShaderActual.INSTANCE.getWidth().set(this.width);
            FontShaderActual.INSTANCE.getEdge().set(this.edge);
            FontShaderActual.INSTANCE.getBorderWidth().set(this.borderWidth);
            FontShaderActual.INSTANCE.getBorderEdge().set(this.borderEdge);
            FontShaderActual.INSTANCE.getOpacity().set(this.opacity);
            $this$renderActual_u24lambda_u240.draw();
            $this$renderActual_u24lambda_u240.unbind();
         }
      }
   }

   public final void renderLegacy() {
      if (!this.getEmpty() || this.renderEmpty) {
         this.updateMesh();
         if (this.mesh == null) {
            LoliGraphics.INSTANCE.getLogger().error("Mesh is empty after build, WTF?");
         } else {
            TextBuffer var10000 = this.mesh;
            Intrinsics.checkNotNull(var10000);
            TextBuffer $this$renderLegacy_u24lambda_u241 = var10000;
            int var3 = 0;
            $this$renderLegacy_u24lambda_u241.bind();
            FontShaderLegacy.INSTANCE.getPosition().set(this.position);
            FontShaderLegacy.INSTANCE.getOffset().set(this.offset);
            FontShaderLegacy.INSTANCE.getColor().set(this.color);
            FontShaderLegacy.INSTANCE.getOutlineColor().set(this.outlineColor);
            FontShaderLegacy.INSTANCE.getWidth().set(this.width);
            FontShaderLegacy.INSTANCE.getEdge().set(this.edge);
            FontShaderLegacy.INSTANCE.getBorderWidth().set(this.borderWidth);
            FontShaderLegacy.INSTANCE.getBorderEdge().set(this.borderEdge);
            FontShaderLegacy.INSTANCE.getOpacity().set(this.opacity);
            $this$renderLegacy_u24lambda_u241.draw();
            $this$renderLegacy_u24lambda_u241.unbind();
         }
      }
   }

   public final void renderSuperLegacy() {
      if (!this.getEmpty() || this.renderEmpty) {
         this.updateMesh();
         if (this.mesh == null) {
            LoliGraphics.INSTANCE.getLogger().error("Mesh is empty after build, WTF?");
         } else {
            TextBuffer var10000 = this.mesh;
            Intrinsics.checkNotNull(var10000);
            TextBuffer $this$renderSuperLegacy_u24lambda_u242 = var10000;
            int var3 = 0;
            $this$renderSuperLegacy_u24lambda_u242.bind();
            FontShaderSuperLegacy.INSTANCE.getPosition().set(this.position);
            FontShaderSuperLegacy.INSTANCE.getOffset().set(this.offset);
            FontShaderSuperLegacy.INSTANCE.getColor().set(this.color);
            FontShaderSuperLegacy.INSTANCE.getOutlineColor().set(this.outlineColor);
            FontShaderSuperLegacy.INSTANCE.getWidth().set(this.width);
            FontShaderSuperLegacy.INSTANCE.getEdge().set(this.edge);
            FontShaderSuperLegacy.INSTANCE.getBorderWidth().set(this.borderWidth);
            FontShaderSuperLegacy.INSTANCE.getBorderEdge().set(this.borderEdge);
            FontShaderSuperLegacy.INSTANCE.getOpacity().set(this.opacity);
            $this$renderSuperLegacy_u24lambda_u242.draw();
            $this$renderSuperLegacy_u24lambda_u242.unbind();
         }
      }
   }

   public final void updateMesh() {
      if (this.mesh == null) {
         this.createMesh();
      } else if (this.changed) {
         this.rebuildMesh();
      }

      this.changed = false;
   }

   private final void createMesh() {
      TextBuffer var10000 = this.mesh;
      if (var10000 != null) {
         var10000.dispose();
      }

      this.mesh = null;
      TextData textData = this.buildTextData();
      TextBuffer var10001;
      switch (FontText.WhenMappings.$EnumSwitchMapping$0[FontManager.INSTANCE.getRenderMode().getBuffer().ordinal()]) {
         case 1:
            var10001 = new TextBufferVAO(textData);
            break;
         case 2:
            var10001 = new TextBufferVBO(textData);
            break;
         case 3:
            var10001 = new TextBufferSuperLegacyVBO(textData);
            break;
         default:
            throw new NoWhenBranchMatchedException();
      }

      this.mesh = var10001;
   }

   private final void rebuildMesh() {
      TextData textData = this.buildTextData();
      TextBuffer var10000 = this.mesh;
      Intrinsics.checkNotNull(var10000);
      var10000.update(textData);
   }

   private final TextData buildTextData() {
      TFloatArrayList vertices = new TFloatArrayList(1536);
      TFloatArrayList uvs = new TFloatArrayList(1536);
      TFloatArrayList colors = new TFloatArrayList(3072);
      this.calculateText(new Function3<FontGlyph, Vector2f, Vector4f, Unit>(this, vertices, uvs, colors) {
         // $FF: synthetic field
         final FontText this$0;
         // $FF: synthetic field
         final TFloatArrayList $vertices;
         // $FF: synthetic field
         final TFloatArrayList $uvs;
         // $FF: synthetic field
         final TFloatArrayList $colors;

         {
            this.this$0 = $receiver;
            this.$vertices = $vertices;
            this.$uvs = $uvs;
            this.$colors = $colors;
         }

         public final void invoke(@NotNull FontGlyph p0, @NotNull Vector2f p1, @NotNull Vector4f p2) {
            Intrinsics.checkNotNullParameter(p0, "p0");
            Intrinsics.checkNotNullParameter(p1, "p1");
            Intrinsics.checkNotNullParameter(p2, "p2");
            FontText.buildTextData$glyphMesh(this.this$0, this.$vertices, this.$uvs, this.$colors, p0, p1, p2);
         }
      });
      float[] var10002 = vertices.toArray();
      Intrinsics.checkNotNullExpressionValue(var10002, "toArray(...)");
      float[] var10003 = uvs.toArray();
      Intrinsics.checkNotNullExpressionValue(var10003, "toArray(...)");
      float[] var10004 = colors.toArray();
      Intrinsics.checkNotNullExpressionValue(var10004, "toArray(...)");
      return new TextData(var10002, var10003, var10004);
   }

   public final void calculateText(@NotNull Function3<? super FontGlyph, ? super Vector2f, ? super Vector4f, Unit> glyphAction) {
      Intrinsics.checkNotNullParameter(glyphAction, "glyphAction");
      this.lines = calculateLines$default(this, (String)null, 0.0F, 3, (Object)null);
      int $i$f$getFontHeight = 0;
      float lineYOffset = (float)this.getFont().getMetadata().getLineHeight() * this.getSize() * this.getLineHeight();
      this.contentHeight = getStringHeight$default(this, (List)null, 1, (Object)null);
      Ref.FloatRef cursorY = new Ref.FloatRef();
      float var10001;
      if (this.getBoundsHeight() > 0.0F) {
         switch (FontText.WhenMappings.$EnumSwitchMapping$1[this.getVerticalAlignment().ordinal()]) {
            case 1:
               var10001 = 0.0F;
               break;
            case 2:
               var10001 = (this.getBoundsHeight() - this.contentHeight) / 2.0F + this.getCenterOffsetY();
               break;
            case 3:
               var10001 = this.getBoundsHeight() - this.contentHeight;
               break;
            default:
               throw new IllegalStateException(("Illegal vertical alignment for string '" + this.getContent() + "': " + this.getVerticalAlignment()).toString());
         }
      } else {
         var10001 = 0.0F;
      }

      cursorY.element = var10001;
      Vector2f tempCursorPos = new Vector2f();
      Iterable $this$forEach$iv = (Iterable)this.getLines();
      int $i$f$forEach = 0;

      for(Object element$iv : $this$forEach$iv) {
         Line line = (Line)element$iv;
         int var10 = 0;
         String lineStringWithoutCodes = ChatUtils.withoutFormattingCodes(line.getString());
         float lineWidth = this.getStringWidth(lineStringWithoutCodes);
         Ref.FloatRef cursorX = new Ref.FloatRef();
         if (this.getBoundsWidth() > 0.0F && this.getHorizontalAlignment() != FontText.Alignment.JUSTIFY) {
            switch (FontText.WhenMappings.$EnumSwitchMapping$1[this.getHorizontalAlignment().ordinal()]) {
               case 2:
                  var10001 = (this.getBoundsWidth() - lineWidth) / 2.0F + this.getCenterOffsetX();
                  break;
               case 3:
               default:
                  throw new IllegalStateException(("Illegal horizontal alignment for string '" + this.getContent() + "': " + this.getHorizontalAlignment()).toString());
               case 4:
                  var10001 = 0.0F;
                  break;
               case 5:
                  var10001 = this.getBoundsWidth() - lineWidth;
            }
         } else {
            var10001 = 0.0F;
         }

         cursorX.element = var10001;
         line.getStartPos().set(cursorX.element, cursorY.element);
         line.setStringWidth(lineWidth);
         if (((CharSequence)lineStringWithoutCodes).length() > 0) {
            if (this.getHorizontalAlignment() == FontText.Alignment.JUSTIFY && line.getCompleted()) {
               float availableWidth = this.getBoundsWidth() - lineWidth;
               float justifySpace = availableWidth / (float)this.splitWordRuns(lineStringWithoutCodes).size();
               Iterable $this$forEach$iv = (Iterable)this.splitWordRuns(line.getString());
               int $i$f$forEach = 0;

               for(Object element$iv : $this$forEach$iv) {
                  String word = (String)element$iv;
                  int var21 = 0;
                  calculateText$lambda$8$renderChars(word, this, glyphAction, tempCursorPos, cursorX, cursorY, line);
                  cursorX.element += justifySpace;
               }
            } else {
               calculateText$lambda$8$renderChars(line.getString(), this, glyphAction, tempCursorPos, cursorX, cursorY, line);
            }
         }

         cursorY.element += lineYOffset;
      }

      $this$forEach$iv = (Iterable)this.getLines();
      Iterator var26 = $this$forEach$iv.iterator();
      if (!var26.hasNext()) {
         throw new NoSuchElementException();
      } else {
         Line it = (Line)var26.next();
         int var29 = 0;

         for(var28 = it.getStringWidth(); var26.hasNext(); var28 = Math.max(var28, var31)) {
            Line it = (Line)var26.next();
            int var32 = 0;
            var31 = it.getStringWidth();
         }

         this.contentWidth = var28;
         this.currentGlyphColor.set(-1.0F);
      }
   }

   // $FF: synthetic method
   public static void calculateText$default(FontText var0, Function3 var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = null.INSTANCE;
      }

      var0.calculateText(var1);
   }

   @NotNull
   public final List<Line> calculateLines(@NotNull String string, float lineWidth) {
      Intrinsics.checkNotNullParameter(string, "string");
      if (((CharSequence)string).length() == 0) {
         return CollectionsKt.listOf(new Line("", false));
      } else {
         List splits = this.getSplitNextLine() ? this.decodeLangNewlines(string, this.getWrap()) : CollectionsKt.listOf(string);
         List lines = (List)(new ArrayList());
         StringBuilder lineBuffer = new StringBuilder();
         float cursorX = 0.0F;
         Iterable $this$forEach$iv = (Iterable)splits;
         int $i$f$forEach = 0;

         for(Object element$iv : $this$forEach$iv) {
            String splitString = (String)element$iv;
            int var12 = 0;
            if (((CharSequence)splitString).length() == 0) {
               lines.add(new Line("\n", false));
            } else if (lineWidth <= 0.0F) {
               lines.add(new Line(splitString, false));
            } else {
               List words = this.splitWordRuns(splitString);
               Iterable $this$forEachIndexed$iv = (Iterable)words;
               int $i$f$forEachIndexed = 0;
               int index$iv = 0;

               for(Object item$iv : $this$forEachIndexed$iv) {
                  int symbol = index$iv++;
                  if (symbol < 0) {
                     CollectionsKt.throwIndexOverflow();
                  }

                  String word = (String)item$iv;
                  int var22 = 0;
                  cursorX += this.getStringWidth(word);
                  lineBuffer.append(word);
                  String var41 = (String)CollectionsKt.getOrNull(words, symbol + 1);
                  float var42;
                  if (var41 != null) {
                     String it = var41;
                     int var24 = 0;
                     var42 = this.getStringWidth(it);
                  } else {
                     var42 = 0.0F;
                  }

                  float nextWordWidth = var42;
                  if (cursorX + nextWordWidth > lineWidth || symbol == CollectionsKt.getLastIndex(words)) {
                     String var26 = ((CharSequence)lineBuffer).length() > 0 && CharsKt.isWhitespace(StringsKt.last((CharSequence)lineBuffer)) && !this.getSplitNextLineByChar() ? lineBuffer.substring(0, lineBuffer.length() - 1) : lineBuffer.toString();
                     Intrinsics.checkNotNull(var26);
                     lines.add(new Line(var26, symbol != CollectionsKt.getLastIndex(words)));
                     lineBuffer.setLength(0);
                     cursorX = 0.0F;
                  }
               }
            }
         }

         cursorX = 0.0F;
         lineBuffer.setLength(0);
         if (this.getSplitNextLineByChar() && lineWidth > 0.0F) {
            boolean recalcNeeded = false;
            StringBuilder recalcString = new StringBuilder();
            Iterable $this$forEach$iv = (Iterable)lines;
            int $i$f$forEach = 0;

            for(Object element$iv : $this$forEach$iv) {
               Line line = (Line)element$iv;
               int var35 = 0;
               String singleWord = StringsKt.trim((CharSequence)line.getString()).toString();
               if (!SPLIT_WORDS_REGEX.containsMatchIn((CharSequence)singleWord) && this.getStringWidth(singleWord) > lineWidth) {
                  recalcNeeded = true;
                  CharSequence $this$forEach$iv = (CharSequence)line.getString();
                  int $i$f$forEach = 0;

                  for(int var39 = 0; var39 < $this$forEach$iv.length(); ++var39) {
                     char element$iv = $this$forEach$iv.charAt(var39);
                     int i = 0;
                     cursorX += this.getCharWidth(element$iv);
                     if (cursorX > lineWidth - this.getCharWidth(' ')) {
                        recalcString.append(' ');
                        cursorX = 0.0F;
                     }

                     recalcString.append(element$iv);
                  }
               } else {
                  recalcString.append(line.getString());
               }
            }

            if (recalcNeeded) {
               String var10001 = recalcString.toString();
               Intrinsics.checkNotNullExpressionValue(var10001, "toString(...)");
               return this.calculateLines(var10001, lineWidth);
            }
         }

         return lines;
      }
   }

   // $FF: synthetic method
   public static List calculateLines$default(FontText var0, String var1, float var2, int var3, Object var4) {
      if ((var3 & 1) != 0) {
         var1 = var0.getContent();
      }

      if ((var3 & 2) != 0) {
         var2 = var0.getWrap() ? (float)Math.ceil((double)var0.getBoundsWidth()) : -1.0F;
      }

      return var0.calculateLines(var1, var2);
   }

   private final List<String> decodeLangNewlines(String string, boolean wrap) {
      return !wrap ? this.decodeLangNewlinesWithoutWrap(string) : this.decodeLangNewlinesWithWrap(string);
   }

   private final List<String> decodeLangNewlinesWithoutWrap(String string) {
      int n = string.length();
      StringBuilder out = new StringBuilder(n);
      int start = 0;
      int i = 0;

      while(i < n) {
         char c = string.charAt(i);
         if (c == '\n') {
            if (start < i) {
               out.append((CharSequence)string, start, i);
            }

            ++i;
            start = i;
         } else if (c == '\\' && i + 1 < n && string.charAt(i + 1) == 'n') {
            if (start < i) {
               out.append((CharSequence)string, start, i);
            }

            i += 2;
            start = i;
         } else {
            ++i;
         }
      }

      if (start == 0) {
         return CollectionsKt.listOf(string);
      } else {
         if (start < n) {
            out.append((CharSequence)string, start, n);
         }

         String var10000 = out.toString();
         Intrinsics.checkNotNullExpressionValue(var10000, "toString(...)");
         return CollectionsKt.listOf(var10000);
      }
   }

   private final List<String> decodeLangNewlinesWithWrap(String string) {
      ArrayList lines = new ArrayList(4);
      int n = string.length();
      int start = 0;
      int i = 0;

      while(i < n) {
         char c = string.charAt(i);
         if (c == '\n') {
            String var7;
            if (start < i) {
               var7 = string.substring(start, i);
               Intrinsics.checkNotNullExpressionValue(var7, "substring(...)");
            } else {
               var7 = "";
            }

            lines.add(var7);
            ++i;
            start = i;
         } else if (c == '\\' && i + 1 < n && string.charAt(i + 1) == 'n') {
            String var10001;
            if (start < i) {
               var10001 = string.substring(start, i);
               Intrinsics.checkNotNullExpressionValue(var10001, "substring(...)");
            } else {
               var10001 = "";
            }

            lines.add(var10001);
            i += 2;
            start = i;
         } else {
            ++i;
         }
      }

      if (start == 0) {
         return CollectionsKt.listOf(string);
      } else {
         String var8;
         if (start < n) {
            var8 = string.substring(start);
            Intrinsics.checkNotNullExpressionValue(var8, "substring(...)");
         } else {
            var8 = "";
         }

         lines.add(var8);
         return (List)lines;
      }
   }

   private final List<String> splitWordRuns(String s) {
      int n = s.length();
      if (n == 0) {
         return CollectionsKt.emptyList();
      } else if (n == 1) {
         return CollectionsKt.listOf(s);
      } else {
         ArrayList result = new ArrayList(8);
         int start = 0;

         for(int i = 1; i < n; ++i) {
            if (CharsKt.isWhitespace(s.charAt(i - 1)) && !CharsKt.isWhitespace(s.charAt(i))) {
               String var10001 = s.substring(start, i);
               Intrinsics.checkNotNullExpressionValue(var10001, "substring(...)");
               result.add(var10001);
               start = i;
            }
         }

         String var6 = s.substring(start, n);
         Intrinsics.checkNotNullExpressionValue(var6, "substring(...)");
         result.add(var6);
         return (List)result;
      }
   }

   public final float getStringWidth(@NotNull String string) {
      Intrinsics.checkNotNullParameter(string, "string");
      float totalWidth = 0.0F;
      String $this$forEachVisibleChar$iv = string;
      int $i$f$forEachVisibleChar = 0;
      int n$iv = string.length();
      int i$iv = 0;

      while(i$iv < n$iv) {
         int skipFormat$iv = ChatUtils.isFormatCodeAt($this$forEachVisibleChar$iv, i$iv, '§');
         if (skipFormat$iv != 0) {
            i$iv += skipFormat$iv;
         } else {
            int skipAlpha$iv = ChatUtils.isAlphaCodeAt($this$forEachVisibleChar$iv, i$iv, '¤');
            if (skipAlpha$iv != 0) {
               i$iv += skipAlpha$iv;
            } else {
               char ch = $this$forEachVisibleChar$iv.charAt(i$iv);
               int var10 = 0;
               totalWidth += this.getCharWidth(ch);
               ++i$iv;
            }
         }
      }

      return totalWidth;
   }

   // $FF: synthetic method
   public static float getStringWidth$default(FontText var0, String var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = var0.getContent();
      }

      return var0.getStringWidth(var1);
   }

   public final float getCharWidth(char var1) {
      return this.getGlyphWidth(this.getGlyph(var1));
   }

   public final float getStringHeight(@NotNull List<Line> inputLines) {
      Intrinsics.checkNotNullParameter(inputLines, "inputLines");
      return this.getStringHeight(inputLines.size());
   }

   // $FF: synthetic method
   public static float getStringHeight$default(FontText var0, List var1, int var2, Object var3) {
      if ((var2 & 1) != 0) {
         var1 = var0.getLines();
      }

      return var0.getStringHeight(var1);
   }

   public final float getStringHeight(int linesCount) {
      float var10000 = (float)linesCount;
      int $i$f$getFontHeight = 0;
      return var10000 * (float)this.getFont().getMetadata().getLineHeight() * this.getSize() * this.getLineHeight();
   }

   private final float getGlyphWidth(FontGlyph glyph) {
      return (float)glyph.getAdvance() * this.getLetterSpacing() * this.getSize();
   }

   private final FontGlyph getGlyph(char var1) {
      return this.font.getGlyph(var1);
   }

   public final void setColorARGB(int value) {
      int $i$f$getArgbRed = 0;
      int $this$argbRed$iv = value >> 16 & 255;
      $i$f$getArgbRed = 0;
      float var10001 = (float)$this$argbRed$iv / 255.0F;
      $i$f$getArgbRed = 0;
      $this$argbRed$iv = value >> 8 & 255;
      $i$f$getArgbRed = 0;
      float var10002 = (float)$this$argbRed$iv / 255.0F;
      $i$f$getArgbRed = 0;
      $this$argbRed$iv = value >> 0 & 255;
      $i$f$getArgbRed = 0;
      float var10003 = (float)$this$argbRed$iv / 255.0F;
      $i$f$getArgbRed = 0;
      $this$argbRed$iv = value >> 24 & 255;
      $i$f$getArgbRed = 0;
      this.color.set(var10001, var10002, var10003, (float)$this$argbRed$iv / 255.0F);
   }

   public final void setColorAlpha(float alpha) {
      this.color.w = alpha;
   }

   public final void setOutlineColorARGB(int value) {
      int $i$f$getArgbRed = 0;
      int $this$argbRed$iv = value >> 16 & 255;
      $i$f$getArgbRed = 0;
      float var10001 = (float)$this$argbRed$iv / 255.0F;
      $i$f$getArgbRed = 0;
      $this$argbRed$iv = value >> 8 & 255;
      $i$f$getArgbRed = 0;
      float var10002 = (float)$this$argbRed$iv / 255.0F;
      $i$f$getArgbRed = 0;
      $this$argbRed$iv = value >> 0 & 255;
      $i$f$getArgbRed = 0;
      this.outlineColor.set(var10001, var10002, (float)$this$argbRed$iv / 255.0F);
   }

   public int compareTo(@NotNull FontText other) {
      Intrinsics.checkNotNullParameter(other, "other");
      return this.font.getTexture().compareTo(other.font.getTexture());
   }

   public final boolean dispose() {
      TextBuffer var10000 = this.mesh;
      if (var10000 != null) {
         var10000.dispose();
      }

      this.mesh = null;
      this.setContent("");
      return true;
   }

   private final <T> ReadWriteProperty<Object, T> changeable(T initialValue) {
      Delegates this_$iv = Delegates.INSTANCE;
      int $i$f$observable = 0;
      return (ReadWriteProperty)(new FontText$changeable$$inlined$observable$1(initialValue, this));
   }

   public final <R> R withoutChanges(@NotNull Function1<? super FontText, ? extends R> block) {
      Intrinsics.checkNotNullParameter(block, "block");
      boolean prev = this.changed;

      Object var3;
      try {
         var3 = block.invoke(this);
      } finally {
         this.changed = prev;
      }

      return (R)var3;
   }

   @JvmOverloads
   public FontText(@NotNull Font font) {
      Intrinsics.checkNotNullParameter(font, "font");
      this(font, (String)null, 2, (DefaultConstructorMarker)null);
   }

   @JvmOverloads
   @NotNull
   public final FontText configure(@NotNull InitialData data) {
      Intrinsics.checkNotNullParameter(data, "data");
      return configure$default(this, data, (Function1)null, 2, (Object)null);
   }

   @JvmOverloads
   @NotNull
   public final FontText configure(float size, float width, float edge) {
      return configure$default(this, size, width, edge, (Function1)null, 8, (Object)null);
   }

   private static final void buildTextData$glyphMesh$addColor(TFloatArrayList colors, Vector4f $color) {
      byte var2 = 6;

      for(int var3 = 0; var3 < var2; ++var3) {
         int var5 = 0;
         colors.add($color.x);
         colors.add($color.y);
         colors.add($color.z);
         colors.add($color.w);
      }

   }

   private static final void buildTextData$glyphMesh(FontText this$0, TFloatArrayList vertices, TFloatArrayList uvs, TFloatArrayList colors, FontGlyph glyph, Vector2f position, Vector4f color) {
      if (!(glyph.getSize().x <= 0.0F) && !(glyph.getSize().y <= 0.0F)) {
         float minX = position.x + glyph.getOffset().x * this$0.getSize();
         float minY = position.y + glyph.getOffset().y * this$0.getSize();
         float maxX = minX + glyph.getSize().x * this$0.getSize();
         float maxY = minY + glyph.getSize().y * this$0.getSize();
         float minTexX = glyph.getPosition().x / this$0.font.getMetadata().getImageSize().x;
         float minTexY = glyph.getPosition().y / this$0.font.getMetadata().getImageSize().y;
         float maxTexX = minTexX + glyph.getSize().x / this$0.font.getMetadata().getImageSize().x;
         float maxTexY = minTexY + glyph.getSize().y / this$0.font.getMetadata().getImageSize().y;
         vertices.add(minX);
         vertices.add(maxY);
         vertices.add(maxX);
         vertices.add(minY);
         vertices.add(minX);
         vertices.add(minY);
         uvs.add(minTexX);
         uvs.add(maxTexY);
         uvs.add(maxTexX);
         uvs.add(minTexY);
         uvs.add(minTexX);
         uvs.add(minTexY);
         vertices.add(minX);
         vertices.add(maxY);
         vertices.add(maxX);
         vertices.add(maxY);
         vertices.add(maxX);
         vertices.add(minY);
         uvs.add(minTexX);
         uvs.add(maxTexY);
         uvs.add(maxTexX);
         uvs.add(maxTexY);
         uvs.add(maxTexX);
         uvs.add(minTexY);
         buildTextData$glyphMesh$addColor(colors, color);
      }
   }

   private static final int calculateText$lambda$8$renderChar(FontText this$0, Function3<? super FontGlyph, ? super Vector2f, ? super Vector4f, Unit> $glyphAction, Vector2f tempCursorPos, Ref.FloatRef cursorX, Ref.FloatRef cursorY, Line $line, char[] chars, int charIndex) {
      char var8 = chars[charIndex];
      if (var8 == 167 && charIndex + 1 < chars.length) {
         char formattingSymbol = chars[charIndex + 1];
         if (formattingSymbol == 'r') {
            this$0.currentGlyphColor.set(-1.0F, -1.0F, -1.0F);
            return 2;
         }

         if (IGNORED_FORMATTING_CODES.contains(formattingSymbol)) {
            return 2;
         }

         Integer it = (Integer)ChatUtils.getCHAT_COLORS_CODES().get(formattingSymbol);
         if (it != null) {
            int var12 = 0;
            Vector4f var31 = this$0.currentGlyphColor;
            int $this$argbRed$iv = it;
            int $i$f$getArgbRed = 0;
            $this$argbRed$iv = $this$argbRed$iv >> 16 & 255;
            $i$f$getArgbRed = 0;
            float var10001 = (float)$this$argbRed$iv / 255.0F;
            $this$argbRed$iv = it;
            $i$f$getArgbRed = 0;
            $this$argbRed$iv = $this$argbRed$iv >> 8 & 255;
            $i$f$getArgbRed = 0;
            float var32 = (float)$this$argbRed$iv / 255.0F;
            $this$argbRed$iv = it;
            $i$f$getArgbRed = 0;
            $this$argbRed$iv = $this$argbRed$iv >> 0 & 255;
            $i$f$getArgbRed = 0;
            var31.set(var10001, var32, (float)$this$argbRed$iv / 255.0F);
            return 2;
         }
      } else if (var8 == 164) {
         if (charIndex + 1 < chars.length && chars[charIndex + 1] == 'r') {
            this$0.currentGlyphColor.w = -1.0F;
            return 2;
         }

         if (charIndex + 3 < chars.length) {
            Integer var10000 = StringsKt.toIntOrNull(StringsKt.concatToString(chars, charIndex + 1, charIndex + 4));
            if (var10000 != null) {
               Integer it = var10000;
               int it = ((Number)it).intValue();
               int it = 0;
               this$0.currentGlyphColor.w = RangesKt.coerceIn((float)it / 255.0F, 0.0F, 1.0F);
            }

            return 4;
         }
      }

      FontGlyph glyph = this$0.getGlyph(var8);
      Vector2f var10002 = tempCursorPos.set(cursorX.element, cursorY.element);
      Intrinsics.checkNotNullExpressionValue(var10002, "set(...)");
      $glyphAction.invoke(glyph, var10002, this$0.currentGlyphColor);
      Object it = $line.getChars().get(charIndex);
      Line.LineChar it = (Line.LineChar)it;
      int var19 = 0;
      it.setX(cursorX.element);
      it.setY(cursorY.element);
      it.setW(glyph.getSize().x * this$0.getSize());
      it.setH(glyph.getSize().y * this$0.getSize());
      cursorX.element += this$0.getGlyphWidth(glyph);
      return 1;
   }

   private static final void calculateText$lambda$8$renderChars(String $this$calculateText_u24lambda_u248_u24renderChars, FontText this$0, Function3<? super FontGlyph, ? super Vector2f, ? super Vector4f, Unit> $glyphAction, Vector2f tempCursorPos, Ref.FloatRef cursorX, Ref.FloatRef cursorY, Line $line) {
      int charIndex = 0;
      char[] var10000 = $this$calculateText_u24lambda_u248_u24renderChars.toCharArray();
      Intrinsics.checkNotNullExpressionValue(var10000, "toCharArray(...)");

      for(char[] lineChars = var10000; charIndex < lineChars.length; charIndex += calculateText$lambda$8$renderChar(this$0, $glyphAction, tempCursorPos, cursorX, cursorY, $line, lineChars, charIndex)) {
      }

   }

   // $FF: synthetic method
   public static final void access$setChanged$p(FontText $this, boolean var1) {
      $this.changed = var1;
   }

   static {
      KProperty[] var0 = new KProperty[]{Reflection.mutableProperty1((MutablePropertyReference1)(new MutablePropertyReference1Impl(FontText.class, "size", "getSize()F", 0))), Reflection.mutableProperty1((MutablePropertyReference1)(new MutablePropertyReference1Impl(FontText.class, "content", "getContent()Ljava/lang/String;", 0))), Reflection.mutableProperty1((MutablePropertyReference1)(new MutablePropertyReference1Impl(FontText.class, "letterSpacing", "getLetterSpacing()F", 0))), Reflection.mutableProperty1((MutablePropertyReference1)(new MutablePropertyReference1Impl(FontText.class, "lineHeight", "getLineHeight()F", 0))), Reflection.mutableProperty1((MutablePropertyReference1)(new MutablePropertyReference1Impl(FontText.class, "horizontalAlignment", "getHorizontalAlignment()Lloliland/graphics/renderer/font/FontText$Alignment;", 0))), Reflection.mutableProperty1((MutablePropertyReference1)(new MutablePropertyReference1Impl(FontText.class, "verticalAlignment", "getVerticalAlignment()Lloliland/graphics/renderer/font/FontText$Alignment;", 0))), Reflection.mutableProperty1((MutablePropertyReference1)(new MutablePropertyReference1Impl(FontText.class, "bounds", "getBounds()Lorg/lwjgl/util/ReadableDimension;", 0))), Reflection.mutableProperty1((MutablePropertyReference1)(new MutablePropertyReference1Impl(FontText.class, "boundsF", "getBoundsF()Lloliland/graphics/renderer/font/FontText$Bounds;", 0))), Reflection.mutableProperty1((MutablePropertyReference1)(new MutablePropertyReference1Impl(FontText.class, "splitNextLine", "getSplitNextLine()Z", 0))), Reflection.mutableProperty1((MutablePropertyReference1)(new MutablePropertyReference1Impl(FontText.class, "splitNextLineByChar", "getSplitNextLineByChar()Z", 0))), Reflection.mutableProperty1((MutablePropertyReference1)(new MutablePropertyReference1Impl(FontText.class, "wrap", "getWrap()Z", 0))), Reflection.mutableProperty1((MutablePropertyReference1)(new MutablePropertyReference1Impl(FontText.class, "centerOffsetX", "getCenterOffsetX()F", 0))), Reflection.mutableProperty1((MutablePropertyReference1)(new MutablePropertyReference1Impl(FontText.class, "centerOffsetY", "getCenterOffsetY()F", 0)))};
      $$delegatedProperties = var0;
      Companion = new Companion((DefaultConstructorMarker)null);
      SPLIT_WORDS_REGEX = new Regex("(?<=\\s)(?!\\s)");
      buffer = BufferUtils.createFloatBuffer(49152);
      modelViewMatrixBuffer = BufferUtils.createFloatBuffer(16);
      projectionMatrixBuffer = BufferUtils.createFloatBuffer(16);
      Character[] var1 = new Character[]{'k', 'l', 'm', 'n', 'o'};
      IGNORED_FORMATTING_CODES = SetsKt.setOf(var1);
   }

   @Metadata(
      mv = {1, 9, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0007\n\u0002\b\b\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003¢\u0006\u0002\u0010\u0006R\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\b¨\u0006\u000b"},
      d2 = {"Lloliland/graphics/renderer/font/FontText$InitialData;", "", "size", "", "width", "edge", "(FFF)V", "getEdge", "()F", "getSize", "getWidth", "loligraphics-1.7.10"}
   )
   public static final class InitialData {
      private final float size;
      private final float width;
      private final float edge;

      public InitialData(float size, float width, float edge) {
         this.size = size;
         this.width = width;
         this.edge = edge;
      }

      public final float getSize() {
         return this.size;
      }

      public final float getWidth() {
         return this.width;
      }

      public final float getEdge() {
         return this.edge;
      }
   }

   @Metadata(
      mv = {1, 9, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0014\n\u0002\b\u0007\n\u0002\u0010\b\n\u0002\b\u0004\b\u0002\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003¢\u0006\u0002\u0010\u0006R\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\bR\u0011\u0010\n\u001a\u00020\u000b8F¢\u0006\u0006\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\b¨\u0006\u000f"},
      d2 = {"Lloliland/graphics/renderer/font/FontText$TextData;", "", "vertices", "", "uvs", "colors", "([F[F[F)V", "getColors", "()[F", "getUvs", "vertexCount", "", "getVertexCount", "()I", "getVertices", "loligraphics-1.7.10"}
   )
   private static final class TextData {
      @NotNull
      private final float[] vertices;
      @NotNull
      private final float[] uvs;
      @NotNull
      private final float[] colors;

      public TextData(@NotNull float[] vertices, @NotNull float[] uvs, @NotNull float[] colors) {
         Intrinsics.checkNotNullParameter(vertices, "vertices");
         Intrinsics.checkNotNullParameter(uvs, "uvs");
         Intrinsics.checkNotNullParameter(colors, "colors");
         super();
         this.vertices = vertices;
         this.uvs = uvs;
         this.colors = colors;
      }

      @NotNull
      public final float[] getVertices() {
         return this.vertices;
      }

      @NotNull
      public final float[] getUvs() {
         return this.uvs;
      }

      @NotNull
      public final float[] getColors() {
         return this.colors;
      }

      public final int getVertexCount() {
         return this.vertices.length / 2;
      }
   }

   @Metadata(
      mv = {1, 9, 0},
      k = 1,
      xi = 48,
      d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u0007\n\u0002\b\u0006\u0018\u00002\u00020\u0001:\u0001 B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006R!\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\t0\b8FX\u0086\u0084\u0002¢\u0006\f\n\u0004\b\f\u0010\r\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\u0010\u001a\u00020\u00118F¢\u0006\u0006\u001a\u0004\b\u0012\u0010\u0013R\u001a\u0010\u0014\u001a\u00020\u0011X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0015\u0010\u0013\"\u0004\b\u0016\u0010\u0017R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u001a\u0010\u001a\u001a\u00020\u001bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001c\u0010\u001d\"\u0004\b\u001e\u0010\u001f¨\u0006!"},
      d2 = {"Lloliland/graphics/renderer/font/FontText$Line;", "", "string", "", "completed", "", "(Ljava/lang/String;Z)V", "chars", "", "Lloliland/graphics/renderer/font/FontText$Line$LineChar;", "getChars", "()Ljava/util/List;", "chars$delegate", "Lkotlin/Lazy;", "getCompleted", "()Z", "lastCharPos", "Lorg/joml/Vector2f;", "getLastCharPos", "()Lorg/joml/Vector2f;", "startPos", "getStartPos", "setStartPos", "(Lorg/joml/Vector2f;)V", "getString", "()Ljava/lang/String;", "stringWidth", "", "getStringWidth", "()F", "setStringWidth", "(F)V", "LineChar", "loligraphics-1.7.10"}
   )
   public static final class Line {
      @NotNull
      private final String string;
      private final boolean completed;
      @NotNull
      private final Lazy chars$delegate;
      @NotNull
      private Vector2f startPos;
      private float stringWidth;

      public Line(@NotNull String string, boolean completed) {
         Intrinsics.checkNotNullParameter(string, "string");
         super();
         this.string = string;
         this.completed = completed;
         this.chars$delegate = LazyKt.lazy(LazyThreadSafetyMode.NONE, new Function0<ArrayList<LineChar>>() {
            @NotNull
            public final ArrayList<LineChar> invoke() {
               int n = Line.this.getString().length();
               ArrayList var2 = new ArrayList(n);
               Line var3 = Line.this;
               ArrayList $this$invoke_u24lambda_u240 = var2;
               int var5 = 0;

               for(int i = 0; i < n; ++i) {
                  $this$invoke_u24lambda_u240.add(new LineChar(var3.getString().charAt(i), 0.0F, 0.0F, 0.0F, 0.0F, 30, (DefaultConstructorMarker)null));
               }

               return var2;
            }
         });
         this.startPos = new Vector2f();
      }

      @NotNull
      public final String getString() {
         return this.string;
      }

      public final boolean getCompleted() {
         return this.completed;
      }

      @NotNull
      public final List<LineChar> getChars() {
         Lazy var1 = this.chars$delegate;
         return (List)var1.getValue();
      }

      @NotNull
      public final Vector2f getStartPos() {
         return this.startPos;
      }

      public final void setStartPos(@NotNull Vector2f var1) {
         Intrinsics.checkNotNullParameter(var1, "<set-?>");
         this.startPos = var1;
      }

      public final float getStringWidth() {
         return this.stringWidth;
      }

      public final void setStringWidth(float var1) {
         this.stringWidth = var1;
      }

      @NotNull
      public final Vector2f getLastCharPos() {
         Vector2f var10000;
         if (((CharSequence)this.string).length() > 0) {
            LineChar lastChar = (LineChar)CollectionsKt.last(this.getChars());
            var10000 = new Vector2f(lastChar.getX() + lastChar.getW() + 1.0F, lastChar.getY());
         } else {
            var10000 = this.startPos;
         }

         return var10000;
      }

      @Metadata(
         mv = {1, 9, 0},
         k = 1,
         xi = 48,
         d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\f\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0011\u0018\u00002\u00020\u0001B5\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0005\u0012\b\b\u0002\u0010\b\u001a\u00020\u0005¢\u0006\u0002\u0010\tR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u001a\u0010\b\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\r\"\u0004\b\u000e\u0010\u000fR\u001a\u0010\u0007\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\r\"\u0004\b\u0011\u0010\u000fR\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\r\"\u0004\b\u0013\u0010\u000fR\u001a\u0010\u0006\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0014\u0010\r\"\u0004\b\u0015\u0010\u000f¨\u0006\u0016"},
         d2 = {"Lloliland/graphics/renderer/font/FontText$Line$LineChar;", "", "char", "", "x", "", "y", "w", "h", "(CFFFF)V", "getChar", "()C", "getH", "()F", "setH", "(F)V", "getW", "setW", "getX", "setX", "getY", "setY", "loligraphics-1.7.10"}
      )
      public static final class LineChar {
         private final char char;
         private float x;
         private float y;
         private float w;
         private float h;

         public LineChar(char var1, float x, float y, float w, float h) {
            this.char = var1;
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
         }

         // $FF: synthetic method
         public LineChar(char var1, float var2, float var3, float var4, float var5, int var6, DefaultConstructorMarker var7) {
            if ((var6 & 2) != 0) {
               var2 = 0.0F;
            }

            if ((var6 & 4) != 0) {
               var3 = 0.0F;
            }

            if ((var6 & 8) != 0) {
               var4 = 0.0F;
            }

            if ((var6 & 16) != 0) {
               var5 = 0.0F;
            }

            this(var1, var2, var3, var4, var5);
         }

         public final char getChar() {
            return this.char;
         }

         public final float getX() {
            return this.x;
         }

         public final void setX(float var1) {
            this.x = var1;
         }

         public final float getY() {
            return this.y;
         }

         public final void setY(float var1) {
            this.y = var1;
         }

         public final float getW() {
            return this.w;
         }

         public final void setW(float var1) {
            this.w = var1;
         }

         public final float getH() {
            return this.h;
         }

         public final void setH(float var1) {
            this.h = var1;
         }
      }
   }

   @Metadata(
      mv = {1, 9, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\b\"\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\t\u001a\u00020\nH&J\b\u0010\u000b\u001a\u00020\nH&J\b\u0010\f\u001a\u00020\nH&J\b\u0010\r\u001a\u00020\nH&J\u0010\u0010\u000e\u001a\u00020\n2\u0006\u0010\u000f\u001a\u00020\u0010H&R\u001a\u0010\u0003\u001a\u00020\u0004X\u0084\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\b¨\u0006\u0011"},
      d2 = {"Lloliland/graphics/renderer/font/FontText$TextBuffer;", "", "()V", "vertexCount", "", "getVertexCount", "()I", "setVertexCount", "(I)V", "bind", "", "dispose", "draw", "unbind", "update", "text", "Lloliland/graphics/renderer/font/FontText$TextData;", "loligraphics-1.7.10"}
   )
   private abstract static class TextBuffer {
      private int vertexCount;

      public TextBuffer() {
      }

      protected final int getVertexCount() {
         return this.vertexCount;
      }

      protected final void setVertexCount(int var1) {
         this.vertexCount = var1;
      }

      public abstract void update(@NotNull TextData var1);

      public abstract void bind();

      public abstract void draw();

      public abstract void unbind();

      public abstract void dispose();
   }

   @Metadata(
      mv = {1, 9, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\b\u0002\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\b\u0010\u0007\u001a\u00020\bH\u0016J\b\u0010\t\u001a\u00020\bH\u0016J\b\u0010\n\u001a\u00020\bH\u0016J\b\u0010\u000b\u001a\u00020\bH\u0016J\u0010\u0010\f\u001a\u00020\b2\u0006\u0010\u0002\u001a\u00020\u0003H\u0016R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\r"},
      d2 = {"Lloliland/graphics/renderer/font/FontText$TextBufferVAO;", "Lloliland/graphics/renderer/font/FontText$TextBuffer;", "text", "Lloliland/graphics/renderer/font/FontText$TextData;", "(Lloliland/graphics/renderer/font/FontText$TextData;)V", "vao", "Lloliland/graphics/renderer/VAO;", "bind", "", "dispose", "draw", "unbind", "update", "loligraphics-1.7.10"}
   )
   private static final class TextBufferVAO extends TextBuffer {
      @NotNull
      private final VAO vao;

      public TextBufferVAO(@NotNull TextData text) {
         Intrinsics.checkNotNullParameter(text, "text");
         super();
         this.vao = new VAO(0, 1, (DefaultConstructorMarker)null);
         this.setVertexCount(text.getVertexCount());
         VAO $this$_init__u24lambda_u240 = this.vao;
         int var4 = 0;
         $this$_init__u24lambda_u240.bind();
         $this$_init__u24lambda_u240.createAttribute(0, FontText.Companion.copyToBuffer(text.getVertices()), 2, GLCompatible.GL_DYNAMIC_DRAW);
         $this$_init__u24lambda_u240.createAttribute(1, FontText.Companion.copyToBuffer(text.getUvs()), 2, GLCompatible.GL_DYNAMIC_DRAW);
         $this$_init__u24lambda_u240.createAttribute(2, FontText.Companion.copyToBuffer(text.getColors()), 4, GLCompatible.GL_DYNAMIC_DRAW);
         $this$_init__u24lambda_u240.unbind();
      }

      public void update(@NotNull TextData text) {
         Intrinsics.checkNotNullParameter(text, "text");
         this.setVertexCount(text.getVertexCount());
         VAO $this$update_u24lambda_u244 = this.vao;
         int var4 = 0;
         $this$update_u24lambda_u244.bind();
         VBO $this$update_u24lambda_u244_u24lambda_u241 = $this$update_u24lambda_u244.attribute(0);
         int var7 = 0;
         $this$update_u24lambda_u244_u24lambda_u241.bind();
         $this$update_u24lambda_u244_u24lambda_u241.bufferData((long)text.getVertices().length << 2);
         VBO.bufferSubData$default($this$update_u24lambda_u244_u24lambda_u241, (FloatBuffer)FontText.Companion.copyToBuffer(text.getVertices()), 0L, 2, (Object)null);
         $this$update_u24lambda_u244_u24lambda_u241.unbind();
         $this$update_u24lambda_u244_u24lambda_u241 = $this$update_u24lambda_u244.attribute(1);
         var7 = 0;
         $this$update_u24lambda_u244_u24lambda_u241.bind();
         $this$update_u24lambda_u244_u24lambda_u241.bufferData((long)text.getUvs().length << 2);
         VBO.bufferSubData$default($this$update_u24lambda_u244_u24lambda_u241, (FloatBuffer)FontText.Companion.copyToBuffer(text.getUvs()), 0L, 2, (Object)null);
         $this$update_u24lambda_u244_u24lambda_u241.unbind();
         $this$update_u24lambda_u244_u24lambda_u241 = $this$update_u24lambda_u244.attribute(2);
         var7 = 0;
         $this$update_u24lambda_u244_u24lambda_u241.bind();
         $this$update_u24lambda_u244_u24lambda_u241.bufferData((long)text.getColors().length << 2);
         VBO.bufferSubData$default($this$update_u24lambda_u244_u24lambda_u241, (FloatBuffer)FontText.Companion.copyToBuffer(text.getColors()), 0L, 2, (Object)null);
         $this$update_u24lambda_u244_u24lambda_u241.unbind();
         $this$update_u24lambda_u244.unbind();
      }

      public void bind() {
         this.vao.bind();
      }

      public void draw() {
         GL11.glDrawArrays(4, 0, this.getVertexCount());
      }

      public void unbind() {
         this.vao.unbind();
      }

      public void dispose() {
         this.vao.dispose();
      }
   }

   @Metadata(
      mv = {1, 9, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0004\b\"\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u0006\u0010\u0012\u001a\u00020\u0013J\u0006\u0010\u0014\u001a\u00020\u0013J\u0006\u0010\u0015\u001a\u00020\u0013J\u000e\u0010\u0016\u001a\u00020\u00132\u0006\u0010\u0002\u001a\u00020\u0003R\u001a\u0010\u0005\u001a\u00020\u0006X\u0084\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0007\u0010\b\"\u0004\b\t\u0010\nR\u001a\u0010\u000b\u001a\u00020\u0006X\u0084\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\b\"\u0004\b\r\u0010\nR\u0014\u0010\u000e\u001a\u00020\u000fX\u0084\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011¨\u0006\u0017"},
      d2 = {"Lloliland/graphics/renderer/font/FontText$TextAbstractBufferVBO;", "Lloliland/graphics/renderer/font/FontText$TextBuffer;", "text", "Lloliland/graphics/renderer/font/FontText$TextData;", "(Lloliland/graphics/renderer/font/FontText$TextData;)V", "colorsOffset", "", "getColorsOffset", "()J", "setColorsOffset", "(J)V", "uvsOffset", "getUvsOffset", "setUvsOffset", "vbo", "Lloliland/graphics/renderer/VBO;", "getVbo", "()Lloliland/graphics/renderer/VBO;", "bind", "", "dispose", "unbind", "update", "loligraphics-1.7.10"}
   )
   private abstract static class TextAbstractBufferVBO extends TextBuffer {
      @NotNull
      private final VBO vbo;
      private long uvsOffset;
      private long colorsOffset;

      public TextAbstractBufferVBO(@NotNull TextData text) {
         Intrinsics.checkNotNullParameter(text, "text");
         super();
         this.vbo = new VBO(0, GLCompatible.GL_ARRAY_BUFFER, GLCompatible.GL_DYNAMIC_DRAW, 1, (DefaultConstructorMarker)null);
         this.update(text);
      }

      @NotNull
      protected final VBO getVbo() {
         return this.vbo;
      }

      protected final long getUvsOffset() {
         return this.uvsOffset;
      }

      protected final void setUvsOffset(long var1) {
         this.uvsOffset = var1;
      }

      protected final long getColorsOffset() {
         return this.colorsOffset;
      }

      protected final void setColorsOffset(long var1) {
         this.colorsOffset = var1;
      }

      public final void update(@NotNull TextData text) {
         Intrinsics.checkNotNullParameter(text, "text");
         this.setVertexCount(text.getVertexCount());
         if (this.getVertexCount() != 0) {
            this.uvsOffset = (long)(text.getVertices().length * 4);
            this.colorsOffset = this.uvsOffset + (long)(text.getUvs().length * 4);
            VBO $this$update_u24lambda_u240 = this.vbo;
            int var4 = 0;
            $this$update_u24lambda_u240.bind();
            this.vbo.bufferData(FontText.Companion.copyToBuffer(text));
            $this$update_u24lambda_u240.unbind();
         }
      }

      public final void bind() {
         this.vbo.bind();
      }

      public final void unbind() {
         this.vbo.unbind();
      }

      public final void dispose() {
         this.vbo.dispose();
      }
   }

   @Metadata(
      mv = {1, 9, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\b\u0002\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\b\u0010\u0005\u001a\u00020\u0006H\u0016¨\u0006\u0007"},
      d2 = {"Lloliland/graphics/renderer/font/FontText$TextBufferVBO;", "Lloliland/graphics/renderer/font/FontText$TextAbstractBufferVBO;", "text", "Lloliland/graphics/renderer/font/FontText$TextData;", "(Lloliland/graphics/renderer/font/FontText$TextData;)V", "draw", "", "loligraphics-1.7.10"}
   )
   private static final class TextBufferVBO extends TextAbstractBufferVBO {
      public TextBufferVBO(@NotNull TextData text) {
         Intrinsics.checkNotNullParameter(text, "text");
         super(text);
      }

      public void draw() {
         if (this.getVertexCount() != 0) {
            GLCompatible.vertexAttribPointer(0, 2, 5126, false, 8, 0L);
            GLCompatible.enableVertexAttribArray(0);
            GLCompatible.vertexAttribPointer(1, 2, 5126, false, 8, this.getUvsOffset());
            GLCompatible.enableVertexAttribArray(1);
            GLCompatible.vertexAttribPointer(2, 4, 5126, false, 16, this.getColorsOffset());
            GLCompatible.enableVertexAttribArray(2);
            GL11.glDrawArrays(4, 0, this.getVertexCount());
            GLCompatible.disableVertexAttribArray(0);
            GLCompatible.disableVertexAttribArray(1);
            GLCompatible.disableVertexAttribArray(2);
         }
      }
   }

   @Metadata(
      mv = {1, 9, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\b\u0002\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\b\u0010\u0005\u001a\u00020\u0006H\u0016¨\u0006\u0007"},
      d2 = {"Lloliland/graphics/renderer/font/FontText$TextBufferSuperLegacyVBO;", "Lloliland/graphics/renderer/font/FontText$TextAbstractBufferVBO;", "text", "Lloliland/graphics/renderer/font/FontText$TextData;", "(Lloliland/graphics/renderer/font/FontText$TextData;)V", "draw", "", "loligraphics-1.7.10"}
   )
   private static final class TextBufferSuperLegacyVBO extends TextAbstractBufferVBO {
      public TextBufferSuperLegacyVBO(@NotNull TextData text) {
         Intrinsics.checkNotNullParameter(text, "text");
         super(text);
      }

      public void draw() {
         if (this.getVertexCount() != 0) {
            GL11.glVertexPointer(2, 5126, 8, 0L);
            GL11.glEnableClientState(32884);
            GL11.glTexCoordPointer(2, 5126, 8, this.getUvsOffset());
            GL11.glEnableClientState(32888);
            GL11.glColorPointer(4, 5126, 16, this.getColorsOffset());
            GL11.glEnableClientState(32886);
            GL11.glDrawArrays(4, 0, this.getVertexCount());
            GL11.glDisableClientState(32884);
            GL11.glDisableClientState(32888);
            GL11.glDisableClientState(32886);
         }
      }
   }

   @Metadata(
      mv = {1, 9, 0},
      k = 1,
      xi = 48,
      d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\"\n\u0002\u0010\f\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0014\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0011\u001a\u00020\r2\u0006\u0010\u0012\u001a\u00020\u0013H\u0002J\u0010\u0010\u0011\u001a\u00020\r2\u0006\u0010\u0012\u001a\u00020\u0014H\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u0014\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\t0\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\f\u001a\n \u000e*\u0004\u0018\u00010\r0\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u0016\u0010\u000f\u001a\n \u000e*\u0004\u0018\u00010\r0\rX\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u0010\u001a\n \u000e*\u0004\u0018\u00010\r0\rX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0015"},
      d2 = {"Lloliland/graphics/renderer/font/FontText$Companion;", "", "()V", "ATTRIBUTE_COLORS", "", "ATTRIBUTE_UVS", "ATTRIBUTE_VERTICES", "IGNORED_FORMATTING_CODES", "", "", "SPLIT_WORDS_REGEX", "Lkotlin/text/Regex;", "buffer", "Ljava/nio/FloatBuffer;", "kotlin.jvm.PlatformType", "modelViewMatrixBuffer", "projectionMatrixBuffer", "copyToBuffer", "data", "", "Lloliland/graphics/renderer/font/FontText$TextData;", "loligraphics-1.7.10"}
   )
   public static final class Companion {
      private Companion() {
      }

      private final FloatBuffer copyToBuffer(float[] data) {
         if (FontText.buffer.capacity() < data.length) {
            FontText.buffer = BufferUtils.createFloatBuffer(data.length);
         } else {
            FontText.buffer.clear();
         }

         FontText.buffer.put(data);
         FontText.buffer.position(0).limit(data.length);
         FloatBuffer var10000 = FontText.buffer;
         Intrinsics.checkNotNullExpressionValue(var10000, "access$getBuffer$cp(...)");
         return var10000;
      }

      private final FloatBuffer copyToBuffer(TextData data) {
         int size = data.getVertices().length + data.getUvs().length + data.getColors().length;
         if (FontText.buffer.capacity() < size) {
            FontText.buffer = BufferUtils.createFloatBuffer(size);
         } else {
            FontText.buffer.clear();
         }

         FontText.buffer.put(data.getVertices());
         FontText.buffer.put(data.getUvs());
         FontText.buffer.put(data.getColors());
         FontText.buffer.position(0).limit(size);
         FloatBuffer var10000 = FontText.buffer;
         Intrinsics.checkNotNullExpressionValue(var10000, "access$getBuffer$cp(...)");
         return var10000;
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }

   @Metadata(
      mv = {1, 9, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\b\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007j\u0002\b\b¨\u0006\t"},
      d2 = {"Lloliland/graphics/renderer/font/FontText$Alignment;", "", "(Ljava/lang/String;I)V", "TOP", "LEFT", "CENTER", "RIGHT", "BOTTOM", "JUSTIFY", "loligraphics-1.7.10"}
   )
   public static enum Alignment {
      TOP,
      LEFT,
      CENTER,
      RIGHT,
      BOTTOM,
      JUSTIFY;

      // $FF: synthetic field
      private static final EnumEntries $ENTRIES = EnumEntriesKt.enumEntries($VALUES);

      @NotNull
      public static EnumEntries<Alignment> getEntries() {
         return $ENTRIES;
      }

      // $FF: synthetic method
      private static final Alignment[] $values() {
         Alignment[] var0 = new Alignment[]{TOP, LEFT, CENTER, RIGHT, BOTTOM, JUSTIFY};
         return var0;
      }
   }

   @Metadata(
      mv = {1, 9, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0007\n\u0002\b\t\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0002\u0010\u0005J\t\u0010\t\u001a\u00020\u0003HÆ\u0003J\t\u0010\n\u001a\u00020\u0003HÆ\u0003J\u001d\u0010\u000b\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\f\u001a\u00020\r2\b\u0010\u000e\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u000f\u001a\u00020\u0010HÖ\u0001J\t\u0010\u0011\u001a\u00020\u0012HÖ\u0001R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\u0007¨\u0006\u0013"},
      d2 = {"Lloliland/graphics/renderer/font/FontText$Bounds;", "", "width", "", "height", "(FF)V", "getHeight", "()F", "getWidth", "component1", "component2", "copy", "equals", "", "other", "hashCode", "", "toString", "", "loligraphics-1.7.10"}
   )
   public static final class Bounds {
      private final float width;
      private final float height;

      public Bounds(float width, float height) {
         this.width = width;
         this.height = height;
      }

      public final float getWidth() {
         return this.width;
      }

      public final float getHeight() {
         return this.height;
      }

      public final float component1() {
         return this.width;
      }

      public final float component2() {
         return this.height;
      }

      @NotNull
      public final Bounds copy(float width, float height) {
         return new Bounds(width, height);
      }

      // $FF: synthetic method
      public static Bounds copy$default(Bounds var0, float var1, float var2, int var3, Object var4) {
         if ((var3 & 1) != 0) {
            var1 = var0.width;
         }

         if ((var3 & 2) != 0) {
            var2 = var0.height;
         }

         return var0.copy(var1, var2);
      }

      @NotNull
      public String toString() {
         return "Bounds(width=" + this.width + ", height=" + this.height + ')';
      }

      public int hashCode() {
         int result = Float.hashCode(this.width);
         result = result * 31 + Float.hashCode(this.height);
         return result;
      }

      public boolean equals(@Nullable Object other) {
         if (this == other) {
            return true;
         } else if (!(other instanceof Bounds)) {
            return false;
         } else {
            Bounds var2 = (Bounds)other;
            if (Float.compare(this.width, var2.width) != 0) {
               return false;
            } else {
               return Float.compare(this.height, var2.height) == 0;
            }
         }
      }
   }

   // $FF: synthetic class
   @Metadata(
      mv = {1, 9, 0},
      k = 3,
      xi = 48
   )
   public class WhenMappings {
      // $FF: synthetic field
      public static final int[] $EnumSwitchMapping$0;
      // $FF: synthetic field
      public static final int[] $EnumSwitchMapping$1;

      static {
         int[] var0 = new int[FontRenderMode.Buffer.values().length];

         try {
            var0[FontRenderMode.Buffer.VAO.ordinal()] = 1;
         } catch (NoSuchFieldError var9) {
         }

         try {
            var0[FontRenderMode.Buffer.VBO.ordinal()] = 2;
         } catch (NoSuchFieldError var8) {
         }

         try {
            var0[FontRenderMode.Buffer.SUPER_LEGACY.ordinal()] = 3;
         } catch (NoSuchFieldError var7) {
         }

         $EnumSwitchMapping$0 = var0;
         var0 = new int[FontText.Alignment.values().length];

         try {
            var0[FontText.Alignment.TOP.ordinal()] = 1;
         } catch (NoSuchFieldError var6) {
         }

         try {
            var0[FontText.Alignment.CENTER.ordinal()] = 2;
         } catch (NoSuchFieldError var5) {
         }

         try {
            var0[FontText.Alignment.BOTTOM.ordinal()] = 3;
         } catch (NoSuchFieldError var4) {
         }

         try {
            var0[FontText.Alignment.LEFT.ordinal()] = 4;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[FontText.Alignment.RIGHT.ordinal()] = 5;
         } catch (NoSuchFieldError var2) {
         }

         $EnumSwitchMapping$1 = var0;
      }
   }
}

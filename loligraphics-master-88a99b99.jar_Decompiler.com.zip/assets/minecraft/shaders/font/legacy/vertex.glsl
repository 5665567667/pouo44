#version 120

attribute vec2 vertex;
attribute vec2 textureCoords;
attribute vec4 vertexColor;

varying vec2 pass_textureCoords;
varying vec4 pass_vertexColor;

uniform vec3 position;

void main() {
    vec4 transformedVertex = vec4(vec3(vertex, 0.0) + position, 1.0);
    gl_Position = gl_ModelViewProjectionMatrix * transformedVertex;
    pass_textureCoords = textureCoords;
    pass_vertexColor = vertexColor;
}
package loliland.graphics.renderer.texture;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.Charset;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.io.CloseableKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.ranges.RangesKt;
import kotlin.text.Charsets;
import loliland.graphics.renderer.texture.png.PNGDecoder;
import loliland.graphics.util.MPPUtils;
import loliland.graphics.util.ResourceExtensionsKt;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.util.ResourceLocation;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.lwjglx.opengl.GL11;
import org.lwjglx.opengl.GL30;

@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B>\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007\u0012\u001b\b\u0002\u0010\b\u001a\u0015\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\n\u0018\u00010\t¢\u0006\u0002\b\u000b¢\u0006\u0002\u0010\fJ\b\u0010\r\u001a\u00020\nH\u0016R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R!\u0010\b\u001a\u0015\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\n\u0018\u00010\t¢\u0006\u0002\b\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000e"},
   d2 = {"Lloliland/graphics/renderer/texture/SimpleTexture;", "Lloliland/graphics/renderer/texture/Texture;", "location", "Lnet/minecraft/util/ResourceLocation;", "mipmapLevel", "", "anisotropic", "", "configure", "Lkotlin/Function1;", "", "Lkotlin/ExtensionFunctionType;", "(Lnet/minecraft/util/ResourceLocation;IFLkotlin/jvm/functions/Function1;)V", "load", "loligraphics-1.7.10"}
)
@SourceDebugExtension({"SMAP\nSimpleTexture.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SimpleTexture.kt\nloliland/graphics/renderer/texture/SimpleTexture\n+ 2 ResourceExtensions.kt\nloliland/graphics/util/ResourceExtensionsKt\n*L\n1#1,90:1\n30#2:91\n*S KotlinDebug\n*F\n+ 1 SimpleTexture.kt\nloliland/graphics/renderer/texture/SimpleTexture\n*L\n27#1:91\n*E\n"})
public final class SimpleTexture extends Texture {
   private final int mipmapLevel;
   private final float anisotropic;
   @Nullable
   private final Function1<Integer, Unit> configure;

   public SimpleTexture(@NotNull ResourceLocation location, int mipmapLevel, float anisotropic, @Nullable Function1<? super Integer, Unit> configure) {
      Intrinsics.checkNotNullParameter(location, "location");
      super(location);
      this.mipmapLevel = mipmapLevel;
      this.anisotropic = anisotropic;
      this.configure = configure;
   }

   // $FF: synthetic method
   public SimpleTexture(ResourceLocation var1, int var2, float var3, Function1 var4, int var5, DefaultConstructorMarker var6) {
      if ((var5 & 2) != 0) {
         var2 = 0;
      }

      if ((var5 & 4) != 0) {
         var3 = 1.0F;
      }

      if ((var5 & 8) != 0) {
         var4 = null;
      }

      this(var1, var2, var3, var4);
   }

   public void load() {
      ResourceLocation $this$addPath$iv = this.getLocation();
      String path$iv = ".meta";
      int $i$f$addPath = 0;
      ResourceLocation metaLocation = new ResourceLocation($this$addPath$iv.func_110624_b(), $this$addPath$iv.func_110623_a() + path$iv);

      try {
         InputStream var30 = ResourceExtensionsKt.inputStream(metaLocation);
         Charset _ = Charsets.UTF_8;
         Reader var5 = (Reader)(new InputStreamReader(var30, _));
         int var6 = 8192;
         Closeable var31 = (Closeable)(var5 instanceof BufferedReader ? (BufferedReader)var5 : new BufferedReader(var5, var6));
         Throwable wrap = null;

         try {
            BufferedReader it = (BufferedReader)var31;
            var6 = 0;
            var37 = (new JsonParser()).parse((Reader)it).getAsJsonObject();
         } catch (Throwable var23) {
            wrap = var23;
            throw var23;
         } finally {
            CloseableKt.closeFinally(var31, wrap);
         }

         filter = var37;
      } catch (FileNotFoundException var25) {
         filter = null;
      }

      String var43;
      label326: {
         meta = filter;
         if (filter != null) {
            JsonElement var10000 = filter.get("filter");
            if (var10000 != null) {
               var43 = var10000.getAsString();
               break label326;
            }
         }

         var43 = null;
      }

      label320: {
         filter = Intrinsics.areEqual(var43, "nearest") ? 9728 : 9729;
         if (meta != null) {
            JsonElement var44 = meta.get("wrap");
            if (var44 != null) {
               var43 = var44.getAsString();
               break label320;
            }
         }

         var43 = null;
      }

      label314: {
         $i$f$addPath = Intrinsics.areEqual(var43, "repeat") ? 10497 : '脯';
         if (meta != null) {
            JsonElement var46 = meta.get("anisotropic");
            if (var46 != null) {
               var47 = var46.getAsFloat();
               break label314;
            }
         }

         var47 = this.anisotropic;
      }

      float anisotropic;
      label309: {
         anisotropic = var47;
         if (meta != null) {
            JsonElement var48 = meta.get("mipmap");
            if (var48 != null) {
               var49 = var48.getAsInt();
               break label309;
            }
         }

         var49 = this.mipmapLevel;
      }

      int mipmap = var49;
      Closeable var7 = (Closeable)ResourceExtensionsKt.inputStream(this.getLocation());
      Throwable var8 = null;

      try {
         InputStream stream = (InputStream)var7;
         int var10 = 0;
         TextureManager.TextureData textureData = MPPUtils.LOADED ? MPPUtils.loadTexture(stream) : TextureManager.decodeTexture$default(TextureManager.INSTANCE, new PNGDecoder(stream), (PNGDecoder.Format)null, 2, (Object)null);
         this.setWidth(textureData.getWidth());
         this.setHeight(textureData.getHeight());
         this.setId(GL11.glGenTextures());
         GL11.glBindTexture(3553, this.getId());
         GL11.glTexImage2D(3553, 0, 6408, this.getWidth(), this.getHeight(), 0, 32993, 33639, textureData.getPixels());
         if (mipmap > 0) {
            int mipmapFilter = filter == 9729 ? 9987 : 9984;
            GL11.glTexParameterf(3553, 34049, 0.0F);
            GL11.glTexParameteri(3553, 10241, mipmapFilter);
            GL11.glTexParameteri(3553, 33085, mipmap);
            GL11.glTexParameterf(3553, 33082, 0.0F);
            GL11.glTexParameterf(3553, 33083, (float)mipmap);
            GL30.glGenerateMipmap(3553);
         } else {
            GL11.glTexParameteri(3553, 10241, filter);
         }

         GL11.glTexParameteri(3553, 10240, filter);
         GL11.glTexParameteri(3553, 10242, $i$f$addPath);
         GL11.glTexParameteri(3553, 10243, $i$f$addPath);
         if (OpenGlHelper.field_148825_d) {
            float amount = RangesKt.coerceIn(anisotropic, 1.0F, (float)OpenGlHelper.field_148826_e);
            GL11.glTexParameterf(3553, 34046, amount);
         }

         Function1 var50 = this.configure;
         if (var50 != null) {
            var50.invoke(this.getId());
         }

         GL11.glBindTexture(3553, 0);
         Unit var41 = Unit.INSTANCE;
      } catch (Throwable var26) {
         var8 = var26;
         throw var26;
      } finally {
         CloseableKt.closeFinally(var7, var8);
      }

   }
}

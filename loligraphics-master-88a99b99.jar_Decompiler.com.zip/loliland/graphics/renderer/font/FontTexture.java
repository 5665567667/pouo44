package loliland.graphics.renderer.font;

import java.io.Closeable;
import java.io.InputStream;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.io.CloseableKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import loliland.graphics.renderer.texture.Texture;
import loliland.graphics.renderer.texture.TextureManager;
import loliland.graphics.renderer.texture.png.PNGDecoder;
import loliland.graphics.util.MPPUtils;
import loliland.graphics.util.ResourceExtensionsKt;
import net.minecraft.util.ResourceLocation;
import org.jetbrains.annotations.NotNull;
import org.lwjglx.opengl.GL11;
import org.lwjglx.opengl.GL30;
import org.lwjglx.opengl.GLContext;

@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\u0018\u00002\u00020\u0001B!\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007¢\u0006\u0002\u0010\bJ\b\u0010\t\u001a\u00020\nH\u0016R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000b"},
   d2 = {"Lloliland/graphics/renderer/font/FontTexture;", "Lloliland/graphics/renderer/texture/Texture;", "location", "Lnet/minecraft/util/ResourceLocation;", "mipmap", "", "anisotropic", "", "(Lnet/minecraft/util/ResourceLocation;IF)V", "load", "", "loligraphics-1.7.10"}
)
public final class FontTexture extends Texture {
   private final int mipmap;
   private final float anisotropic;

   public FontTexture(@NotNull ResourceLocation location, int mipmap, float anisotropic) {
      Intrinsics.checkNotNullParameter(location, "location");
      super(location);
      this.mipmap = mipmap;
      this.anisotropic = anisotropic;
   }

   // $FF: synthetic method
   public FontTexture(ResourceLocation var1, int var2, float var3, int var4, DefaultConstructorMarker var5) {
      if ((var4 & 2) != 0) {
         var2 = 0;
      }

      if ((var4 & 4) != 0) {
         var3 = 1.0F;
      }

      this(var1, var2, var3);
   }

   public void load() {
      Closeable var1 = (Closeable)ResourceExtensionsKt.inputStream(this.getLocation());
      Throwable var2 = null;

      try {
         InputStream stream = (InputStream)var1;
         int var4 = 0;
         TextureManager.TextureData textureData = MPPUtils.LOADED ? MPPUtils.loadTexture(stream) : TextureManager.decodeTexture$default(TextureManager.INSTANCE, new PNGDecoder(stream), (PNGDecoder.Format)null, 2, (Object)null);
         this.setWidth(textureData.getWidth());
         this.setHeight(textureData.getHeight());
         this.setId(GL11.glGenTextures());
         GL11.glBindTexture(3553, this.getId());
         GL11.glTexImage2D(3553, 0, 6408, this.getWidth(), this.getHeight(), 0, 32993, 33639, textureData.getPixels());
         if (this.mipmap > 0) {
            GL11.glTexParameterf(3553, 34049, 0.0F);
            GL11.glTexParameteri(3553, 10241, 9987);
            GL11.glTexParameteri(3553, 33085, this.mipmap);
            GL11.glTexParameterf(3553, 33082, 0.0F);
            GL11.glTexParameterf(3553, 33083, (float)this.mipmap);
            GL30.glGenerateMipmap(3553);
         } else {
            GL11.glTexParameteri(3553, 10241, 9729);
         }

         GL11.glTexParameteri(3553, 10240, 9729);
         GL11.glTexParameteri(3553, 10242, 10497);
         GL11.glTexParameteri(3553, 10243, 10497);
         if (GLContext.getCapabilities().GL_EXT_texture_filter_anisotropic) {
            float amount = RangesKt.coerceIn(this.anisotropic, 1.0F, GL11.glGetFloat(34047));
            GL11.glTexParameterf(3553, 34046, amount);
         }

         GL11.glBindTexture(3553, 0);
         Unit var11 = Unit.INSTANCE;
      } catch (Throwable var9) {
         var2 = var9;
         throw var9;
      } finally {
         CloseableKt.closeFinally(var1, var2);
      }

   }
}

package loliland.graphics.renderer.shader.uniform;

import java.nio.FloatBuffer;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import loliland.graphics.renderer.GLCompatible;
import loliland.graphics.renderer.shader.Shader;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix4f;
import org.lwjglx.BufferUtils;

@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u0000 \u000b2\u00020\u0001:\u0001\u000bB\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\u000e\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\n¨\u0006\f"},
   d2 = {"Lloliland/graphics/renderer/shader/uniform/UniformMatrix4;", "Lloliland/graphics/renderer/shader/uniform/Uniform;", "shader", "Lloliland/graphics/renderer/shader/Shader;", "name", "", "(Lloliland/graphics/renderer/shader/Shader;Ljava/lang/String;)V", "set", "", "value", "Lorg/joml/Matrix4f;", "Companion", "loligraphics-1.7.10"}
)
public final class UniformMatrix4 extends Uniform {
   @NotNull
   public static final Companion Companion = new Companion((DefaultConstructorMarker)null);
   private static final FloatBuffer matrixBuffer = BufferUtils.createFloatBuffer(16);

   public UniformMatrix4(@NotNull Shader shader, @NotNull String name) {
      Intrinsics.checkNotNullParameter(shader, "shader");
      Intrinsics.checkNotNullParameter(name, "name");
      super(shader, name);
   }

   public final void set(@NotNull Matrix4f value) {
      Intrinsics.checkNotNullParameter(value, "value");
      value.get(matrixBuffer);
      matrixBuffer.rewind();
      GLCompatible.uniformMatrix4(this.getLocation(), false, matrixBuffer);
      this.setFirstUpload(false);
   }

   @Metadata(
      mv = {1, 9, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u0016\u0010\u0003\u001a\n \u0005*\u0004\u0018\u00010\u00040\u0004X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0006"},
      d2 = {"Lloliland/graphics/renderer/shader/uniform/UniformMatrix4$Companion;", "", "()V", "matrixBuffer", "Ljava/nio/FloatBuffer;", "kotlin.jvm.PlatformType", "loligraphics-1.7.10"}
   )
   public static final class Companion {
      private Companion() {
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }
}

package loliland.graphics.renderer.texture;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.util.ResourceLocation;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.lwjglx.opengl.GL11;

@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u000f\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\r\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\b&\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\b\u0010\u0013\u001a\u00020\u0014H\u0016J\u0011\u0010\u0015\u001a\u00020\u00062\u0006\u0010\u0016\u001a\u00020\u0000H\u0096\u0002J\b\u0010\u0017\u001a\u00020\u0018H\u0016J\u0013\u0010\u0019\u001a\u00020\u00182\b\u0010\u0016\u001a\u0004\u0018\u00010\u001aH\u0096\u0002J\b\u0010\u001b\u001a\u00020\u0006H\u0016J\b\u0010\u001c\u001a\u00020\u0014H&J\b\u0010\u001d\u001a\u00020\u001eH\u0016J\b\u0010\u001f\u001a\u00020\u0014H\u0016R\u001a\u0010\u0005\u001a\u00020\u0006X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0007\u0010\b\"\u0004\b\t\u0010\nR\u001a\u0010\u000b\u001a\u00020\u0006X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\b\"\u0004\b\r\u0010\nR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u001a\u0010\u0010\u001a\u00020\u0006X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\b\"\u0004\b\u0012\u0010\n¨\u0006 "},
   d2 = {"Lloliland/graphics/renderer/texture/Texture;", "", "location", "Lnet/minecraft/util/ResourceLocation;", "(Lnet/minecraft/util/ResourceLocation;)V", "height", "", "getHeight", "()I", "setHeight", "(I)V", "id", "getId", "setId", "getLocation", "()Lnet/minecraft/util/ResourceLocation;", "width", "getWidth", "setWidth", "bind", "", "compareTo", "other", "dispose", "", "equals", "", "hashCode", "load", "toString", "", "unbind", "loligraphics-1.7.10"}
)
public abstract class Texture implements Comparable<Texture> {
   @NotNull
   private final ResourceLocation location;
   private int id;
   private int width;
   private int height;

   public Texture(@NotNull ResourceLocation location) {
      Intrinsics.checkNotNullParameter(location, "location");
      super();
      this.location = location;
      this.id = -1;
      this.width = -1;
      this.height = -1;
   }

   @NotNull
   public final ResourceLocation getLocation() {
      return this.location;
   }

   public final int getId() {
      return this.id;
   }

   public final void setId(int var1) {
      this.id = var1;
   }

   public final int getWidth() {
      return this.width;
   }

   public final void setWidth(int var1) {
      this.width = var1;
   }

   public final int getHeight() {
      return this.height;
   }

   public final void setHeight(int var1) {
      this.height = var1;
   }

   public abstract void load();

   public void bind() {
      if (this.id >= 0) {
         GL11.glBindTexture(3553, this.id);
      }

   }

   public void unbind() {
      if (this.id >= 0) {
         GL11.glBindTexture(3553, 0);
      }

   }

   public boolean dispose() {
      this.width = -1;
      this.height = -1;
      if (this.id > 0) {
         GL11.glDeleteTextures(this.id);
         this.id = -1;
         return true;
      } else {
         return false;
      }
   }

   public boolean equals(@Nullable Object other) {
      return other instanceof Texture && Intrinsics.areEqual(this.location, ((Texture)other).location);
   }

   public int hashCode() {
      return this.location.hashCode();
   }

   @NotNull
   public String toString() {
      String var10000 = this.location.toString();
      Intrinsics.checkNotNullExpressionValue(var10000, "toString(...)");
      return var10000;
   }

   public int compareTo(@NotNull Texture other) {
      Intrinsics.checkNotNullParameter(other, "other");
      return Intrinsics.compare(this.id, other.id);
   }
}

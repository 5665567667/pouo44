package loliland.graphics.renderer.shader.uniform;

import java.nio.FloatBuffer;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import loliland.graphics.renderer.GLCompatible;
import loliland.graphics.renderer.shader.Shader;
import org.jetbrains.annotations.NotNull;
import org.lwjglx.BufferUtils;

@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0014\n\u0000\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\u000e\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\n¨\u0006\u000b"},
   d2 = {"Lloliland/graphics/renderer/shader/uniform/UniformFloatArray;", "Lloliland/graphics/renderer/shader/uniform/Uniform;", "shader", "Lloliland/graphics/renderer/shader/Shader;", "name", "", "(Lloliland/graphics/renderer/shader/Shader;Ljava/lang/String;)V", "set", "", "value", "", "loligraphics-1.7.10"}
)
public final class UniformFloatArray extends Uniform {
   public UniformFloatArray(@NotNull Shader shader, @NotNull String name) {
      Intrinsics.checkNotNullParameter(shader, "shader");
      Intrinsics.checkNotNullParameter(name, "name");
      super(shader, name);
   }

   public final void set(@NotNull float[] value) {
      Intrinsics.checkNotNullParameter(value, "value");
      FloatBuffer $this$set_u24lambda_u240 = BufferUtils.createFloatBuffer(value.length);
      int var4 = 0;
      $this$set_u24lambda_u240.put(value);
      $this$set_u24lambda_u240.flip();
      GLCompatible.uniformFloatArray(this.getLocation(), $this$set_u24lambda_u240);
      this.setFirstUpload(false);
   }
}

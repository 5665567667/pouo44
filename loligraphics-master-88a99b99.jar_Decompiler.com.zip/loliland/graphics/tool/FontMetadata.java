package loliland.graphics.tool;

import java.util.Map;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import loliland.graphics.renderer.font.FontGlyph;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector2f;

@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\b\u0016\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001BA\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\u0006\u0010\t\u001a\u00020\b\u0012\u0012\u0010\n\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\f0\u000b¢\u0006\u0002\u0010\rJ\t\u0010\u0018\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0019\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001a\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001b\u001a\u00020\bHÆ\u0003J\t\u0010\u001c\u001a\u00020\bHÆ\u0003J\u0015\u0010\u001d\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\f0\u000bHÆ\u0003JQ\u0010\u001e\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\b2\b\b\u0002\u0010\t\u001a\u00020\b2\u0014\b\u0002\u0010\n\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\f0\u000bHÆ\u0001J\u0013\u0010\u001f\u001a\u00020\b2\b\u0010 \u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010!\u001a\u00020\u0005HÖ\u0001J\t\u0010\"\u001a\u00020#HÖ\u0001R\u0011\u0010\u0007\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u001d\u0010\n\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\f0\u000b¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0011\u0010\t\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u000fR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0011¨\u0006$"},
   d2 = {"Lloliland/graphics/tool/FontMetadata;", "", "imageSize", "Lorg/joml/Vector2f;", "fontSize", "", "lineHeight", "bold", "", "italic", "glyphs", "", "Lloliland/graphics/renderer/font/FontGlyph;", "(Lorg/joml/Vector2f;IIZZLjava/util/Map;)V", "getBold", "()Z", "getFontSize", "()I", "getGlyphs", "()Ljava/util/Map;", "getImageSize", "()Lorg/joml/Vector2f;", "getItalic", "getLineHeight", "component1", "component2", "component3", "component4", "component5", "component6", "copy", "equals", "other", "hashCode", "toString", "", "loligraphics-1.7.10"}
)
public final class FontMetadata {
   @NotNull
   private final Vector2f imageSize;
   private final int fontSize;
   private final int lineHeight;
   private final boolean bold;
   private final boolean italic;
   @NotNull
   private final Map<Integer, FontGlyph> glyphs;

   public FontMetadata(@NotNull Vector2f imageSize, int fontSize, int lineHeight, boolean bold, boolean italic, @NotNull Map<Integer, FontGlyph> glyphs) {
      Intrinsics.checkNotNullParameter(imageSize, "imageSize");
      Intrinsics.checkNotNullParameter(glyphs, "glyphs");
      super();
      this.imageSize = imageSize;
      this.fontSize = fontSize;
      this.lineHeight = lineHeight;
      this.bold = bold;
      this.italic = italic;
      this.glyphs = glyphs;
   }

   @NotNull
   public final Vector2f getImageSize() {
      return this.imageSize;
   }

   public final int getFontSize() {
      return this.fontSize;
   }

   public final int getLineHeight() {
      return this.lineHeight;
   }

   public final boolean getBold() {
      return this.bold;
   }

   public final boolean getItalic() {
      return this.italic;
   }

   @NotNull
   public final Map<Integer, FontGlyph> getGlyphs() {
      return this.glyphs;
   }

   @NotNull
   public final Vector2f component1() {
      return this.imageSize;
   }

   public final int component2() {
      return this.fontSize;
   }

   public final int component3() {
      return this.lineHeight;
   }

   public final boolean component4() {
      return this.bold;
   }

   public final boolean component5() {
      return this.italic;
   }

   @NotNull
   public final Map<Integer, FontGlyph> component6() {
      return this.glyphs;
   }

   @NotNull
   public final FontMetadata copy(@NotNull Vector2f imageSize, int fontSize, int lineHeight, boolean bold, boolean italic, @NotNull Map<Integer, FontGlyph> glyphs) {
      Intrinsics.checkNotNullParameter(imageSize, "imageSize");
      Intrinsics.checkNotNullParameter(glyphs, "glyphs");
      return new FontMetadata(imageSize, fontSize, lineHeight, bold, italic, glyphs);
   }

   // $FF: synthetic method
   public static FontMetadata copy$default(FontMetadata var0, Vector2f var1, int var2, int var3, boolean var4, boolean var5, Map var6, int var7, Object var8) {
      if ((var7 & 1) != 0) {
         var1 = var0.imageSize;
      }

      if ((var7 & 2) != 0) {
         var2 = var0.fontSize;
      }

      if ((var7 & 4) != 0) {
         var3 = var0.lineHeight;
      }

      if ((var7 & 8) != 0) {
         var4 = var0.bold;
      }

      if ((var7 & 16) != 0) {
         var5 = var0.italic;
      }

      if ((var7 & 32) != 0) {
         var6 = var0.glyphs;
      }

      return var0.copy(var1, var2, var3, var4, var5, var6);
   }

   @NotNull
   public String toString() {
      return "FontMetadata(imageSize=" + this.imageSize + ", fontSize=" + this.fontSize + ", lineHeight=" + this.lineHeight + ", bold=" + this.bold + ", italic=" + this.italic + ", glyphs=" + this.glyphs + ')';
   }

   public int hashCode() {
      int result = this.imageSize.hashCode();
      result = result * 31 + Integer.hashCode(this.fontSize);
      result = result * 31 + Integer.hashCode(this.lineHeight);
      result = result * 31 + Boolean.hashCode(this.bold);
      result = result * 31 + Boolean.hashCode(this.italic);
      result = result * 31 + this.glyphs.hashCode();
      return result;
   }

   public boolean equals(@Nullable Object other) {
      if (this == other) {
         return true;
      } else if (!(other instanceof FontMetadata)) {
         return false;
      } else {
         FontMetadata var2 = (FontMetadata)other;
         if (!Intrinsics.areEqual(this.imageSize, var2.imageSize)) {
            return false;
         } else if (this.fontSize != var2.fontSize) {
            return false;
         } else if (this.lineHeight != var2.lineHeight) {
            return false;
         } else if (this.bold != var2.bold) {
            return false;
         } else if (this.italic != var2.italic) {
            return false;
         } else {
            return Intrinsics.areEqual(this.glyphs, var2.glyphs);
         }
      }
   }
}

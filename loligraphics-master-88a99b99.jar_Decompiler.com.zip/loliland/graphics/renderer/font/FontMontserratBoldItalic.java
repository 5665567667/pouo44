package loliland.graphics.renderer.font;

import kotlin.Metadata;
import net.minecraft.util.ResourceLocation;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002¨\u0006\u0003"},
   d2 = {"Lloliland/graphics/renderer/font/FontMontserratBoldItalic;", "Lloliland/graphics/renderer/font/Font;", "()V", "loligraphics-1.7.10"}
)
public final class FontMontserratBoldItalic extends Font {
   @NotNull
   public static final FontMontserratBoldItalic INSTANCE = new FontMontserratBoldItalic();

   private FontMontserratBoldItalic() {
      super(new ResourceLocation("fonts/montserrat_bold_italic"));
   }
}

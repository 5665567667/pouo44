package loliland.graphics.renderer.texture;

import kotlin.Metadata;
import net.minecraft.util.ResourceLocation;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0016J\b\u0010\u0005\u001a\u00020\u0006H\u0016¨\u0006\u0007"},
   d2 = {"Lloliland/graphics/renderer/texture/MissingTexture;", "Lloliland/graphics/renderer/texture/Texture;", "()V", "dispose", "", "load", "", "loligraphics-1.7.10"}
)
public final class MissingTexture extends Texture {
   @NotNull
   public static final MissingTexture INSTANCE = new MissingTexture();

   private MissingTexture() {
      super(new ResourceLocation("textures/missing"));
   }

   public void load() {
   }

   public boolean dispose() {
      return true;
   }
}

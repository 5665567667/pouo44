#version 120

varying vec2 pass_textureCoords;
varying vec4 pass_vertexColor;

uniform vec3 position;

void main() {
    vec4 transformedVertex = vec4(gl_Vertex.xyz + position, 1.0);
    gl_Position = gl_ModelViewProjectionMatrix * transformedVertex;
    pass_textureCoords = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    pass_vertexColor = gl_Color.rgba;
}
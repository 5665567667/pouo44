#version 120

varying vec2 pass_textureCoords;
varying vec4 pass_vertexColor;

uniform sampler2D fontAtlas;

uniform vec4 color;
uniform vec3 outlineColor;

uniform float width;
uniform float edge;

uniform float borderWidth;
uniform float borderEdge;

uniform vec2 offset;
uniform float opacity;

void main() {
    float distance = 1.0 - texture2D(fontAtlas, pass_textureCoords).a;
    float alpha = 1.0 - smoothstep(width, width + edge, distance);

    float distance2 = 1.0 - texture2D(fontAtlas, pass_textureCoords + offset).a;
    float outlineAlpha = 1.0 - smoothstep(borderWidth, borderWidth + borderEdge, distance2);

    vec3 actualColor = pass_vertexColor.r < 0.0f ? color.rgb : pass_vertexColor.rgb;
    float actualAlpha = pass_vertexColor.a < 0.0f ? color.a : pass_vertexColor.a;

    float overallAlpha = alpha + (1.0 - alpha) * outlineAlpha;
    vec3 overallColor = mix(outlineColor, actualColor, alpha / overallAlpha);

    gl_FragColor = vec4(overallColor, actualAlpha * overallAlpha * opacity);
}
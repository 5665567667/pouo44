package loliland.graphics.renderer;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\n\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u001f\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003¢\u0006\u0002\u0010\u0006J\u0006\u0010\r\u001a\u00020\u000eJ\u000e\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0010\u001a\u00020\u0011J\u000e\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0010\u001a\u00020\u0012J\u000e\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0013\u001a\u00020\u0014J\u0018\u0010\u0015\u001a\u00020\u000e2\u0006\u0010\u0010\u001a\u00020\u00112\b\b\u0002\u0010\u0016\u001a\u00020\u0014J\u0018\u0010\u0015\u001a\u00020\u000e2\u0006\u0010\u0010\u001a\u00020\u00122\b\b\u0002\u0010\u0016\u001a\u00020\u0014J\u0006\u0010\u0017\u001a\u00020\u0018J\u0013\u0010\u0019\u001a\u00020\u00182\b\u0010\u001a\u001a\u0004\u0018\u00010\u0001H\u0096\u0002J\b\u0010\u001b\u001a\u00020\u0003H\u0016J\b\u0010\u001c\u001a\u00020\u001dH\u0016J\u0006\u0010\u001e\u001a\u00020\u000eR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u001e\u0010\n\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\u0003@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\b¨\u0006\u001f"},
   d2 = {"Lloliland/graphics/renderer/VBO;", "", "vboId", "", "type", "drawMode", "(III)V", "getDrawMode", "()I", "<set-?>", "id", "getId", "getType", "bind", "", "bufferData", "data", "Ljava/nio/FloatBuffer;", "Ljava/nio/IntBuffer;", "size", "", "bufferSubData", "offset", "dispose", "", "equals", "other", "hashCode", "toString", "", "unbind", "loligraphics-1.7.10"}
)
public final class VBO {
   private final int type;
   private final int drawMode;
   private int id;

   public VBO(int vboId, int type, int drawMode) {
      this.type = type;
      this.drawMode = drawMode;
      this.id = vboId;
   }

   // $FF: synthetic method
   public VBO(int var1, int var2, int var3, int var4, DefaultConstructorMarker var5) {
      if ((var4 & 1) != 0) {
         var1 = GLCompatible.genBuffers();
      }

      this(var1, var2, var3);
   }

   public final int getType() {
      return this.type;
   }

   public final int getDrawMode() {
      return this.drawMode;
   }

   public final int getId() {
      return this.id;
   }

   public final void bind() {
      GLCompatible.bindBuffer(this.type, this.id);
   }

   public final void unbind() {
      GLCompatible.bindBuffer(this.type, 0);
   }

   public final boolean dispose() {
      if (this.id <= 0) {
         return false;
      } else {
         this.unbind();
         GLCompatible.deleteBuffer(this.id);
         this.id = -1;
         return true;
      }
   }

   public final void bufferData(@NotNull IntBuffer data) {
      Intrinsics.checkNotNullParameter(data, "data");
      GLCompatible.bufferData(this.type, data, this.drawMode);
   }

   public final void bufferData(@NotNull FloatBuffer data) {
      Intrinsics.checkNotNullParameter(data, "data");
      GLCompatible.bufferData(this.type, data, this.drawMode);
   }

   public final void bufferData(long size) {
      GLCompatible.bufferData(this.type, size, this.drawMode);
   }

   public final void bufferSubData(@NotNull FloatBuffer data, long offset) {
      Intrinsics.checkNotNullParameter(data, "data");
      GLCompatible.bufferSubData(this.type, offset, data);
   }

   // $FF: synthetic method
   public static void bufferSubData$default(VBO var0, FloatBuffer var1, long var2, int var4, Object var5) {
      if ((var4 & 2) != 0) {
         var2 = 0L;
      }

      var0.bufferSubData(var1, var2);
   }

   public final void bufferSubData(@NotNull IntBuffer data, long offset) {
      Intrinsics.checkNotNullParameter(data, "data");
      GLCompatible.bufferSubData(this.type, offset, data);
   }

   // $FF: synthetic method
   public static void bufferSubData$default(VBO var0, IntBuffer var1, long var2, int var4, Object var5) {
      if ((var4 & 2) != 0) {
         var2 = 0L;
      }

      var0.bufferSubData(var1, var2);
   }

   public boolean equals(@Nullable Object other) {
      if (this == other) {
         return true;
      } else if (!(other instanceof VBO)) {
         return false;
      } else {
         return this.id == ((VBO)other).id;
      }
   }

   public int hashCode() {
      return this.id;
   }

   @NotNull
   public String toString() {
      return "VBO(id=" + this.id + ", type=" + this.type + ", drawMode=" + this.drawMode + ')';
   }
}

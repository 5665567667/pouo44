package loliland.graphics.util;

import java.io.FileNotFoundException;
import java.io.InputStream;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 9, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u001e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\u001a\u0015\u0010\b\u001a\u00020\u0001*\u00020\u00012\u0006\u0010\t\u001a\u00020\nH\u0086\b\u001a\n\u0010\u000b\u001a\u00020\f*\u00020\u0001\"\u0011\u0010\u0000\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0003\"\u0015\u0010\u0004\u001a\u00020\u0005*\u00020\u00018F¢\u0006\u0006\u001a\u0004\b\u0006\u0010\u0007¨\u0006\r"},
   d2 = {"NULL_LOCATION", "Lnet/minecraft/util/ResourceLocation;", "getNULL_LOCATION", "()Lnet/minecraft/util/ResourceLocation;", "exists", "", "getExists", "(Lnet/minecraft/util/ResourceLocation;)Z", "addPath", "path", "", "inputStream", "Ljava/io/InputStream;", "loligraphics-1.7.10"}
)
public final class ResourceExtensionsKt {
   @NotNull
   private static final ResourceLocation NULL_LOCATION = new ResourceLocation("null");

   @NotNull
   public static final ResourceLocation getNULL_LOCATION() {
      return NULL_LOCATION;
   }

   @NotNull
   public static final InputStream inputStream(@NotNull ResourceLocation $this$inputStream) {
      Intrinsics.checkNotNullParameter($this$inputStream, "<this>");
      Minecraft mc = Minecraft.func_71410_x();

      InputStream var2;
      try {
         var2 = mc.func_110442_L().func_110536_a($this$inputStream).func_110527_b();
         Intrinsics.checkNotNull(var2);
         var2 = var2;
      } catch (FileNotFoundException var5) {
         InputStream var4 = mc.field_110450_ap.func_110590_a($this$inputStream);
         Intrinsics.checkNotNull(var4);
         var2 = var4;
      }

      return var2;
   }

   public static final boolean getExists(@NotNull ResourceLocation $this$exists) {
      Intrinsics.checkNotNullParameter($this$exists, "<this>");

      boolean var1;
      try {
         inputStream($this$exists);
         var1 = true;
      } catch (FileNotFoundException var3) {
         var1 = false;
      }

      return var1;
   }

   @NotNull
   public static final ResourceLocation addPath(@NotNull ResourceLocation $this$addPath, @NotNull String path) {
      Intrinsics.checkNotNullParameter($this$addPath, "<this>");
      Intrinsics.checkNotNullParameter(path, "path");
      int $i$f$addPath = 0;
      return new ResourceLocation($this$addPath.func_110624_b(), $this$addPath.func_110623_a() + path);
   }
}

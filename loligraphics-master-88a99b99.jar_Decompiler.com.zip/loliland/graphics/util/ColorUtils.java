package loliland.graphics.util;

import kotlin.Metadata;
import kotlin.jvm.JvmName;
import kotlin.jvm.internal.SourceDebugExtension;

@Metadata(
   mv = {1, 9, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000\u0012\n\u0000\n\u0002\u0010\b\n\u0002\b\u0012\n\u0002\u0010\u0007\n\u0002\b\b\u001a)\u0010\u0012\u001a\u00020\u00012\u0006\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u00142\u0006\u0010\u0016\u001a\u00020\u00142\u0006\u0010\u0017\u001a\u00020\u0014H\u0086\b\u001a)\u0010\u0012\u001a\u00020\u00012\u0006\u0010\u0013\u001a\u00020\u00012\u0006\u0010\u0015\u001a\u00020\u00012\u0006\u0010\u0016\u001a\u00020\u00012\u0006\u0010\u0017\u001a\u00020\u0001H\u0086\b\u001a!\u0010\u0018\u001a\u00020\u00012\u0006\u0010\u0015\u001a\u00020\u00142\u0006\u0010\u0016\u001a\u00020\u00142\u0006\u0010\u0017\u001a\u00020\u0014H\u0086\b\u001a!\u0010\u0018\u001a\u00020\u00012\u0006\u0010\u0015\u001a\u00020\u00012\u0006\u0010\u0016\u001a\u00020\u00012\u0006\u0010\u0017\u001a\u00020\u0001H\u0086\b\u001a)\u0010\u0019\u001a\u00020\u00012\u0006\u0010\u0015\u001a\u00020\u00142\u0006\u0010\u0016\u001a\u00020\u00142\u0006\u0010\u0017\u001a\u00020\u00142\u0006\u0010\u0013\u001a\u00020\u0014H\u0086\b\u001a)\u0010\u0019\u001a\u00020\u00012\u0006\u0010\u0015\u001a\u00020\u00012\u0006\u0010\u0016\u001a\u00020\u00012\u0006\u0010\u0017\u001a\u00020\u00012\u0006\u0010\u0013\u001a\u00020\u0001H\u0086\b\u001a\r\u0010\u001a\u001a\u00020\u0001*\u00020\u0014H\u0086\b\u001a\r\u0010\u001b\u001a\u00020\u0014*\u00020\u0001H\u0086\b\"\u0016\u0010\u0000\u001a\u00020\u0001*\u00020\u00018Æ\u0002¢\u0006\u0006\u001a\u0004\b\u0002\u0010\u0003\"\u0016\u0010\u0004\u001a\u00020\u0001*\u00020\u00018Æ\u0002¢\u0006\u0006\u001a\u0004\b\u0005\u0010\u0003\"\u0016\u0010\u0006\u001a\u00020\u0001*\u00020\u00018Æ\u0002¢\u0006\u0006\u001a\u0004\b\u0007\u0010\u0003\"\u0016\u0010\b\u001a\u00020\u0001*\u00020\u00018Æ\u0002¢\u0006\u0006\u001a\u0004\b\t\u0010\u0003\"\u0016\u0010\n\u001a\u00020\u0001*\u00020\u00018Æ\u0002¢\u0006\u0006\u001a\u0004\b\u000b\u0010\u0003\"\u0016\u0010\f\u001a\u00020\u0001*\u00020\u00018Æ\u0002¢\u0006\u0006\u001a\u0004\b\r\u0010\u0003\"\u0016\u0010\u000e\u001a\u00020\u0001*\u00020\u00018Æ\u0002¢\u0006\u0006\u001a\u0004\b\u000f\u0010\u0003\"\u0016\u0010\u0010\u001a\u00020\u0001*\u00020\u00018Æ\u0002¢\u0006\u0006\u001a\u0004\b\u0011\u0010\u0003¨\u0006\u001c"},
   d2 = {"argbAlpha", "", "getArgbAlpha", "(I)I", "argbBlue", "getArgbBlue", "argbGreen", "getArgbGreen", "argbRed", "getArgbRed", "rgbaAlpha", "getRgbaAlpha", "rgbaBlue", "getRgbaBlue", "rgbaGreen", "getRgbaGreen", "rgbaRed", "getRgbaRed", "argb", "alpha", "", "red", "green", "blue", "rgb", "rgba", "denormalizeColor", "normalizeColor", "loligraphics-1.7.10"}
)
@JvmName(
   name = "ColorUtils"
)
@SourceDebugExtension({"SMAP\nColorUtils.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ColorUtils.kt\nloliland/graphics/util/ColorUtils\n*L\n1#1,35:1\n19#1,4:36\n19#1,10:40\n22#1:50\n19#1:51\n33#1:52\n22#1:53\n*S KotlinDebug\n*F\n+ 1 ColorUtils.kt\nloliland/graphics/util/ColorUtils\n*L\n25#1:36,4\n31#1:40,10\n33#1:50\n35#1:51\n35#1:52\n35#1:53\n*E\n"})
public final class ColorUtils {
   public static final int getArgbRed(int $this$argbRed) {
      int $i$f$getArgbRed = 0;
      return $this$argbRed >> 16 & 255;
   }

   public static final int getRgbaRed(int $this$rgbaRed) {
      int $i$f$getRgbaRed = 0;
      return $this$rgbaRed >> 24 & 255;
   }

   public static final int getArgbGreen(int $this$argbGreen) {
      int $i$f$getArgbGreen = 0;
      return $this$argbGreen >> 8 & 255;
   }

   public static final int getRgbaGreen(int $this$rgbaGreen) {
      int $i$f$getRgbaGreen = 0;
      return $this$rgbaGreen >> 16 & 255;
   }

   public static final int getArgbBlue(int $this$argbBlue) {
      int $i$f$getArgbBlue = 0;
      return $this$argbBlue >> 0 & 255;
   }

   public static final int getRgbaBlue(int $this$rgbaBlue) {
      int $i$f$getRgbaBlue = 0;
      return $this$rgbaBlue >> 8 & 255;
   }

   public static final int getArgbAlpha(int $this$argbAlpha) {
      int $i$f$getArgbAlpha = 0;
      return $this$argbAlpha >> 24 & 255;
   }

   public static final int getRgbaAlpha(int $this$rgbaAlpha) {
      int $i$f$getRgbaAlpha = 0;
      return $this$rgbaAlpha >> 0 & 255;
   }

   public static final float normalizeColor(int $this$normalizeColor) {
      int $i$f$normalizeColor = 0;
      return (float)$this$normalizeColor / 255.0F;
   }

   public static final int denormalizeColor(float $this$denormalizeColor) {
      int $i$f$denormalizeColor = 0;
      return (int)($this$denormalizeColor * 255.0F + 0.5F);
   }

   public static final int argb(int alpha, int red, int green, int blue) {
      int $i$f$argb = 0;
      return alpha << 24 | red << 16 | green << 8 | blue << 0;
   }

   public static final int argb(float alpha, float red, float green, float blue) {
      int $i$f$argb = 0;
      int $i$f$denormalizeColor = 0;
      int $this$denormalizeColor$iv = (int)(alpha * 255.0F + 0.5F);
      int $i$f$denormalizeColor = 0;
      $i$f$denormalizeColor = (int)(red * 255.0F + 0.5F);
      int $i$f$denormalizeColor = 0;
      $i$f$denormalizeColor = (int)(green * 255.0F + 0.5F);
      int $i$f$denormalizeColor = 0;
      $i$f$denormalizeColor = (int)(blue * 255.0F + 0.5F);
      $i$f$denormalizeColor = 0;
      return $this$denormalizeColor$iv << 24 | $i$f$denormalizeColor << 16 | $i$f$denormalizeColor << 8 | $i$f$denormalizeColor << 0;
   }

   public static final int rgba(int red, int green, int blue, int alpha) {
      int $i$f$rgba = 0;
      return red << 24 | green << 16 | blue << 8 | alpha << 0;
   }

   public static final int rgba(float red, float green, float blue, float alpha) {
      int $i$f$rgba = 0;
      int $i$f$denormalizeColor = 0;
      int $this$denormalizeColor$iv = (int)(red * 255.0F + 0.5F);
      int $i$f$denormalizeColor = 0;
      $i$f$denormalizeColor = (int)(green * 255.0F + 0.5F);
      int $i$f$denormalizeColor = 0;
      $i$f$denormalizeColor = (int)(blue * 255.0F + 0.5F);
      int $i$f$denormalizeColor = 0;
      $i$f$denormalizeColor = (int)(alpha * 255.0F + 0.5F);
      $i$f$denormalizeColor = 0;
      return $this$denormalizeColor$iv << 24 | $i$f$denormalizeColor << 16 | $i$f$denormalizeColor << 8 | $i$f$denormalizeColor << 0;
   }

   public static final int rgb(int red, int green, int blue) {
      int $i$f$rgb = 0;
      int alpha$iv = 255;
      int $i$f$argb = 0;
      return alpha$iv << 24 | red << 16 | green << 8 | blue << 0;
   }

   public static final int rgb(float red, float green, float blue) {
      int $i$f$rgb = 0;
      int $i$f$denormalizeColor = 0;
      int $this$denormalizeColor$iv = (int)(red * 255.0F + 0.5F);
      int $i$f$denormalizeColor = 0;
      $i$f$denormalizeColor = (int)(green * 255.0F + 0.5F);
      int $i$f$denormalizeColor = 0;
      $i$f$denormalizeColor = (int)(blue * 255.0F + 0.5F);
      $i$f$denormalizeColor = 0;
      int alpha$iv$iv = 255;
      int $i$f$argb = 0;
      return alpha$iv$iv << 24 | $this$denormalizeColor$iv << 16 | $i$f$denormalizeColor << 8 | $i$f$denormalizeColor << 0;
   }
}

package loliland.graphics.renderer.glut;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import org.lwjglx.opengl.GL11;
import org.lwjglx.opengl.GL20;
import org.lwjglx.opengl.GL30;
import org.lwjglx.opengl.GLContext;

@SideOnly(Side.CLIENT)
public class GLUTFramebuffer implements IDisposable {
   static List<GLUTFramebuffer> managedFramebuffers = new ArrayList();
   protected int width;
   protected int height;
   protected boolean isMRT;
   protected int framebufferHandle = -1;
   protected int depthBufferHandle = -1;
   protected int stencilBufferHandle = -1;
   protected int packedDepthStencilBufferHandle = -1;
   protected final GLUTFramebufferAttachment stencilRenderBuffer;
   protected final GLUTFramebufferAttachment depthRenderBuffer;
   protected final GLUTFramebufferAttachment packedDepthStencilRenderBuffer;
   protected List<GLTexture> textureAttachments = new ArrayList();
   protected int cachedPreviousFramebufferHandle;

   protected GLUTFramebuffer(Builder builder) {
      this.width = builder.width;
      this.height = builder.height;
      this.framebufferHandle = GL30.glGenFramebuffers();
      GL30.glBindFramebuffer(36160, this.framebufferHandle);
      if (builder.depthRenderBuffer != null) {
         this.depthBufferHandle = GL30.glGenRenderbuffers();
         GL30.glBindRenderbuffer(36161, this.depthBufferHandle);
         GL30.glRenderbufferStorage(36161, builder.depthRenderBuffer.internalFormat, builder.width, builder.height);
         this.depthRenderBuffer = builder.depthRenderBuffer;
      } else {
         this.depthRenderBuffer = null;
      }

      if (builder.stencilRenderBuffer != null) {
         this.stencilBufferHandle = GL30.glGenRenderbuffers();
         GL30.glBindRenderbuffer(36161, this.stencilBufferHandle);
         GL30.glRenderbufferStorage(36161, builder.stencilRenderBuffer.internalFormat, builder.width, builder.height);
         this.stencilRenderBuffer = builder.stencilRenderBuffer;
      } else {
         this.stencilRenderBuffer = null;
      }

      if (builder.packedDepthStencilRenderBuffer != null) {
         this.packedDepthStencilBufferHandle = GL30.glGenRenderbuffers();
         GL30.glBindRenderbuffer(36161, this.packedDepthStencilBufferHandle);
         GL30.glRenderbufferStorage(36161, builder.packedDepthStencilRenderBuffer.internalFormat, builder.width, builder.height);
         this.packedDepthStencilRenderBuffer = builder.packedDepthStencilRenderBuffer;
      } else {
         this.packedDepthStencilRenderBuffer = null;
      }

      int colorAttachmentCounter = 0;
      this.isMRT = builder.attachments.size() > 1;
      if (this.isMRT) {
         for(GLUTFramebufferAttachment attachment : builder.attachments) {
            GLTexture texture = (new GLTexture.Builder(attachment.internalFormat, attachment.format, attachment.type)).setSize(builder.width, builder.height).build();
            this.textureAttachments.add(texture);
            if (attachment.isColorTexture()) {
               GL30.glFramebufferTexture2D(36160, '賠' + colorAttachmentCounter, 3553, texture.getHandle(), 0);
               ++colorAttachmentCounter;
            } else if (attachment.isDepth) {
               GL30.glFramebufferTexture2D(36160, 36096, 3553, texture.getHandle(), 0);
            } else if (attachment.isStencil) {
               GL30.glFramebufferTexture2D(36160, 36128, 3553, texture.getHandle(), 0);
            }
         }
      } else {
         GLUTFramebufferAttachment attachment = (GLUTFramebufferAttachment)builder.attachments.get(0);
         GLTexture texture = (new GLTexture.Builder(attachment.internalFormat, attachment.format, attachment.type)).setSize(builder.width, builder.height).build();
         this.textureAttachments.add(texture);
         GL11.glBindTexture(3553, texture.getHandle());
      }

      if (this.isMRT) {
         ByteBuffer byteBuf = ByteBuffer.allocateDirect(colorAttachmentCounter * 4);
         byteBuf.order(ByteOrder.nativeOrder());
         IntBuffer buffer = byteBuf.asIntBuffer();

         for(int i = 0; i != colorAttachmentCounter; ++i) {
            buffer.put('賠' + i);
         }

         buffer.position(0);
         int prevLimit = buffer.limit();
         buffer.limit(colorAttachmentCounter);
         GL20.glDrawBuffers(buffer);
         buffer.limit(prevLimit);
      } else {
         GL30.glFramebufferTexture2D(36160, 36064, 3553, ((GLTexture)this.textureAttachments.get(0)).getHandle(), 0);
      }

      if (builder.depthRenderBuffer != null) {
         GL30.glFramebufferRenderbuffer(36160, 36096, 36161, this.depthBufferHandle);
      }

      if (builder.stencilRenderBuffer != null) {
         GL30.glFramebufferRenderbuffer(36160, 36128, 36161, this.stencilBufferHandle);
      }

      if (builder.packedDepthStencilRenderBuffer != null) {
         GL30.glFramebufferRenderbuffer(36160, 33306, 36161, this.packedDepthStencilBufferHandle);
      }

      GL30.glBindRenderbuffer(36161, 0);
      GL11.glBindTexture(3553, 0);
      int status = GL30.glCheckFramebufferStatus(36160);
      GL30.glBindFramebuffer(36160, 0);
      if (status == 36053) {
         managedFramebuffers.add(this);
      } else {
         for(GLTexture texture : this.textureAttachments) {
            texture.dispose();
         }

         if (this.packedDepthStencilBufferHandle != -1) {
            GL30.glDeleteRenderbuffers(this.packedDepthStencilBufferHandle);
         } else {
            if (this.depthBufferHandle != -1) {
               GL30.glDeleteRenderbuffers(this.depthBufferHandle);
            }

            if (this.stencilBufferHandle != -1) {
               GL30.glDeleteRenderbuffers(this.stencilBufferHandle);
            }
         }

         GL30.glDeleteFramebuffers(this.framebufferHandle);
         switch (status) {
            case 36054:
               throw new IllegalStateException("Framebuffer couldn't be constructed: incomplete attachment");
            case 36055:
               throw new IllegalStateException("Framebuffer couldn't be constructed: incomplete attachment");
            case 36056:
            case 36058:
            case 36059:
            case 36060:
            default:
               throw new IllegalStateException("Framebuffer couldn't be constructed: unknown error " + status);
            case 36057:
               throw new IllegalStateException("Framebuffer couldn't be constructed: incomplete dimensions");
            case 36061:
               throw new IllegalStateException("Framebuffer couldn't be constructed: unsupported combination of formats");
         }
      }
   }

   public GLUTFramebuffer setSize(int width, int height) {
      if (this.width != width || this.height != height) {
         this.width = width;
         this.height = height;

         for(GLTexture texture : this.textureAttachments) {
            texture.bind();
            texture.resize(width, height);
         }
      }

      return this;
   }

   public int bind() {
      int boundFramebuffer = GL11.glGetInteger(36006);
      GL30.glBindFramebuffer(36160, this.framebufferHandle);
      return boundFramebuffer;
   }

   public void unbind(int framebufferHandle) {
      GL30.glBindFramebuffer(36160, framebufferHandle);
   }

   public void begin() {
      this.cachedPreviousFramebufferHandle = this.bind();
      GL11.glViewport(0, 0, Minecraft.func_71410_x().field_71443_c, Minecraft.func_71410_x().field_71440_d);
   }

   public void end() {
      this.unbind(this.cachedPreviousFramebufferHandle);
      GL11.glViewport(0, 0, Minecraft.func_71410_x().field_71443_c, Minecraft.func_71410_x().field_71440_d);
   }

   public int getWidth() {
      return this.width;
   }

   public int getHeight() {
      return this.height;
   }

   public boolean isMRT() {
      return this.isMRT;
   }

   public int getFramebufferHandle() {
      return this.framebufferHandle;
   }

   public int getDepthBufferHandle() {
      return this.depthBufferHandle;
   }

   public int getStencilBufferHandle() {
      return this.stencilBufferHandle;
   }

   public int getPackedDepthStencilBufferHandle() {
      return this.packedDepthStencilBufferHandle;
   }

   public List<GLTexture> getTextureAttachments() {
      return this.textureAttachments;
   }

   public void dispose() {
      for(GLTexture texture : this.textureAttachments) {
         if (!texture.isDisposed()) {
            texture.dispose();
         }
      }

      if (this.packedDepthStencilBufferHandle != -1) {
         GL30.glDeleteRenderbuffers(this.packedDepthStencilBufferHandle);
      } else {
         if (this.depthBufferHandle != -1) {
            GL30.glDeleteRenderbuffers(this.depthBufferHandle);
         }

         if (this.stencilBufferHandle != -1) {
            GL30.glDeleteRenderbuffers(this.stencilBufferHandle);
         }
      }

      if (this.framebufferHandle != -1) {
         GL30.glDeleteFramebuffers(this.framebufferHandle);
      }

      managedFramebuffers.remove(this);
   }

   public static void blit(int readTarget, int readX, int readY, int readWidth, int readHeight, int drawTarget, int drawX, int drawY, int drawWidth, int drawHeight, int mode, int filtering) {
      GL30.glBindFramebuffer(36008, readTarget);
      GL30.glBindFramebuffer(36009, drawTarget);
      GL30.glBlitFramebuffer(readX, readY, readWidth, readHeight, drawX, drawY, drawWidth, drawHeight, mode, filtering);
   }

   public static class Builder {
      protected int width;
      protected int height;
      protected GLUTFramebufferAttachment stencilRenderBuffer;
      protected GLUTFramebufferAttachment depthRenderBuffer;
      protected GLUTFramebufferAttachment packedDepthStencilRenderBuffer;
      protected List<GLUTFramebufferAttachment> attachments = new ArrayList();

      public Builder() {
         this.width = Minecraft.func_71410_x().field_71443_c;
         this.height = Minecraft.func_71410_x().field_71440_d;
      }

      public Builder setSize(int width, int height) {
         this.width = width;
         this.height = height;
         return this;
      }

      public Builder addBasicTextureAttachment(GLTextureFormat format) {
         return format == null ? this : this.addTextureAttachment(format.getGLFormat(), format.getGLFormat(), format.getGLType());
      }

      public Builder addTextureAttachment(int internalFormat, int format, int type) {
         this.attachments.add(new GLUTFramebufferAttachment(internalFormat, format, type));
         return this;
      }

      public Builder addFloatTextureAttachment(int internalFormat, int format, int type, boolean gpuOnly) {
         GLUTFramebufferAttachment attachment = new GLUTFramebufferAttachment(internalFormat, format, type);
         attachment.isFloat = true;
         attachment.isGPUOnly = gpuOnly;
         this.attachments.add(attachment);
         return this;
      }

      public Builder addDepthTextureAttachment(int internalFormat, int type) {
         GLUTFramebufferAttachment attachment = new GLUTFramebufferAttachment(internalFormat, 6402, type);
         attachment.isDepth = true;
         this.attachments.add(attachment);
         return this;
      }

      public Builder addStencilTextureAttachment(int internalFormat, int type) {
         GLUTFramebufferAttachment attachment = new GLUTFramebufferAttachment(internalFormat, 36128, type);
         attachment.isStencil = true;
         this.attachments.add(attachment);
         return this;
      }

      public Builder addBasicDepthRenderBuffer() {
         return this.addDepthRenderBuffer(33189);
      }

      public Builder addDepthRenderBuffer(int internalFormat) {
         this.depthRenderBuffer = new GLUTFramebufferAttachment(internalFormat);
         return this;
      }

      public Builder addBasicStencilRenderBuffer() {
         return this.addStencilRenderBuffer(36168);
      }

      public Builder addStencilRenderBuffer(int internalFormat) {
         this.stencilRenderBuffer = new GLUTFramebufferAttachment(internalFormat);
         return this;
      }

      public Builder addBasicStencilDepthPackedRenderBuffer() {
         return this.addStencilDepthPackedRenderBuffer(35056);
      }

      public Builder addStencilDepthPackedRenderBuffer(int internalFormat) {
         this.packedDepthStencilRenderBuffer = new GLUTFramebufferAttachment(internalFormat);
         return this;
      }

      public GLUTFramebuffer build() {
         boolean isGL30 = GLContext.getCapabilities().OpenGL30;
         if (!isGL30) {
            if (this.packedDepthStencilRenderBuffer != null) {
               throw new UnsupportedOperationException("Packed Stencil/render render buffers are not available on GL(ES) < 3.0");
            }

            if (this.attachments.size() > 1) {
               throw new UnsupportedOperationException("Multiple render targets not available on GL(ES) < 3.0");
            }

            for(GLUTFramebufferAttachment attachment : this.attachments) {
               if (attachment.isDepth) {
                  throw new UnsupportedOperationException("Depth texture attachment not available on GL(ES) < 3.0");
               }

               if (attachment.isStencil) {
                  throw new UnsupportedOperationException("Stencil texture attachment not available on GL(ES) < 3.0");
               }

               if (attachment.isFloat) {
                  throw new UnsupportedOperationException("Float texture attachment not available on GL(ES) < 3.0");
               }
            }
         }

         return new GLUTFramebuffer(this);
      }
   }
}

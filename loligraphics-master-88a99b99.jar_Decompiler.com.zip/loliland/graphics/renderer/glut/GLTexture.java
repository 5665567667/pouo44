package loliland.graphics.renderer.glut;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.nio.ByteBuffer;
import net.minecraft.client.Minecraft;
import org.lwjglx.opengl.GL11;
import org.lwjglx.opengl.GL13;

@SideOnly(Side.CLIENT)
public class GLTexture implements IDisposable {
   private int glHandle;
   protected int width;
   protected int height;
   protected int internalFormat;
   protected int format;
   protected int type;
   protected int minFilter;
   protected int magFilter;
   protected int wrapS;
   protected int wrapT;

   public GLTexture(int glHandle) {
      this.glHandle = glHandle;
   }

   public void bind() {
      GL11.glBindTexture(3553, this.glHandle);
   }

   public void bind(int target) {
      GL13.glActiveTexture(target);
      GL11.glBindTexture(3553, this.glHandle);
   }

   public void resize(int width, int height) {
      this.width = width;
      this.height = height;
      GL11.glTexImage2D(3553, 0, this.internalFormat, width, height, 0, this.format, this.type, (ByteBuffer)null);
   }

   public int getHandle() {
      return this.glHandle;
   }

   public boolean isDisposed() {
      return this.glHandle == 0;
   }

   public void dispose() {
      if (this.glHandle != 0) {
         GL11.glDeleteTextures(this.glHandle);
         this.glHandle = 0;
      }

   }

   public static class Builder {
      private int width;
      private int height;
      private final int internalFormat;
      private final int format;
      private final int type;
      private int minFilter;
      private int magFilter;
      private int wrapS;
      private int wrapT;

      public Builder(GLTextureFormat format) {
         this(format.getGLFormat(), format.getGLFormat(), format.getGLType());
      }

      public Builder(GLTextureFormat format, int width, int height) {
         this(format.getGLFormat(), format.getGLFormat(), format.getGLType(), width, height);
      }

      public Builder(int internalFormat, int format, int type) {
         this(internalFormat, format, type, Minecraft.func_71410_x().field_71443_c, Minecraft.func_71410_x().field_71440_d);
      }

      public Builder(int internalFormat, int format, int type, int width, int height) {
         this.minFilter = 9728;
         this.magFilter = 9728;
         this.wrapS = 33071;
         this.wrapT = 33071;
         this.internalFormat = internalFormat;
         this.format = format;
         this.type = type;
         this.width = width;
         this.height = height;
      }

      public Builder setSize(int width, int height) {
         this.width = width;
         this.height = height;
         return this;
      }

      public Builder setFilter(int minFilter, int magFilter) {
         this.minFilter = minFilter;
         this.magFilter = magFilter;
         return this;
      }

      public Builder setWrap(int wrapS, int wrapT) {
         this.wrapS = wrapS;
         this.wrapT = wrapT;
         return this;
      }

      public GLTexture build() {
         int glHandle = GL11.glGenTextures();
         GL11.glBindTexture(3553, glHandle);
         GL11.glTexImage2D(3553, 0, this.internalFormat, this.width, this.height, 0, this.format, this.type, (ByteBuffer)null);
         GL11.glTexParameteri(3553, 10241, this.minFilter);
         GL11.glTexParameteri(3553, 10240, this.magFilter);
         GL11.glTexParameteri(3553, 10242, this.wrapS);
         GL11.glTexParameteri(3553, 10243, this.wrapT);
         GLTexture glTexture = new GLTexture(glHandle);
         glTexture.width = this.width;
         glTexture.height = this.height;
         glTexture.internalFormat = this.internalFormat;
         glTexture.format = this.format;
         glTexture.type = this.type;
         glTexture.wrapS = this.wrapS;
         glTexture.wrapT = this.wrapT;
         glTexture.minFilter = this.minFilter;
         glTexture.magFilter = this.magFilter;
         return glTexture;
      }
   }
}

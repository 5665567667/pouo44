package loliland.graphics.renderer.font;

import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\r\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0002\u0010\u0011B\u0017\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nj\u0002\b\u000bj\u0002\b\fj\u0002\b\rj\u0002\b\u000ej\u0002\b\u000f¨\u0006\u0012"},
   d2 = {"Lloliland/graphics/renderer/font/FontRenderMode;", "", "buffer", "Lloliland/graphics/renderer/font/FontRenderMode$Buffer;", "shader", "Lloliland/graphics/renderer/font/FontRenderMode$Shader;", "(Ljava/lang/String;ILloliland/graphics/renderer/font/FontRenderMode$Buffer;Lloliland/graphics/renderer/font/FontRenderMode$Shader;)V", "getBuffer", "()Lloliland/graphics/renderer/font/FontRenderMode$Buffer;", "getShader", "()Lloliland/graphics/renderer/font/FontRenderMode$Shader;", "ACTUAL_VAO", "ACTUAL_VBO", "LEGACY_VAO", "LEGACY_VBO", "SUPER_LEGACY", "Buffer", "Shader", "loligraphics-1.7.10"}
)
public enum FontRenderMode {
   @NotNull
   private final Buffer buffer;
   @NotNull
   private final Shader shader;
   ACTUAL_VAO(FontRenderMode.Buffer.VAO, FontRenderMode.Shader.ACTUAL),
   ACTUAL_VBO(FontRenderMode.Buffer.VBO, FontRenderMode.Shader.ACTUAL),
   LEGACY_VAO(FontRenderMode.Buffer.VAO, FontRenderMode.Shader.LEGACY),
   LEGACY_VBO(FontRenderMode.Buffer.VBO, FontRenderMode.Shader.LEGACY),
   SUPER_LEGACY(FontRenderMode.Buffer.SUPER_LEGACY, FontRenderMode.Shader.SUPER_LEGACY);

   // $FF: synthetic field
   private static final EnumEntries $ENTRIES = EnumEntriesKt.enumEntries($VALUES);

   private FontRenderMode(Buffer buffer, Shader shader) {
      this.buffer = buffer;
      this.shader = shader;
   }

   @NotNull
   public final Buffer getBuffer() {
      return this.buffer;
   }

   @NotNull
   public final Shader getShader() {
      return this.shader;
   }

   @NotNull
   public static EnumEntries<FontRenderMode> getEntries() {
      return $ENTRIES;
   }

   // $FF: synthetic method
   private static final FontRenderMode[] $values() {
      FontRenderMode[] var0 = new FontRenderMode[]{ACTUAL_VAO, ACTUAL_VBO, LEGACY_VAO, LEGACY_VBO, SUPER_LEGACY};
      return var0;
   }

   @Metadata(
      mv = {1, 9, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005¨\u0006\u0006"},
      d2 = {"Lloliland/graphics/renderer/font/FontRenderMode$Buffer;", "", "(Ljava/lang/String;I)V", "VAO", "VBO", "SUPER_LEGACY", "loligraphics-1.7.10"}
   )
   public static enum Buffer {
      VAO,
      VBO,
      SUPER_LEGACY;

      // $FF: synthetic field
      private static final EnumEntries $ENTRIES = EnumEntriesKt.enumEntries($VALUES);

      @NotNull
      public static EnumEntries<Buffer> getEntries() {
         return $ENTRIES;
      }

      // $FF: synthetic method
      private static final Buffer[] $values() {
         Buffer[] var0 = new Buffer[]{VAO, VBO, SUPER_LEGACY};
         return var0;
      }
   }

   @Metadata(
      mv = {1, 9, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005¨\u0006\u0006"},
      d2 = {"Lloliland/graphics/renderer/font/FontRenderMode$Shader;", "", "(Ljava/lang/String;I)V", "ACTUAL", "LEGACY", "SUPER_LEGACY", "loligraphics-1.7.10"}
   )
   public static enum Shader {
      ACTUAL,
      LEGACY,
      SUPER_LEGACY;

      // $FF: synthetic field
      private static final EnumEntries $ENTRIES = EnumEntriesKt.enumEntries($VALUES);

      @NotNull
      public static EnumEntries<Shader> getEntries() {
         return $ENTRIES;
      }

      // $FF: synthetic method
      private static final Shader[] $values() {
         Shader[] var0 = new Shader[]{ACTUAL, LEGACY, SUPER_LEGACY};
         return var0;
      }
   }
}

package loliland.graphics.renderer;

import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.renderer.OpenGlHelper;
import org.lwjglx.opengl.ARBDrawInstanced;
import org.lwjglx.opengl.ARBFramebufferObject;
import org.lwjglx.opengl.ARBImaging;
import org.lwjglx.opengl.ARBInstancedArrays;
import org.lwjglx.opengl.ARBMultitexture;
import org.lwjglx.opengl.ARBOcclusionQuery;
import org.lwjglx.opengl.ARBShaderObjects;
import org.lwjglx.opengl.ARBVertexArrayObject;
import org.lwjglx.opengl.ARBVertexBufferObject;
import org.lwjglx.opengl.ARBVertexProgram;
import org.lwjglx.opengl.ARBVertexShader;
import org.lwjglx.opengl.ContextCapabilities;
import org.lwjglx.opengl.EXTDrawInstanced;
import org.lwjglx.opengl.EXTFramebufferBlit;
import org.lwjglx.opengl.EXTFramebufferObject;
import org.lwjglx.opengl.GL13;
import org.lwjglx.opengl.GL14;
import org.lwjglx.opengl.GL15;
import org.lwjglx.opengl.GL20;
import org.lwjglx.opengl.GL30;
import org.lwjglx.opengl.GL31;
import org.lwjglx.opengl.GL33;
import org.lwjglx.opengl.GLContext;

public class GLCompatible {
   public static String error = "";
   public static int GL_ARRAY_BUFFER;
   public static int GL_ELEMENT_ARRAY_BUFFER;
   public static int GL_DYNAMIC_DRAW;
   public static int GL_STATIC_DRAW;
   public static int GL_TEXTURE0;
   public static int GL_RENDERBUFFER;
   public static int GL_FRAMEBUFFER;
   public static int GL_READ_FRAMEBUFFER;
   public static int GL_DRAW_FRAMEBUFFER;
   public static int GL_RGBA16F;
   public static int GL_DEPTH_ATTACHMENT;
   public static int GL_COLOR_ATTACHMENT0;
   public static int GL_DEPTH_COMPONENT24;
   public static int GL_VERTEX_SHADER;
   public static int GL_FRAGMENT_SHADER;
   public static int GL_COMPILE_STATUS;
   public static int GL_LINK_STATUS;
   public static int GL_VALIDATE_STATUS;
   public static int GL_INFO_LOG_LENGTH;
   public static int GL_CURRENT_PROGRAM;
   public static int GL_FUNC_ADD;
   public static int GL_MAX;
   public static int GL_SAMPLES_PASSED;
   public static int GL_QUERY_RESULT_AVAILABLE;
   public static int GL_QUERY_RESULT;
   public static VAOType vaoType;
   public static FBOType fboType;
   public static InstancingType instancingType;
   public static boolean arbInstancedArrays;
   public static boolean arbImaging;
   public static boolean arbVbo;
   public static boolean arbShaderObject;
   public static boolean arbVertexProgram;
   public static boolean arbVertexShader;
   public static boolean arbFragmentShader;
   public static boolean arbMultitexture;
   public static boolean arbOcclusionQuery;
   public static boolean supportedOpenGL33;
   private static final boolean APPLE_EXTENSIONS = false;
   private static boolean initialized = false;

   public static boolean isInitialized() {
      return initialized;
   }

   public static boolean isVertexArraysSupported() {
      return vaoType != null;
   }

   public static int genVertexArrays() {
      switch (vaoType) {
         case NORMAL:
            return GL30.glGenVertexArrays();
         case ARB:
            return ARBVertexArrayObject.glGenVertexArrays();
         case APPLE:
            return 0;
         default:
            return 0;
      }
   }

   public static void bindVertexArray(int vao) {
      switch (vaoType) {
         case NORMAL:
            GL30.glBindVertexArray(vao);
            break;
         case ARB:
            ARBVertexArrayObject.glBindVertexArray(vao);
         case APPLE:
      }

   }

   public static boolean isVertexArray(int vao) {
      switch (vaoType) {
         case NORMAL:
            return GL30.glIsVertexArray(vao);
         case ARB:
            return ARBVertexArrayObject.glIsVertexArray(vao);
         case APPLE:
            return false;
         default:
            return false;
      }
   }

   public static void deleteVertexArrays(int vao) {
      switch (vaoType) {
         case NORMAL:
            GL30.glDeleteVertexArrays(vao);
            break;
         case ARB:
            ARBVertexArrayObject.glDeleteVertexArrays(vao);
         case APPLE:
      }

   }

   public static int genBuffers() {
      return arbVbo ? ARBVertexBufferObject.glGenBuffersARB() : GL15.glGenBuffers();
   }

   public static void deleteBuffer(int buf) {
      if (arbVbo) {
         ARBVertexBufferObject.glDeleteBuffersARB(buf);
      } else {
         GL15.glDeleteBuffers(buf);
      }

   }

   public static void bindBuffer(int target, int buf) {
      if (arbVbo) {
         ARBVertexBufferObject.glBindBufferARB(target, buf);
      } else {
         GL15.glBindBuffer(target, buf);
      }

   }

   public static void bufferData(int target, ByteBuffer data, int usage) {
      if (arbVbo) {
         ARBVertexBufferObject.glBufferDataARB(target, data, usage);
      } else {
         GL15.glBufferData(target, data, usage);
      }

   }

   public static void bufferData(int target, IntBuffer data, int usage) {
      if (arbVbo) {
         ARBVertexBufferObject.glBufferDataARB(target, data, usage);
      } else {
         GL15.glBufferData(target, data, usage);
      }

   }

   public static void bufferData(int target, FloatBuffer data, int usage) {
      if (arbVbo) {
         ARBVertexBufferObject.glBufferDataARB(target, data, usage);
      } else {
         GL15.glBufferData(target, data, usage);
      }

   }

   public static void bufferData(int target, long size, int usage) {
      if (arbVbo) {
         ARBVertexBufferObject.glBufferDataARB(target, size, usage);
      } else {
         GL15.glBufferData(target, size, usage);
      }

   }

   public static void bufferSubData(int target, long offset, ByteBuffer data) {
      if (arbVbo) {
         ARBVertexBufferObject.glBufferSubDataARB(target, offset, data);
      } else {
         GL15.glBufferSubData(target, offset, data);
      }

   }

   public static void bufferSubData(int target, long offset, IntBuffer data) {
      if (arbVbo) {
         ARBVertexBufferObject.glBufferSubDataARB(target, offset, data);
      } else {
         GL15.glBufferSubData(target, offset, data);
      }

   }

   public static void bufferSubData(int target, long offset, FloatBuffer data) {
      if (arbVbo) {
         ARBVertexBufferObject.glBufferSubDataARB(target, offset, data);
      } else {
         GL15.glBufferSubData(target, offset, data);
      }

   }

   public static void vertexAttribPointer(int index, int size, int type, boolean normalized, int stride, long offset) {
      if (arbVertexProgram) {
         ARBVertexProgram.glVertexAttribPointerARB(index, size, type, normalized, stride, offset);
      } else {
         GL20.glVertexAttribPointer(index, size, type, normalized, stride, offset);
      }

   }

   public static void enableVertexAttribArray(int index) {
      if (arbVertexProgram) {
         ARBVertexProgram.glEnableVertexAttribArrayARB(index);
      } else {
         GL20.glEnableVertexAttribArray(index);
      }

   }

   public static void disableVertexAttribArray(int index) {
      if (arbVertexProgram) {
         ARBVertexProgram.glDisableVertexAttribArrayARB(index);
      } else {
         GL20.glDisableVertexAttribArray(index);
      }

   }

   public static void bindAttribLocation(int program, int index, CharSequence name) {
      if (arbVertexShader) {
         ARBVertexShader.glBindAttribLocationARB(program, index, name);
      } else {
         GL20.glBindAttribLocation(program, index, name);
      }

   }

   public static void deleteFramebuffers(int framebuffer) {
      switch (fboType) {
         case NORMAL:
            GL30.glDeleteFramebuffers(framebuffer);
            break;
         case ARB:
            ARBFramebufferObject.glDeleteFramebuffers(framebuffer);
            break;
         case EXT:
            EXTFramebufferObject.glDeleteFramebuffersEXT(framebuffer);
      }

   }

   public static void bindFramebuffer(int target, int framebuffer) {
      switch (fboType) {
         case NORMAL:
            GL30.glBindFramebuffer(target, framebuffer);
            break;
         case ARB:
            ARBFramebufferObject.glBindFramebuffer(target, framebuffer);
            break;
         case EXT:
            EXTFramebufferObject.glBindFramebufferEXT(target, framebuffer);
      }

   }

   public static void framebufferTexture2D(int target, int attachment, int textarget, int texture, int level) {
      switch (fboType) {
         case NORMAL:
            GL30.glFramebufferTexture2D(target, attachment, textarget, texture, level);
            break;
         case ARB:
            ARBFramebufferObject.glFramebufferTexture2D(target, attachment, textarget, texture, level);
            break;
         case EXT:
            EXTFramebufferObject.glFramebufferTexture2DEXT(target, attachment, textarget, texture, level);
      }

   }

   public static void bindRenderbuffer(int target, int renderbuffer) {
      switch (fboType) {
         case NORMAL:
            GL30.glBindRenderbuffer(target, renderbuffer);
            break;
         case ARB:
            ARBFramebufferObject.glBindRenderbuffer(target, renderbuffer);
            break;
         case EXT:
            EXTFramebufferObject.glBindRenderbufferEXT(target, renderbuffer);
      }

   }

   public static int genRenderbuffers() {
      switch (fboType) {
         case NORMAL:
            return GL30.glGenRenderbuffers();
         case ARB:
            return ARBFramebufferObject.glGenRenderbuffers();
         case EXT:
            return EXTFramebufferObject.glGenRenderbuffersEXT();
         default:
            return 0;
      }
   }

   public static void renderbufferStorage(int target, int internalformat, int width, int height) {
      switch (fboType) {
         case NORMAL:
            GL30.glRenderbufferStorage(target, internalformat, width, height);
            break;
         case ARB:
            ARBFramebufferObject.glRenderbufferStorage(target, internalformat, width, height);
            break;
         case EXT:
            EXTFramebufferObject.glRenderbufferStorageEXT(target, internalformat, width, height);
      }

   }

   public static void framebufferRenderbuffer(int target, int attachment, int renderbuffertarget, int renderbuffer) {
      switch (fboType) {
         case NORMAL:
            GL30.glFramebufferRenderbuffer(target, attachment, renderbuffertarget, renderbuffer);
            break;
         case ARB:
            ARBFramebufferObject.glFramebufferRenderbuffer(target, attachment, renderbuffertarget, renderbuffer);
            break;
         case EXT:
            EXTFramebufferObject.glFramebufferRenderbufferEXT(target, attachment, renderbuffertarget, renderbuffer);
      }

   }

   public static void deleteRenderbuffers(int renderbuffer) {
      switch (fboType) {
         case NORMAL:
            GL30.glDeleteRenderbuffers(renderbuffer);
            break;
         case ARB:
            ARBFramebufferObject.glDeleteRenderbuffers(renderbuffer);
            break;
         case EXT:
            EXTFramebufferObject.glDeleteRenderbuffersEXT(renderbuffer);
      }

   }

   public static int genFramebuffers() {
      switch (fboType) {
         case NORMAL:
            return GL30.glGenFramebuffers();
         case ARB:
            return ARBFramebufferObject.glGenFramebuffers();
         case EXT:
            return EXTFramebufferObject.glGenFramebuffersEXT();
         default:
            return 0;
      }
   }

   public static void blitFramebuffer(int srcX0, int srcY0, int srcX1, int srcY1, int dstX0, int dstY0, int dstX1, int dstY1, int mask, int filter) {
      switch (fboType) {
         case NORMAL:
            GL30.glBlitFramebuffer(srcX0, srcY0, srcX1, srcY1, dstX0, dstY0, dstX1, dstY1, mask, filter);
            break;
         case ARB:
            ARBFramebufferObject.glBlitFramebuffer(srcX0, srcY0, srcX1, srcY1, dstX0, dstY0, dstX1, dstY1, mask, filter);
            break;
         case EXT:
            EXTFramebufferBlit.glBlitFramebufferEXT(srcX0, srcY0, srcX1, srcY1, dstX0, dstY0, dstX1, dstY1, mask, filter);
      }

   }

   public static void activeTexture(int tex) {
      if (arbMultitexture) {
         ARBMultitexture.glActiveTextureARB(tex);
      } else {
         GL13.glActiveTexture(tex);
      }

   }

   public static void blendEquation(int mode) {
      if (arbImaging) {
         ARBImaging.glBlendEquation(mode);
      } else {
         GL14.glBlendEquation(mode);
      }

   }

   public static void glBlendFunc(int sFactor, int dFactor, int sFactorAlpha, int dFactorAlpha) {
      OpenGlHelper.func_148821_a(sFactor, dFactor, sFactorAlpha, dFactorAlpha);
   }

   public static void drawArraysInstanced(int mode, int first, int count, int primcount) {
      switch (instancingType) {
         case NORMAL:
            GL31.glDrawArraysInstanced(mode, first, count, primcount);
            break;
         case ARB:
            ARBDrawInstanced.glDrawArraysInstancedARB(mode, first, count, primcount);
            break;
         case EXT:
            EXTDrawInstanced.glDrawArraysInstancedEXT(mode, first, count, primcount);
      }

   }

   public static void vertexAttribDivisor(int index, int divisor) {
      if (arbInstancedArrays) {
         ARBInstancedArrays.glVertexAttribDivisorARB(index, divisor);
      } else {
         GL33.glVertexAttribDivisor(index, divisor);
      }

   }

   public static int genQueries() {
      return arbOcclusionQuery ? ARBOcclusionQuery.glGenQueriesARB() : GL15.glGenQueries();
   }

   public static void beginQuery(int target, int id) {
      if (arbOcclusionQuery) {
         ARBOcclusionQuery.glBeginQueryARB(target, id);
      } else {
         GL15.glBeginQuery(target, id);
      }

   }

   public static void endQuery(int target) {
      if (arbOcclusionQuery) {
         ARBOcclusionQuery.glEndQueryARB(target);
      } else {
         GL15.glEndQuery(target);
      }

   }

   public static void deleteQueries(int id) {
      if (arbOcclusionQuery) {
         ARBOcclusionQuery.glDeleteQueriesARB(id);
      } else {
         GL15.glDeleteQueries(id);
      }

   }

   public static int getQueryObject(int id, int pname) {
      return arbOcclusionQuery ? ARBOcclusionQuery.glGetQueryObjectuiARB(id, pname) : GL15.glGetQueryObjectui(id, pname);
   }

   public static int getUniformLocation(int program, CharSequence name) {
      return arbShaderObject ? ARBShaderObjects.glGetUniformLocationARB(program, name) : GL20.glGetUniformLocation(program, name);
   }

   public static void uniform1i(int location, int i) {
      if (arbShaderObject) {
         ARBShaderObjects.glUniform1iARB(location, i);
      } else {
         GL20.glUniform1i(location, i);
      }

   }

   public static void uniform2i(int location, int i1, int i2) {
      if (arbShaderObject) {
         ARBShaderObjects.glUniform2iARB(location, i1, i2);
      } else {
         GL20.glUniform2i(location, i1, i2);
      }

   }

   public static void uniform3i(int location, int i1, int i2, int i3) {
      if (arbShaderObject) {
         ARBShaderObjects.glUniform3iARB(location, i1, i2, i3);
      } else {
         GL20.glUniform3i(location, i1, i2, i3);
      }

   }

   public static void uniform4i(int location, int i1, int i2, int i3, int i4) {
      if (arbShaderObject) {
         ARBShaderObjects.glUniform4iARB(location, i1, i2, i3, i4);
      } else {
         GL20.glUniform4i(location, i1, i2, i3, i4);
      }

   }

   public static void uniform1f(int location, float f) {
      if (arbShaderObject) {
         ARBShaderObjects.glUniform1fARB(location, f);
      } else {
         GL20.glUniform1f(location, f);
      }

   }

   public static void uniform2f(int location, float f1, float f2) {
      if (arbShaderObject) {
         ARBShaderObjects.glUniform2fARB(location, f1, f2);
      } else {
         GL20.glUniform2f(location, f1, f2);
      }

   }

   public static void uniform3f(int location, float f1, float f2, float f3) {
      if (arbShaderObject) {
         ARBShaderObjects.glUniform3fARB(location, f1, f2, f3);
      } else {
         GL20.glUniform3f(location, f1, f2, f3);
      }

   }

   public static void uniform4f(int location, float f1, float f2, float f3, float f4) {
      if (arbShaderObject) {
         ARBShaderObjects.glUniform4fARB(location, f1, f2, f3, f4);
      } else {
         GL20.glUniform4f(location, f1, f2, f3, f4);
      }

   }

   public static void uniformMatrix3(int location, boolean transpose, FloatBuffer matrices) {
      if (arbShaderObject) {
         ARBShaderObjects.glUniformMatrix3ARB(location, transpose, matrices);
      } else {
         GL20.glUniformMatrix3(location, transpose, matrices);
      }

   }

   public static void uniformMatrix4(int location, boolean transpose, FloatBuffer matrices) {
      if (arbShaderObject) {
         ARBShaderObjects.glUniformMatrix4ARB(location, transpose, matrices);
      } else {
         GL20.glUniformMatrix4(location, transpose, matrices);
      }

   }

   public static void uniformFloatArray(int location, FloatBuffer floats) {
      if (arbShaderObject) {
         ARBShaderObjects.glUniform1ARB(location, floats);
      } else {
         GL20.glUniform1(location, floats);
      }

   }

   public static void uniform4fArray(int location, FloatBuffer vectors) {
      if (arbShaderObject) {
         ARBShaderObjects.glUniform4ARB(location, vectors);
      } else {
         GL20.glUniform4(location, vectors);
      }

   }

   public static int createProgram() {
      return arbShaderObject ? ARBShaderObjects.glCreateProgramObjectARB() : GL20.glCreateProgram();
   }

   public static int createShader(int shaderType) {
      return arbShaderObject ? ARBShaderObjects.glCreateShaderObjectARB(shaderType) : GL20.glCreateShader(shaderType);
   }

   public static void shaderSource(int shader, ByteBuffer string) {
      if (arbShaderObject) {
         ARBShaderObjects.glShaderSourceARB(shader, string);
      } else {
         GL20.glShaderSource(shader, string);
      }

   }

   public static void shaderSource(int shader, String string) {
      if (arbShaderObject) {
         ARBShaderObjects.glShaderSourceARB(shader, string);
      } else {
         GL20.glShaderSource(shader, string);
      }

   }

   public static void compileShader(int shader) {
      if (arbShaderObject) {
         ARBShaderObjects.glCompileShaderARB(shader);
      } else {
         GL20.glCompileShader(shader);
      }

   }

   public static int getShaderi(int shader, int pname) {
      return arbShaderObject ? ARBShaderObjects.glGetObjectParameteriARB(shader, pname) : GL20.glGetShaderi(shader, pname);
   }

   public static String getShaderInfoLog(int shader, int length) {
      return arbShaderObject ? ARBShaderObjects.glGetInfoLogARB(shader, length) : GL20.glGetShaderInfoLog(shader, length);
   }

   public static void attachShader(int program, int shader) {
      if (arbShaderObject) {
         ARBShaderObjects.glAttachObjectARB(program, shader);
      } else {
         GL20.glAttachShader(program, shader);
      }

   }

   public static void detachShader(int program, int shader) {
      if (arbShaderObject) {
         ARBShaderObjects.glDetachObjectARB(program, shader);
      } else {
         GL20.glDetachShader(program, shader);
      }

   }

   public static void linkProgram(int program) {
      if (arbShaderObject) {
         ARBShaderObjects.glLinkProgramARB(program);
      } else {
         GL20.glLinkProgram(program);
      }

   }

   public static void validateProgram(int program) {
      if (arbShaderObject) {
         ARBShaderObjects.glValidateProgramARB(program);
      } else {
         GL20.glValidateProgram(program);
      }

   }

   public static int getProgrami(int program, int pname) {
      return arbShaderObject ? ARBShaderObjects.glGetObjectParameteriARB(program, pname) : GL20.glGetProgrami(program, pname);
   }

   public static String getProgramInfoLog(int program, int length) {
      return arbShaderObject ? ARBShaderObjects.glGetInfoLogARB(program, length) : GL20.glGetProgramInfoLog(program, length);
   }

   public static void deleteShader(int shader) {
      if (arbShaderObject) {
         ARBShaderObjects.glDeleteObjectARB(shader);
      } else {
         GL20.glDeleteShader(shader);
      }

   }

   public static void deleteProgram(int program) {
      if (!arbShaderObject) {
         GL20.glDeleteProgram(program);
      }

   }

   public static void useProgram(int program) {
      if (arbShaderObject) {
         ARBShaderObjects.glUseProgramObjectARB(program);
      } else {
         GL20.glUseProgram(program);
      }

   }

   public static String init() {
      ContextCapabilities cap = GLContext.getCapabilities();
      List<String> errors = new ArrayList();
      supportedOpenGL33 = cap.OpenGL33;
      if (cap.OpenGL30) {
         vaoType = GLCompatible.VAOType.NORMAL;
      } else if (cap.GL_ARB_vertex_array_object) {
         vaoType = GLCompatible.VAOType.ARB;
      } else {
         errors.add("VAO not supported");
      }

      if (cap.OpenGL15) {
         arbVbo = false;
      } else if (cap.GL_ARB_vertex_buffer_object) {
         arbVbo = true;
      } else {
         errors.add("VBO not supported");
      }

      if (cap.OpenGL31) {
         instancingType = GLCompatible.InstancingType.NORMAL;
      } else if (cap.GL_ARB_draw_instanced) {
         instancingType = GLCompatible.InstancingType.ARB;
      } else if (cap.GL_EXT_draw_instanced) {
         instancingType = GLCompatible.InstancingType.EXT;
      } else {
         errors.add("Instancing not supported");
      }

      if (cap.OpenGL33) {
         arbInstancedArrays = false;
      } else if (cap.GL_ARB_instanced_arrays) {
         arbInstancedArrays = true;
      } else {
         errors.add("Instanced arrays not supported");
      }

      if (cap.OpenGL20) {
         arbShaderObject = false;
      } else if (cap.GL_ARB_shader_objects) {
         arbShaderObject = true;
      } else {
         errors.add("Shaders not supported");
      }

      if (cap.OpenGL20) {
         arbVertexProgram = false;
      } else if (cap.GL_ARB_vertex_program) {
         arbVertexProgram = true;
      } else {
         errors.add("Vertex program not supported");
      }

      if (cap.OpenGL20) {
         arbVertexShader = false;
      } else if (cap.GL_ARB_vertex_shader) {
         arbVertexShader = true;
      } else {
         errors.add("Vertex shader not supported");
      }

      if (cap.OpenGL20) {
         arbFragmentShader = false;
      } else if (cap.GL_ARB_fragment_shader) {
         arbFragmentShader = true;
      } else {
         errors.add("Fragment shader not supported");
      }

      if (cap.OpenGL30) {
         fboType = GLCompatible.FBOType.NORMAL;
      } else if (cap.GL_ARB_framebuffer_object) {
         fboType = GLCompatible.FBOType.ARB;
      } else if (cap.GL_EXT_framebuffer_object && cap.GL_EXT_framebuffer_blit) {
         fboType = GLCompatible.FBOType.EXT;
      } else {
         errors.add("Framebuffer objects not supported");
      }

      if (cap.OpenGL13) {
         arbMultitexture = false;
      } else if (cap.GL_ARB_multitexture) {
         arbMultitexture = true;
      } else {
         errors.add("Multitexturing not supported");
      }

      if (cap.OpenGL14) {
         arbImaging = false;
      } else if (cap.GL_ARB_imaging) {
         arbImaging = true;
      } else {
         errors.add("Imaging not supported");
      }

      if (cap.OpenGL15) {
         arbOcclusionQuery = false;
      } else if (cap.GL_ARB_occlusion_query) {
         arbOcclusionQuery = true;
      } else {
         errors.add("Occlusion queries not supported");
      }

      if (arbVertexProgram) {
         GL_ARRAY_BUFFER = 34962;
         GL_ELEMENT_ARRAY_BUFFER = 34963;
         GL_DYNAMIC_DRAW = 35048;
         GL_STATIC_DRAW = 35044;
      } else {
         GL_ARRAY_BUFFER = 34962;
         GL_ELEMENT_ARRAY_BUFFER = 34963;
         GL_DYNAMIC_DRAW = 35048;
         GL_STATIC_DRAW = 35044;
      }

      if (arbMultitexture) {
         GL_TEXTURE0 = 33984;
      } else {
         GL_TEXTURE0 = 33984;
      }

      if (fboType == GLCompatible.FBOType.NORMAL) {
         GL_RENDERBUFFER = 36161;
         GL_FRAMEBUFFER = 36160;
         GL_READ_FRAMEBUFFER = 36008;
         GL_DRAW_FRAMEBUFFER = 36009;
         GL_DEPTH_ATTACHMENT = 36096;
         GL_COLOR_ATTACHMENT0 = 36064;
      } else if (fboType == GLCompatible.FBOType.ARB) {
         GL_RENDERBUFFER = 36161;
         GL_FRAMEBUFFER = 36160;
         GL_READ_FRAMEBUFFER = 36008;
         GL_DRAW_FRAMEBUFFER = 36009;
         GL_DEPTH_ATTACHMENT = 36096;
         GL_COLOR_ATTACHMENT0 = 36064;
      } else if (fboType == GLCompatible.FBOType.EXT) {
         GL_RENDERBUFFER = 36161;
         GL_FRAMEBUFFER = 36160;
         GL_READ_FRAMEBUFFER = 36008;
         GL_DRAW_FRAMEBUFFER = 36009;
         GL_DEPTH_ATTACHMENT = 36096;
         GL_COLOR_ATTACHMENT0 = 36064;
      }

      if (cap.OpenGL30) {
         GL_RGBA16F = 34842;
      } else if (cap.GL_APPLE_float_pixels) {
         GL_RGBA16F = 34842;
      } else if (cap.GL_ARB_texture_float) {
         GL_RGBA16F = 34842;
      } else if (cap.GL_ATI_texture_float) {
         GL_RGBA16F = 34842;
      } else {
         errors.add("Floating point texture format not supported");
      }

      if (cap.OpenGL14) {
         GL_DEPTH_COMPONENT24 = 33190;
      } else if (cap.GL_ARB_depth_texture) {
         GL_DEPTH_COMPONENT24 = 33190;
      } else {
         errors.add("24 bit depth not supported");
      }

      if (arbShaderObject) {
         GL_COMPILE_STATUS = 35713;
         GL_LINK_STATUS = 35714;
         GL_VALIDATE_STATUS = 35715;
         GL_INFO_LOG_LENGTH = 35716;
      } else {
         GL_COMPILE_STATUS = 35713;
         GL_LINK_STATUS = 35714;
         GL_VALIDATE_STATUS = 35715;
         GL_INFO_LOG_LENGTH = 35716;
      }

      GL_CURRENT_PROGRAM = 35725;
      if (arbVertexShader) {
         GL_VERTEX_SHADER = 35633;
      } else {
         GL_VERTEX_SHADER = 35633;
      }

      if (arbFragmentShader) {
         GL_FRAGMENT_SHADER = 35632;
      } else {
         GL_FRAGMENT_SHADER = 35632;
      }

      if (arbImaging) {
         GL_FUNC_ADD = 32774;
         GL_MAX = 32776;
      } else {
         GL_FUNC_ADD = 32774;
         GL_MAX = 32776;
      }

      if (arbOcclusionQuery) {
         GL_SAMPLES_PASSED = 35092;
         GL_QUERY_RESULT_AVAILABLE = 34919;
         GL_QUERY_RESULT = 34918;
      } else {
         GL_SAMPLES_PASSED = 35092;
         GL_QUERY_RESULT_AVAILABLE = 34919;
         GL_QUERY_RESULT = 34918;
      }

      initialized = true;
      if (errors.isEmpty()) {
         return "";
      } else {
         return errors.size() == 1 ? (String)errors.get(0) : errors.toString();
      }
   }

   public static enum VAOType {
      NORMAL,
      ARB,
      APPLE;
   }

   public static enum FBOType {
      NORMAL,
      ARB,
      EXT;
   }

   public static enum InstancingType {
      NORMAL,
      ARB,
      EXT;
   }
}

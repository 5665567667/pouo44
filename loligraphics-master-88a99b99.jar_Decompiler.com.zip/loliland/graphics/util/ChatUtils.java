package loliland.graphics.util;

import com.google.common.collect.HashBiMap;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.MapsKt;
import kotlin.jvm.JvmName;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.math.MathKt;
import kotlin.ranges.RangesKt;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 9, 0},
   k = 2,
   xi = 48,
   d1 = {"\u00000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\f\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u0007\n\u0002\b\u0002\u001a\u0012\u0010\t\u001a\u00020\n*\u00020\n2\u0006\u0010\u000b\u001a\u00020\u0002\u001a$\u0010\f\u001a\u00020\r*\u00020\n2\u0012\u0010\u000e\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\r0\u000fH\u0086\bø\u0001\u0000\u001a\u001a\u0010\u0010\u001a\u00020\u0003*\u00020\n2\u0006\u0010\u0011\u001a\u00020\u00032\u0006\u0010\u0012\u001a\u00020\u0002\u001a\u001a\u0010\u0013\u001a\u00020\u0003*\u00020\n2\u0006\u0010\u0011\u001a\u00020\u00032\u0006\u0010\u0014\u001a\u00020\u0002\u001a\u0012\u0010\u0015\u001a\u00020\n*\u00020\n2\u0006\u0010\u0016\u001a\u00020\u0017\u001a\u0012\u0010\u0015\u001a\u00020\n*\u00020\n2\u0006\u0010\u0016\u001a\u00020\u0003\u001a\n\u0010\u0018\u001a\u00020\n*\u00020\n\"\u001d\u0010\u0000\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0004\u0010\u0005\"\u000e\u0010\u0006\u001a\u00020\u0002X\u0086T¢\u0006\u0002\n\u0000\"\u000e\u0010\u0007\u001a\u00020\u0002X\u0086T¢\u0006\u0002\n\u0000\"\u000e\u0010\b\u001a\u00020\u0002X\u0086T¢\u0006\u0002\n\u0000\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006\u0019"},
   d2 = {"CHAT_COLORS_CODES", "Lcom/google/common/collect/HashBiMap;", "", "", "getCHAT_COLORS_CODES", "()Lcom/google/common/collect/HashBiMap;", "FORMATTING_PREFIX", "RENDER_ALPHA_PREFIX", "RESET_FORMATTING_CODE", "colored", "", "color", "forEachVisibleChar", "", "action", "Lkotlin/Function1;", "isAlphaCodeAt", "i", "alphaPrefix", "isFormatCodeAt", "formatPrefix", "withAlpha", "alpha", "", "withoutFormattingCodes", "loligraphics-1.7.10"}
)
@JvmName(
   name = "ChatUtils"
)
public final class ChatUtils {
   public static final char FORMATTING_PREFIX = '§';
   public static final char RENDER_ALPHA_PREFIX = '¤';
   public static final char RESET_FORMATTING_CODE = 'r';
   @NotNull
   private static final HashBiMap<Character, Integer> CHAT_COLORS_CODES;

   @NotNull
   public static final HashBiMap<Character, Integer> getCHAT_COLORS_CODES() {
      return CHAT_COLORS_CODES;
   }

   public static final int isAlphaCodeAt(@NotNull String $this$isAlphaCodeAt, int i, char alphaPrefix) {
      Intrinsics.checkNotNullParameter($this$isAlphaCodeAt, "<this>");
      if (i < $this$isAlphaCodeAt.length() && $this$isAlphaCodeAt.charAt(i) == alphaPrefix) {
         if (i + 1 >= $this$isAlphaCodeAt.length()) {
            return 0;
         } else {
            char c1 = $this$isAlphaCodeAt.charAt(i + 1);
            if (c1 == 'r') {
               return 2;
            } else {
               if (i + 3 < $this$isAlphaCodeAt.length()) {
                  char d1 = $this$isAlphaCodeAt.charAt(i + 1);
                  char d2 = $this$isAlphaCodeAt.charAt(i + 2);
                  char d3 = $this$isAlphaCodeAt.charAt(i + 3);
                  if (Character.isDigit(d1) && Character.isDigit(d2) && Character.isDigit(d3)) {
                     return 4;
                  }
               }

               return 0;
            }
         }
      } else {
         return 0;
      }
   }

   public static final int isFormatCodeAt(@NotNull String $this$isFormatCodeAt, int i, char formatPrefix) {
      Intrinsics.checkNotNullParameter($this$isFormatCodeAt, "<this>");
      return i + 1 < $this$isFormatCodeAt.length() && $this$isFormatCodeAt.charAt(i) == formatPrefix ? 2 : 0;
   }

   @NotNull
   public static final String withoutFormattingCodes(@NotNull String $this$withoutFormattingCodes) {
      Intrinsics.checkNotNullParameter($this$withoutFormattingCodes, "<this>");
      String s = $this$withoutFormattingCodes;
      int n = $this$withoutFormattingCodes.length();
      if (n == 0) {
         return $this$withoutFormattingCodes;
      } else {
         Ref.ObjectRef out = new Ref.ObjectRef();
         int i = 0;

         while(i < n) {
            int skipFormat = isFormatCodeAt(s, i, '§');
            if (skipFormat != 0) {
               withoutFormattingCodes$ensureOut(out, n, s, i);
               i += skipFormat;
            } else {
               int skipAlpha = isAlphaCodeAt(s, i, '¤');
               if (skipAlpha != 0) {
                  withoutFormattingCodes$ensureOut(out, n, s, i);
                  i += skipAlpha;
               } else {
                  StringBuilder var10000 = (StringBuilder)out.element;
                  if (var10000 != null) {
                     var10000.append(s.charAt(i));
                  }

                  ++i;
               }
            }
         }

         StringBuilder var7 = (StringBuilder)out.element;
         String var8 = var7 != null ? var7.toString() : null;
         if (var8 == null) {
            var8 = s;
         }

         return var8;
      }
   }

   public static final void forEachVisibleChar(@NotNull String $this$forEachVisibleChar, @NotNull Function1<? super Character, Unit> action) {
      Intrinsics.checkNotNullParameter($this$forEachVisibleChar, "<this>");
      Intrinsics.checkNotNullParameter(action, "action");
      int $i$f$forEachVisibleChar = 0;
      int n = $this$forEachVisibleChar.length();
      int i = 0;

      while(i < n) {
         int skipFormat = isFormatCodeAt($this$forEachVisibleChar, i, '§');
         if (skipFormat != 0) {
            i += skipFormat;
         } else {
            int skipAlpha = isAlphaCodeAt($this$forEachVisibleChar, i, '¤');
            if (skipAlpha != 0) {
               i += skipAlpha;
            } else {
               action.invoke($this$forEachVisibleChar.charAt(i));
               ++i;
            }
         }
      }

   }

   @NotNull
   public static final String colored(@NotNull String $this$colored, char color) {
      Intrinsics.checkNotNullParameter($this$colored, "<this>");
      return "" + '§' + color + $this$colored + "§r";
   }

   @NotNull
   public static final String withAlpha(@NotNull String $this$withAlpha, int alpha) {
      Intrinsics.checkNotNullParameter($this$withAlpha, "<this>");
      int var2 = $this$withAlpha.length() + 6;
      StringBuilder $this$withAlpha_u24lambda_u240 = new StringBuilder(var2);
      int var5 = 0;
      int startCode = 48;
      int a = RangesKt.coerceIn(alpha, 0, 255);
      $this$withAlpha_u24lambda_u240.append('¤');
      $this$withAlpha_u24lambda_u240.append((char)(startCode + a / 100));
      $this$withAlpha_u24lambda_u240.append((char)(startCode + a / 10 % 10));
      $this$withAlpha_u24lambda_u240.append((char)(startCode + a % 10));
      $this$withAlpha_u24lambda_u240.append($this$withAlpha);
      $this$withAlpha_u24lambda_u240.append('¤');
      $this$withAlpha_u24lambda_u240.append('r');
      String var10000 = $this$withAlpha_u24lambda_u240.toString();
      Intrinsics.checkNotNullExpressionValue(var10000, "toString(...)");
      return var10000;
   }

   @NotNull
   public static final String withAlpha(@NotNull String $this$withAlpha, float alpha) {
      Intrinsics.checkNotNullParameter($this$withAlpha, "<this>");
      return withAlpha($this$withAlpha, MathKt.roundToInt(alpha * 255.0F));
   }

   private static final void withoutFormattingCodes$ensureOut(Ref.ObjectRef<StringBuilder> out, int n, String s, int cutIndex) {
      if (out.element == null) {
         out.element = (new StringBuilder(n)).append((CharSequence)s, 0, cutIndex);
      }

   }

   static {
      Pair[] var0 = new Pair[]{TuplesKt.to('0', -16777216), TuplesKt.to('1', -16777046), TuplesKt.to('2', -16733696), TuplesKt.to('3', -16733526), TuplesKt.to('4', -5636096), TuplesKt.to('5', -5635926), TuplesKt.to('6', -22016), TuplesKt.to('7', -5592406), TuplesKt.to('8', -11184811), TuplesKt.to('9', -11184641), TuplesKt.to('a', -11141291), TuplesKt.to('b', -11141121), TuplesKt.to('c', -43691), TuplesKt.to('d', -43521), TuplesKt.to('e', -171), TuplesKt.to('f', -1), TuplesKt.to('g', -2238971), TuplesKt.to('а', -65536), TuplesKt.to('б', -52480), TuplesKt.to('в', -39424), TuplesKt.to('г', -26368), TuplesKt.to('д', -13312), TuplesKt.to('е', -256), TuplesKt.to('ё', -3342592), TuplesKt.to('ж', -6684928), TuplesKt.to('з', -10027264), TuplesKt.to('и', -13369600), TuplesKt.to('й', -16711783), TuplesKt.to('к', -16711681), TuplesKt.to('л', -16724737), TuplesKt.to('м', -16737793), TuplesKt.to('н', -16750849), TuplesKt.to('о', -16763905), TuplesKt.to('п', -10092289), TuplesKt.to('р', -6749953), TuplesKt.to('с', -3407617), TuplesKt.to('т', -65281), TuplesKt.to('у', -65332), TuplesKt.to('ф', -65434), TuplesKt.to('х', -65485), TuplesKt.to('ц', -15592942)};
      HashBiMap var10000 = HashBiMap.create(MapsKt.mapOf(var0));
      Intrinsics.checkNotNullExpressionValue(var10000, "create(...)");
      CHAT_COLORS_CODES = var10000;
   }
}

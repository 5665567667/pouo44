package loliland.graphics.renderer.shader;

import cpw.mods.fml.common.ProgressManager;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.io.CloseableKt;
import kotlin.io.TextStreamsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import loliland.graphics.LoliGraphics;
import loliland.graphics.renderer.GLCompatible;
import loliland.graphics.renderer.shader.uniform.Uniform;
import loliland.graphics.util.ResourceExtensionsKt;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.client.resources.IResourceManagerReloadListener;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.util.ReportedException;
import net.minecraft.util.ResourceLocation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000V\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010%\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u000e\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\tJ \u0010\r\u001a\u00020\u000e2\u0006\u0010\f\u001a\u00020\t2\u0006\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0010\u001a\u00020\bH\u0002J\u0010\u0010\u0011\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\tH\u0002J\u000e\u0010\u0012\u001a\u00020\u00132\u0006\u0010\f\u001a\u00020\tJ\u000e\u0010\u0014\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\tJ\u0010\u0010\u0015\u001a\u00020\u000b2\u0006\u0010\u0016\u001a\u00020\u0017H\u0016J\u000e\u0010\u0018\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\tJ\u0010\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u000f\u001a\u00020\u000eH\u0002J\u000e\u0010\u001b\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\tJI\u0010\u001c\u001a\u00020\u000b\"\b\b\u0000\u0010\u001d*\u00020\t2\u0006\u0010\f\u001a\u0002H\u001d2\u0017\u0010\u001e\u001a\u0013\u0012\u0004\u0012\u0002H\u001d\u0012\u0004\u0012\u00020\u000b0\u001f¢\u0006\u0002\b H\u0086\bø\u0001\u0000\u0082\u0002\n\n\b\b\u0001\u0012\u0002\u0010\u0002 \u0001¢\u0006\u0002\u0010!R\u0016\u0010\u0003\u001a\n \u0005*\u0004\u0018\u00010\u00040\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006\""},
   d2 = {"Lloliland/graphics/renderer/shader/ShaderManager;", "Lnet/minecraft/client/resources/IResourceManagerReloadListener;", "()V", "log", "Lorg/apache/logging/log4j/Logger;", "kotlin.jvm.PlatformType", "shaders", "", "Lnet/minecraft/util/ResourceLocation;", "Lloliland/graphics/renderer/shader/Shader;", "bindShader", "", "shader", "createShaderType", "", "type", "location", "doLoadShader", "isShaderLoaded", "", "loadShader", "onResourceManagerReload", "resourceManager", "Lnet/minecraft/client/resources/IResourceManager;", "schedulePreload", "shaderTypeString", "", "unbindShader", "useShader", "S", "block", "Lkotlin/Function1;", "Lkotlin/ExtensionFunctionType;", "(Lloliland/graphics/renderer/shader/Shader;Lkotlin/jvm/functions/Function1;)V", "loligraphics-1.7.10"}
)
@SourceDebugExtension({"SMAP\nShaderManager.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ShaderManager.kt\nloliland/graphics/renderer/shader/ShaderManager\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 ResourceExtensions.kt\nloliland/graphics/util/ResourceExtensionsKt\n+ 5 _Maps.kt\nkotlin/collections/MapsKt___MapsKt\n*L\n1#1,166:1\n1#2:167\n1549#3:168\n1620#3,2:169\n1622#3:172\n1864#3,3:173\n1855#3,2:176\n1855#3,2:178\n766#3:180\n857#3,2:181\n1855#3,2:183\n30#4:171\n215#5,2:185\n*S KotlinDebug\n*F\n+ 1 ShaderManager.kt\nloliland/graphics/renderer/shader/ShaderManager\n*L\n59#1:168\n59#1:169,2\n59#1:172\n64#1:173,3\n68#1:176,2\n79#1:178,2\n92#1:180\n92#1:181,2\n92#1:183,2\n60#1:171\n149#1:185,2\n*E\n"})
public final class ShaderManager implements IResourceManagerReloadListener {
   @NotNull
   public static final ShaderManager INSTANCE = new ShaderManager();
   private static final Logger log = LogManager.getLogger("Shader Manager");
   @NotNull
   private static final Map<ResourceLocation, Shader> shaders = (Map)(new LinkedHashMap());

   private ShaderManager() {
   }

   public final void loadShader(@NotNull Shader shader) {
      Intrinsics.checkNotNullParameter(shader, "shader");

      try {
         this.doLoadShader(shader);
         Logger var10000 = log;
         Object[] var2 = new Object[]{shader.getLocation()};
         var10000.debug("Loaded shader: {}", var2);
      } catch (Throwable e) {
         CrashReport report = CrashReport.func_85055_a(e, "Registering shader");
         CrashReportCategory category = report.func_85058_a("Resource location being registered");
         category.func_71507_a("Resource location", shader.getLocation());
         category.func_71500_a("Shader object class", ShaderManager::loadShader$lambda$0);
         throw new ReportedException(report);
      }
   }

   public final void schedulePreload(@NotNull Shader shader) {
      Intrinsics.checkNotNullParameter(shader, "shader");
      shaders.putIfAbsent(shader.getLocation(), shader);
   }

   private final void doLoadShader(Shader shader) {
      if (!LoliGraphics.INSTANCE.getInitialized()) {
         int shadersIds = 0;
         String var19 = "LoliGraphics not initialized.";
         throw new IllegalStateException(var19.toString());
      } else {
         shader.dispose();
         shader.setLoaded(true);
         shaders.put(shader.getLocation(), shader);
         int programId = GLCompatible.createProgram();
         if (programId <= 0) {
            int var29 = 0;
            String var30 = "Could not create shader program: " + shader.getLocation() + ". Maybe, shaders not supported :(";
            throw new IllegalStateException(var30.toString());
         } else {
            shader.setProgramId(programId);
            if (((Collection)shader.getTypes()).isEmpty()) {
               int $this$filter$iv = 0;
               String $this$forEach$iv = "The shader must contain at least one shader type (vertex, fragment, etc.)";
               throw new IllegalStateException($this$forEach$iv.toString());
            } else {
               Iterable $this$map$iv = (Iterable)shader.getTypes();
               int $i$f$map = 0;
               Collection destination$iv$iv = (Collection)(new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10)));
               int $i$f$mapTo = 0;

               for(Object item$iv$iv : $this$map$iv) {
                  int shaderType = ((Number)item$iv$iv).intValue();
                  int var13 = 0;
                  ResourceLocation $this$addPath$iv = shader.getLocation();
                  String path$iv = '/' + INSTANCE.shaderTypeString(shaderType) + ".glsl";
                  int $i$f$addPath = 0;
                  ResourceLocation location = new ResourceLocation($this$addPath$iv.func_110624_b(), $this$addPath$iv.func_110623_a() + path$iv);
                  destination$iv$iv.add(INSTANCE.createShaderType(shader, shaderType, location));
               }

               List shadersIds = (List)destination$iv$iv;
               $this$map$iv = (Iterable)shader.getAttributes();
               $i$f$map = 0;
               int index$iv = 0;

               for(Object item$iv : $this$map$iv) {
                  int index = index$iv++;
                  if (index < 0) {
                     CollectionsKt.throwIndexOverflow();
                  }

                  String attribute = (String)item$iv;
                  int var58 = 0;
                  GLCompatible.bindAttribLocation(programId, index, (CharSequence)attribute);
               }

               $this$map$iv = (Iterable)shadersIds;
               $i$f$map = 0;

               for(Object element$iv : $this$map$iv) {
                  $i$f$mapTo = ((Number)element$iv).intValue();
                  int var51 = 0;
                  GLCompatible.attachShader(programId, $i$f$mapTo);
               }

               GLCompatible.linkProgram(programId);
               if (GLCompatible.getProgrami(programId, GLCompatible.GL_LINK_STATUS) != 1) {
                  String msg = "\n                    |Could not link program for shader: " + shader.getLocation() + "\n                    |" + GLCompatible.getProgramInfoLog(programId, Integer.MAX_VALUE) + "\n                ";
                  throw new IllegalStateException(StringsKt.trimMargin$default(msg, (String)null, 1, (Object)null).toString());
               } else {
                  $this$map$iv = (Iterable)shader.getUniforms().values();
                  $i$f$map = 0;

                  for(Object element$iv : $this$map$iv) {
                     Uniform it = (Uniform)element$iv;
                     int var52 = 0;
                     it.initialize();
                  }

                  GLCompatible.validateProgram(programId);
                  if (GLCompatible.getProgrami(programId, GLCompatible.GL_VALIDATE_STATUS) != 1) {
                     String log = GLCompatible.getProgramInfoLog(programId, Integer.MAX_VALUE);
                     if (!StringsKt.equals(log, "Validation Failed: No vertex array object bound.", true)) {
                        String msg = "\n                    |Could not validate program for shader: " + shader.getLocation() + "\n                    |" + log + "\n                ";
                        throw new IllegalStateException(StringsKt.trimMargin$default(msg, (String)null, 1, (Object)null).toString());
                     }
                  }

                  $this$map$iv = (Iterable)shadersIds;
                  $i$f$map = 0;
                  destination$iv$iv = (Collection)(new ArrayList());
                  $i$f$mapTo = 0;

                  for(Object element$iv$iv : $this$map$iv) {
                     int it = ((Number)element$iv$iv).intValue();
                     int var59 = 0;
                     if (it > 0) {
                        destination$iv$iv.add(element$iv$iv);
                     }
                  }

                  $this$map$iv = (Iterable)((List)destination$iv$iv);
                  $i$f$map = 0;

                  for(Object element$iv : $this$map$iv) {
                     $i$f$mapTo = ((Number)element$iv).intValue();
                     int var54 = 0;
                     GLCompatible.detachShader(programId, $i$f$mapTo);
                     GLCompatible.deleteShader($i$f$mapTo);
                  }

               }
            }
         }
      }
   }

   public final void bindShader(@NotNull Shader shader) {
      Intrinsics.checkNotNullParameter(shader, "shader");
      if (!this.isShaderLoaded(shader)) {
         this.loadShader(shader);
      }

      GLCompatible.useProgram(shader.getProgramId());
      shader.onBind();
   }

   public final void unbindShader(@NotNull Shader shader) {
      Intrinsics.checkNotNullParameter(shader, "shader");
      shader.onUnbind();
      GLCompatible.useProgram(0);
   }

   public final boolean isShaderLoaded(@NotNull Shader shader) {
      Intrinsics.checkNotNullParameter(shader, "shader");
      return shaders.containsKey(shader.getLocation()) && shader.getLoaded();
   }

   private final String shaderTypeString(int type) {
      String var10000;
      if (type == GLCompatible.GL_VERTEX_SHADER) {
         var10000 = "vertex";
      } else {
         if (type != GLCompatible.GL_FRAGMENT_SHADER) {
            throw new IllegalStateException(("Unsupported shader type: " + type).toString());
         }

         var10000 = "fragment";
      }

      return var10000;
   }

   private final int createShaderType(Shader shader, int type, ResourceLocation location) {
      int shaderId = GLCompatible.createShader(type);
      int var6 = 0;
      String shaderTitle = INSTANCE.shaderTypeString(type);
      if (shaderId <= 0) {
         int var19 = 0;
         String var20 = "Could not create " + shaderTitle + " shader: " + shader.getLocation() + ". Maybe, shaders not supported :(";
         throw new IllegalStateException(var20.toString());
      } else {
         InputStream var8 = ResourceExtensionsKt.inputStream(location);
         Charset var9 = Charsets.UTF_8;
         Reader var10 = (Reader)(new InputStreamReader(var8, var9));
         int var11 = 8192;
         Closeable msg = (Closeable)(var10 instanceof BufferedReader ? (BufferedReader)var10 : new BufferedReader(var10, var11));
         Throwable var21 = null;

         try {
            BufferedReader it = (BufferedReader)msg;
            var11 = 0;
            var23 = TextStreamsKt.readText((Reader)it);
         } catch (Throwable var15) {
            var21 = var15;
            throw var15;
         } finally {
            CloseableKt.closeFinally(msg, var21);
         }

         GLCompatible.shaderSource(shaderId, var23);
         GLCompatible.compileShader(shaderId);
         if (GLCompatible.getShaderi(shaderId, GLCompatible.GL_COMPILE_STATUS) != 1) {
            String msg = "\n                    |Could not compile " + shaderTitle + " shader '" + location + "'\n                    |" + GLCompatible.getShaderInfoLog(shaderId, Integer.MAX_VALUE) + "\n                ";
            throw new IllegalStateException(StringsKt.trimMargin$default(msg, (String)null, 1, (Object)null).toString());
         } else {
            return shaderId;
         }
      }
   }

   public void func_110549_a(@NotNull IResourceManager resourceManager) {
      Intrinsics.checkNotNullParameter(resourceManager, "resourceManager");
      if (!LoliGraphics.INSTANCE.getLoadingScreenActive()) {
         HashMap reloaded = new HashMap(shaders);
         shaders.clear();
         ProgressManager.ProgressBar bar = ProgressManager.push("Reloading Shader Manager", reloaded.size(), true);
         Map $this$forEach$iv = (Map)reloaded;
         int $i$f$forEach = 0;

         for(Map.Entry element$iv : $this$forEach$iv.entrySet()) {
            int var9 = 0;
            ResourceLocation location = (ResourceLocation)element$iv.getKey();
            Shader shader = (Shader)element$iv.getValue();
            bar.step(location.toString());
            ShaderManager var10000 = INSTANCE;
            Intrinsics.checkNotNull(shader);
            var10000.loadShader(shader);
         }

         ProgressManager.pop(bar);
      }
   }

   public final <S extends Shader> void useShader(@NotNull S shader, @NotNull Function1<? super S, Unit> block) {
      Intrinsics.checkNotNullParameter(shader, "shader");
      Intrinsics.checkNotNullParameter(block, "block");
      int $i$f$useShader = 0;
      this.bindShader(shader);
      block.invoke(shader);
      this.unbindShader(shader);
   }

   private static final Object loadShader$lambda$0(Shader $shader) {
      Intrinsics.checkNotNullParameter($shader, "$shader");
      return $shader.getClass().getName();
   }
}

package loliland.graphics.renderer.glut;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class GLUTFramebufferAttachment {
   protected int internalFormat;
   protected int format;
   protected int type;
   protected boolean isFloat;
   protected boolean isGPUOnly;
   protected boolean isDepth;
   protected boolean isStencil;
   protected final boolean isRenderBufferAttachment;

   protected GLUTFramebufferAttachment(int internalFormat, int format, int type) {
      this.internalFormat = internalFormat;
      this.format = format;
      this.type = type;
      this.isRenderBufferAttachment = false;
   }

   protected GLUTFramebufferAttachment(int internalFormat) {
      this.internalFormat = internalFormat;
      this.isRenderBufferAttachment = true;
   }

   public void resize(int width, int height) {
   }

   public boolean isRenderBufferAttachment() {
      return this.isRenderBufferAttachment;
   }

   public boolean isColorTexture() {
      return !this.isDepth && !this.isStencil;
   }
}

#version 330

in vec2 vertex;
in vec2 textureCoords;
in vec4 vertexColor;

out vec2 pass_textureCoords;
out vec4 pass_vertexColor;

uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;

uniform ivec2 displayResolution;
uniform vec3 position;

void main(){
    gl_Position = projectionMatrix * modelViewMatrix * vec4(vec3(vertex, 0.0) + position, 1.0);
    pass_textureCoords = textureCoords;
    pass_vertexColor = vertexColor;
}
package loliland.graphics.renderer.shader.uniform;

import java.nio.FloatBuffer;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import loliland.graphics.renderer.GLCompatible;
import loliland.graphics.renderer.shader.Shader;
import org.jetbrains.annotations.NotNull;
import org.joml.Vector4f;
import org.lwjglx.BufferUtils;

@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\u0019\u0010\u0007\u001a\u00020\b2\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\n¢\u0006\u0002\u0010\f¨\u0006\r"},
   d2 = {"Lloliland/graphics/renderer/shader/uniform/UniformVector4fArray;", "Lloliland/graphics/renderer/shader/uniform/Uniform;", "shader", "Lloliland/graphics/renderer/shader/Shader;", "name", "", "(Lloliland/graphics/renderer/shader/Shader;Ljava/lang/String;)V", "set", "", "value", "", "Lorg/joml/Vector4f;", "([Lorg/joml/Vector4f;)V", "loligraphics-1.7.10"}
)
public final class UniformVector4fArray extends Uniform {
   public UniformVector4fArray(@NotNull Shader shader, @NotNull String name) {
      Intrinsics.checkNotNullParameter(shader, "shader");
      Intrinsics.checkNotNullParameter(name, "name");
      super(shader, name);
   }

   public final void set(@NotNull Vector4f[] value) {
      Intrinsics.checkNotNullParameter(value, "value");
      FloatBuffer buffer = BufferUtils.createFloatBuffer(value.length * 4);
      int var3 = 0;

      for(int var4 = value.length; var3 < var4; ++var3) {
         Vector4f v = value[var3];
         buffer.put(v.x).put(v.y).put(v.z).put(v.w);
      }

      buffer.flip();
      GLCompatible.uniform4fArray(this.getLocation(), buffer);
      this.setFirstUpload(false);
   }
}

package loliland.graphics.util;

import com.gamerforea.client.util.TessellatorDebuggerUtils;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.internal.ProgressionUtilKt;
import kotlin.jvm.JvmName;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import loliland.graphics.renderer.font.FontText;
import loliland.graphics.renderer.texture.EmptyTexture;
import loliland.graphics.renderer.texture.Texture;
import loliland.graphics.renderer.texture.TextureManager;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.shader.Framebuffer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector4f;
import org.joml.Vector4fc;
import org.lwjglx.opengl.GL11;

@Metadata(
   mv = {1, 9, 0},
   k = 2,
   xi = 48,
   d1 = {"\u0000j\n\u0000\n\u0002\u0010\b\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0006\n\u0002\b\r\n\u0002\u0010\u0013\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0007\n\u0002\b\u0011\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\u001aL\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u0011\u001a\u00020\u000f2\u0006\u0010\u0012\u001a\u00020\u000f2\u0006\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0013\u001a\u00020\u000f2\b\b\u0002\u0010\u0014\u001a\u00020\u00012\b\b\u0002\u0010\u0015\u001a\u00020\u000fH\u0007\u001a<\u0010\u0016\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0011\u001a\u00020\u000f2\u0006\u0010\u0017\u001a\u00020\u000f2\u0006\u0010\u0000\u001a\u00020\u00012\b\b\u0002\u0010\u0018\u001a\u00020\u000f2\b\b\u0002\u0010\u0015\u001a\u00020\u000fH\u0007\u001aD\u0010\u0019\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0011\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u0012\u001a\u00020\u000f2\u0006\u0010\u0000\u001a\u00020\u00012\b\b\u0002\u0010\u0018\u001a\u00020\u000f2\b\b\u0002\u0010\u0015\u001a\u00020\u000fH\u0007\u001a,\u0010\u001a\u001a\u00020\r2\u0006\u0010\u001b\u001a\u00020\u00012\u0006\u0010\u001c\u001a\u00020\u001d2\b\b\u0002\u0010\u0014\u001a\u00020\u00012\b\b\u0002\u0010\u0015\u001a\u00020\u000fH\u0007\u001aq\u0010\u001e\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u0011\u001a\u00020\u000f2\u0006\u0010\u0012\u001a\u00020\u000f2\n\b\u0002\u0010\u001f\u001a\u0004\u0018\u00010\u00012\n\b\u0002\u0010 \u001a\u0004\u0018\u00010\u00012\n\b\u0002\u0010!\u001a\u0004\u0018\u00010\u00012\n\b\u0002\u0010\"\u001a\u0004\u0018\u00010\u00012\b\b\u0002\u0010\u0015\u001a\u00020\u000f2\b\b\u0002\u0010#\u001a\u00020$H\u0007¢\u0006\u0002\u0010%\u001aD\u0010&\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u0011\u001a\u00020\u000f2\u0006\u0010\u0012\u001a\u00020\u000f2\u0006\u0010\u0000\u001a\u00020\u00012\b\b\u0002\u0010'\u001a\u00020\u000f2\b\b\u0002\u0010\u0015\u001a\u00020\u000fH\u0007\u001aD\u0010(\u001a\u00020\r2\u0006\u0010)\u001a\u00020\u00012\u0006\u0010*\u001a\u00020\u00012\u0006\u0010+\u001a\u00020\u00012\u0006\u0010,\u001a\u00020\u00072\b\u0010-\u001a\u0004\u0018\u00010\u00072\u0006\u0010.\u001a\u00020\u00072\b\b\u0002\u0010\u0015\u001a\u00020\u0001H\u0007\u001aB\u0010/\u001a\u00020\r2\u0006\u0010)\u001a\u00020\u00012\u0006\u0010*\u001a\u00020\u00012\u0006\u00100\u001a\u00020\u00012\u0006\u00101\u001a\u00020\u00072\u0006\u0010-\u001a\u00020\u00072\u0006\u00102\u001a\u00020\u00072\b\b\u0002\u0010\u0015\u001a\u00020\u0001H\u0007\u001a0\u00103\u001a\u00020\r2\u0006\u00104\u001a\u0002052\u0006\u00106\u001a\u0002072\u0012\u00108\u001a\u000e\u0012\u0004\u0012\u000205\u0012\u0004\u0012\u00020\r09H\u0086\bø\u0001\u0000\u001a4\u0010:\u001a\u00020\r2\u0006\u0010;\u001a\u00020\u00072\u0006\u0010)\u001a\u00020\u00012\u0006\u0010*\u001a\u00020\u00012\b\b\u0002\u0010\u0015\u001a\u00020\u00012\b\b\u0002\u0010#\u001a\u00020$H\u0007\u001a2\u0010<\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u0011\u001a\u00020\u000f2\u0006\u0010\u0012\u001a\u00020\u000f2\b\b\u0002\u0010\u0015\u001a\u00020\u0001H\u0007\u001a2\u0010<\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u00012\u0006\u0010\u0010\u001a\u00020\u00012\u0006\u0010\u0011\u001a\u00020\u00012\u0006\u0010\u0012\u001a\u00020\u00012\b\b\u0002\u0010\u0015\u001a\u00020\u0001H\u0007\u001a\\\u0010=\u001a\u00020\r2\u0006\u0010)\u001a\u00020>2\u0006\u0010*\u001a\u00020>2\u0006\u0010?\u001a\u00020>2\u0006\u0010@\u001a\u00020>2\u0006\u0010+\u001a\u00020>2\u0006\u00100\u001a\u00020>2\u0006\u0010A\u001a\u00020>2\u0006\u0010B\u001a\u00020>2\b\b\u0002\u0010\u0015\u001a\u00020\u00012\b\b\u0002\u0010#\u001a\u00020$H\u0007\u001ab\u0010=\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u00012\u0006\u0010\u0011\u001a\u00020\u00012\u0006\u0010\u0010\u001a\u00020\u00012\u0006\u0010\u0012\u001a\u00020\u00012\u0006\u0010C\u001a\u00020\u00012\u0006\u0010D\u001a\u00020\u00012\u0006\u0010E\u001a\u00020\u00012\u0006\u0010F\u001a\u00020\u00012\u0006\u0010A\u001a\u00020\u00012\u0006\u0010B\u001a\u00020\u00012\b\b\u0002\u0010\u0015\u001a\u00020\u0001H\u0007\u001a\\\u0010=\u001a\u00020\r2\u0006\u0010)\u001a\u00020\u00012\u0006\u0010*\u001a\u00020\u00012\u0006\u0010?\u001a\u00020\u00012\u0006\u0010@\u001a\u00020\u00012\u0006\u0010+\u001a\u00020\u00012\u0006\u00100\u001a\u00020\u00012\u0006\u0010A\u001a\u00020\u00012\u0006\u0010B\u001a\u00020\u00012\b\b\u0002\u0010\u0015\u001a\u00020\u00012\b\b\u0002\u0010#\u001a\u00020$H\u0007\u001a<\u0010G\u001a\u00020\r2\u0006\u0010H\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u0012\u001a\u00020\u000f2\u0006\u0010\u0000\u001a\u00020\u00012\b\b\u0002\u0010\u0018\u001a\u00020\u000f2\b\b\u0002\u0010\u0015\u001a\u00020\u000fH\u0007\u001aD\u0010I\u001a\u00020\r2\u0006\u0010J\u001a\u00020>2\u0006\u0010K\u001a\u00020>2\u0006\u0010L\u001a\u00020>2\u0006\u0010M\u001a\u00020>2\b\b\u0002\u0010N\u001a\u00020\u00062\f\u0010O\u001a\b\u0012\u0004\u0012\u00020\r0PH\u0086\bø\u0001\u0000\u001a,\u0010I\u001a\u00020\r2\u0006\u0010\u001b\u001a\u00020\u00012\b\b\u0002\u0010N\u001a\u00020\u00062\f\u0010O\u001a\b\u0012\u0004\u0012\u00020\r0PH\u0086\bø\u0001\u0000\u001a,\u0010I\u001a\u00020\r2\u0006\u0010\u001b\u001a\u00020\u00022\b\b\u0002\u0010N\u001a\u00020\u00062\f\u0010O\u001a\b\u0012\u0004\u0012\u00020\r0PH\u0086\bø\u0001\u0000\u001a\u001a\u0010Q\u001a\u00020\r2\f\u0010O\u001a\b\u0012\u0004\u0012\u00020\r0PH\u0086\bø\u0001\u0000\u001a\u001a\u0010R\u001a\u00020\r*\u00020S2\u0006\u0010+\u001a\u00020\u000f2\u0006\u00100\u001a\u00020\u000f\u001a\u0015\u0010T\u001a\u00020\u000f*\u00020\u000f2\u0006\u0010U\u001a\u00020VH\u0086\f\u001a\u0015\u0010T\u001a\u00020>*\u00020>2\u0006\u0010U\u001a\u00020VH\u0086\f\u001a\u0015\u0010T\u001a\u00020\u0001*\u00020\u00012\u0006\u0010U\u001a\u00020VH\u0086\f\"\u0016\u0010\u0000\u001a\u00020\u0001*\u00020\u00028Æ\u0002¢\u0006\u0006\u001a\u0004\b\u0003\u0010\u0004\"\u0016\u0010\u0005\u001a\u00020\u0006*\u00020\u00078Æ\u0002¢\u0006\u0006\u001a\u0004\b\b\u0010\t\"\u0016\u0010\n\u001a\u00020\u0001*\u00020\u00028Æ\u0002¢\u0006\u0006\u001a\u0004\b\u000b\u0010\u0004\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006W"},
   d2 = {"argb", "", "Lorg/joml/Vector4f;", "getArgb", "(Lorg/joml/Vector4f;)I", "empty", "", "Lloliland/graphics/renderer/texture/Texture;", "getEmpty", "(Lloliland/graphics/renderer/texture/Texture;)Z", "rgba", "getRgba", "drawCorneredRectangle", "", "x1", "", "y1", "x2", "y2", "corner", "drawType", "zLevel", "drawHorizontalLine", "y", "lineWidth", "drawLine", "drawPolygon", "color", "data", "", "drawRectangle", "argbLeftBottom", "argbRightBottom", "argbRightTop", "argbLeftTop", "tessellator", "Lnet/minecraft/client/renderer/Tessellator;", "(DDDDLjava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;DLnet/minecraft/client/renderer/Tessellator;)V", "drawRectangleOutline", "borderWidth", "drawSizeableTextureHorizontal", "posX", "posY", "width", "leftTexture", "centerTexture", "rightTexture", "drawSizeableTextureVertical", "height", "topTexture", "bottomTexture", "drawTextWithShadow", "text", "Lloliland/graphics/renderer/font/FontText;", "shadow", "Lloliland/graphics/util/TextShadow;", "drawCall", "Lkotlin/Function1;", "drawTexturedFullRect", "texture", "drawTexturedQuadFit", "drawTexturedRect", "", "u", "v", "textureWidth", "textureHeight", "u1", "u2", "v1", "v2", "drawVerticalLine", "x", "withColor", "r", "g", "b", "a", "where", "block", "Lkotlin/Function0;", "withMatrixStack", "drawTexture", "Lnet/minecraft/client/shader/Framebuffer;", "scaled", "display", "Lnet/minecraft/client/gui/ScaledResolution;", "loligraphics-1.7.10"}
)
@JvmName(
   name = "GuiUtils"
)
@SourceDebugExtension({"SMAP\nGuiExtensions.kt\nKotlin\n*S Kotlin\n*F\n+ 1 GuiExtensions.kt\nloliland/graphics/util/GuiUtils\n+ 2 TextureManager.kt\nloliland/graphics/renderer/texture/TextureManager\n+ 3 ColorUtils.kt\nloliland/graphics/util/ColorUtils\n+ 4 FontText.kt\nloliland/graphics/renderer/font/FontText\n*L\n1#1,470:1\n444#1,9:574\n444#1,9:606\n143#2,12:471\n143#2,12:483\n143#2,12:495\n143#2,12:507\n143#2,12:519\n143#2,12:531\n6#3,10:543\n6#3,10:553\n6#3,10:563\n6#3:583\n18#3:584\n9#3,10:585\n12#3,7:595\n15#3,4:602\n6#3:615\n18#3:616\n9#3,10:617\n12#3,7:627\n15#3,4:634\n25#3:638\n19#3,4:639\n31#3:643\n19#3,10:644\n6#3,10:654\n100#4:573\n*S KotlinDebug\n*F\n+ 1 GuiExtensions.kt\nloliland/graphics/util/GuiUtils\n*L\n455#1:574,9\n458#1:606,9\n191#1:471,12\n198#1:483,12\n204#1:495,12\n220#1:507,12\n224#1:519,12\n229#1:531,12\n285#1:543,10\n315#1:553,10\n366#1:563,10\n459#1:583\n459#1:584\n460#1:585,10\n461#1:595,7\n462#1:602,4\n459#1:615\n459#1:616\n460#1:617,10\n461#1:627,7\n462#1:634,4\n467#1:638\n467#1:639,4\n468#1:643\n468#1:644,10\n256#1:654,10\n390#1:573\n*E\n"})
public final class GuiUtils {
   public static final int scaled(int $this$scaled, @NotNull ScaledResolution display) {
      Intrinsics.checkNotNullParameter(display, "display");
      int $i$f$scaled = 0;
      return $this$scaled / display.func_78325_e();
   }

   public static final float scaled(float $this$scaled, @NotNull ScaledResolution display) {
      Intrinsics.checkNotNullParameter(display, "display");
      int $i$f$scaled = 0;
      return $this$scaled / (float)display.func_78325_e();
   }

   public static final double scaled(double $this$scaled, @NotNull ScaledResolution display) {
      Intrinsics.checkNotNullParameter(display, "display");
      int $i$f$scaled = 0;
      return $this$scaled / (double)display.func_78325_e();
   }

   @JvmOverloads
   public static final void drawTexturedQuadFit(double x1, double y1, double x2, double y2, int zLevel) {
      Tessellator $this$drawTexturedQuadFit_u24lambda_u240 = Tessellator.field_78398_a;
      int var10 = 0;
      $this$drawTexturedQuadFit_u24lambda_u240.func_78382_b();
      TessellatorDebuggerUtils.onCall("loliland/graphics/util/GuiUtils/drawTexturedQuadFit(DDDDI)V");
      $this$drawTexturedQuadFit_u24lambda_u240.func_78374_a(x1, y2, (double)zLevel, (double)0.0F, (double)1.0F);
      $this$drawTexturedQuadFit_u24lambda_u240.func_78374_a(x2, y2, (double)zLevel, (double)1.0F, (double)1.0F);
      $this$drawTexturedQuadFit_u24lambda_u240.func_78374_a(x2, y1, (double)zLevel, (double)1.0F, (double)0.0F);
      $this$drawTexturedQuadFit_u24lambda_u240.func_78374_a(x1, y1, (double)zLevel, (double)0.0F, (double)0.0F);
      $this$drawTexturedQuadFit_u24lambda_u240.func_78381_a();
   }

   // $FF: synthetic method
   public static void drawTexturedQuadFit$default(double var0, double var2, double var4, double var6, int var8, int var9, Object var10) {
      if ((var9 & 16) != 0) {
         var8 = 0;
      }

      drawTexturedQuadFit(var0, var2, var4, var6, var8);
   }

   @JvmOverloads
   public static final void drawTexturedQuadFit(int x1, int y1, int x2, int y2, int zLevel) {
      drawTexturedQuadFit((double)x1, (double)y1, (double)x2, (double)y2, zLevel);
   }

   // $FF: synthetic method
   public static void drawTexturedQuadFit$default(int var0, int var1, int var2, int var3, int var4, int var5, Object var6) {
      if ((var5 & 16) != 0) {
         var4 = 0;
      }

      drawTexturedQuadFit(var0, var1, var2, var3, var4);
   }

   @JvmOverloads
   public static final void drawTexturedRect(int x1, int x2, int y1, int y2, int u1, int u2, int v1, int v2, int textureWidth, int textureHeight, int zLevel) {
      Tessellator $this$drawTexturedRect_u24lambda_u241 = Tessellator.field_78398_a;
      int var12 = 0;
      $this$drawTexturedRect_u24lambda_u241.func_78382_b();
      TessellatorDebuggerUtils.onCall("loliland/graphics/util/GuiUtils/drawTexturedRect(IIIIIIIIIII)V");
      $this$drawTexturedRect_u24lambda_u241.func_78374_a((double)x1, (double)y2, (double)zLevel, (double)u1 / (double)textureWidth, (double)v2 / (double)textureHeight);
      $this$drawTexturedRect_u24lambda_u241.func_78374_a((double)x2, (double)y2, (double)zLevel, (double)u2 / (double)textureWidth, (double)v2 / (double)textureHeight);
      $this$drawTexturedRect_u24lambda_u241.func_78374_a((double)x2, (double)y1, (double)zLevel, (double)u2 / (double)textureWidth, (double)v1 / (double)textureHeight);
      $this$drawTexturedRect_u24lambda_u241.func_78374_a((double)x1, (double)y1, (double)zLevel, (double)u1 / (double)textureWidth, (double)v1 / (double)textureHeight);
      $this$drawTexturedRect_u24lambda_u241.func_78381_a();
   }

   // $FF: synthetic method
   public static void drawTexturedRect$default(int var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, int var11, Object var12) {
      if ((var11 & 1024) != 0) {
         var10 = 0;
      }

      drawTexturedRect(var0, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10);
   }

   @JvmOverloads
   public static final void drawTexturedRect(int posX, int posY, int u, int v, int width, int height, int textureWidth, int textureHeight, int zLevel, @NotNull Tessellator tessellator) {
      Intrinsics.checkNotNullParameter(tessellator, "tessellator");
      drawTexturedRect((float)posX, (float)posY, (float)u, (float)v, (float)width, (float)height, (float)textureWidth, (float)textureHeight, zLevel, tessellator);
   }

   // $FF: synthetic method
   public static void drawTexturedRect$default(int var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, Tessellator var9, int var10, Object var11) {
      if ((var10 & 256) != 0) {
         var8 = 0;
      }

      if ((var10 & 512) != 0) {
         Tessellator var10000 = Tessellator.field_78398_a;
         Intrinsics.checkNotNullExpressionValue(var10000, "instance");
         var9 = var10000;
      }

      drawTexturedRect(var0, var1, var2, var3, var4, var5, var6, var7, var8, var9);
   }

   @JvmOverloads
   public static final void drawTexturedRect(float posX, float posY, float u, float v, float width, float height, float textureWidth, float textureHeight, int zLevel, @NotNull Tessellator tessellator) {
      Intrinsics.checkNotNullParameter(tessellator, "tessellator");
      int var11 = 0;
      tessellator.func_78382_b();
      TessellatorDebuggerUtils.onCall("loliland/graphics/util/GuiUtils/drawTexturedRect(FFFFFFFFILnet/minecraft/client/renderer/Tessellator;)V");
      tessellator.func_78374_a((double)posX, (double)(posY + height), (double)zLevel, (double)u / (double)textureWidth, (double)(v + height) / (double)textureHeight);
      tessellator.func_78374_a((double)(posX + width), (double)(posY + height), (double)zLevel, (double)(u + width) / (double)textureWidth, (double)(v + height) / (double)textureHeight);
      tessellator.func_78374_a((double)(posX + width), (double)posY, (double)zLevel, (double)(u + width) / (double)textureWidth, (double)v / (double)textureHeight);
      tessellator.func_78374_a((double)posX, (double)posY, (double)zLevel, (double)u / (double)textureWidth, (double)v / (double)textureHeight);
      tessellator.func_78381_a();
   }

   // $FF: synthetic method
   public static void drawTexturedRect$default(float var0, float var1, float var2, float var3, float var4, float var5, float var6, float var7, int var8, Tessellator var9, int var10, Object var11) {
      if ((var10 & 256) != 0) {
         var8 = 0;
      }

      if ((var10 & 512) != 0) {
         Tessellator var10000 = Tessellator.field_78398_a;
         Intrinsics.checkNotNullExpressionValue(var10000, "instance");
         var9 = var10000;
      }

      drawTexturedRect(var0, var1, var2, var3, var4, var5, var6, var7, var8, var9);
   }

   @JvmOverloads
   public static final void drawTexturedFullRect(@NotNull Texture texture, int posX, int posY, int zLevel, @NotNull Tessellator tessellator) {
      Intrinsics.checkNotNullParameter(texture, "texture");
      Intrinsics.checkNotNullParameter(tessellator, "tessellator");
      drawTexturedRect(posX, posY, 0, 0, texture.getWidth(), texture.getHeight(), texture.getWidth(), texture.getHeight(), zLevel, tessellator);
   }

   // $FF: synthetic method
   public static void drawTexturedFullRect$default(Texture var0, int var1, int var2, int var3, Tessellator var4, int var5, Object var6) {
      if ((var5 & 8) != 0) {
         var3 = 0;
      }

      if ((var5 & 16) != 0) {
         Tessellator var10000 = Tessellator.field_78398_a;
         Intrinsics.checkNotNullExpressionValue(var10000, "instance");
         var4 = var10000;
      }

      drawTexturedFullRect(var0, var1, var2, var3, var4);
   }

   @JvmOverloads
   public static final void drawSizeableTextureHorizontal(int posX, int posY, int width, @NotNull Texture leftTexture, @Nullable Texture centerTexture, @NotNull Texture rightTexture, int zLevel) {
      Intrinsics.checkNotNullParameter(leftTexture, "leftTexture");
      Intrinsics.checkNotNullParameter(rightTexture, "rightTexture");
      int currentX = 0;
      TextureManager $this$iv = TextureManager.INSTANCE;
      boolean unbind$iv = false;
      int $i$f$useTexture = 0;
      $this$iv.bindTexture(leftTexture);
      int var12 = 0;
      drawTexturedFullRect$default(leftTexture, posX, posY, zLevel, (Tessellator)null, 16, (Object)null);
      currentX = posX + leftTexture.getWidth();
      int centerWidth = width - leftTexture.getWidth() - rightTexture.getWidth();
      if (centerTexture != null) {
         TextureManager $this$iv = TextureManager.INSTANCE;
         $i$f$useTexture = 0;
         int $i$f$useTexture = 0;
         $this$iv.bindTexture(centerTexture);
         int var13 = 0;
         drawTexturedQuadFit(currentX, posY, currentX + centerWidth, posY + centerTexture.getHeight(), zLevel);
      }

      currentX += centerWidth;
      TextureManager $this$iv = TextureManager.INSTANCE;
      $i$f$useTexture = 0;
      int $i$f$useTexture = 0;
      $this$iv.bindTexture(rightTexture);
      int var22 = 0;
      drawTexturedFullRect$default(rightTexture, currentX, posY, zLevel, (Tessellator)null, 16, (Object)null);
   }

   // $FF: synthetic method
   public static void drawSizeableTextureHorizontal$default(int var0, int var1, int var2, Texture var3, Texture var4, Texture var5, int var6, int var7, Object var8) {
      if ((var7 & 64) != 0) {
         var6 = 0;
      }

      drawSizeableTextureHorizontal(var0, var1, var2, var3, var4, var5, var6);
   }

   @JvmOverloads
   public static final void drawSizeableTextureVertical(int posX, int posY, int height, @NotNull Texture topTexture, @NotNull Texture centerTexture, @NotNull Texture bottomTexture, int zLevel) {
      Intrinsics.checkNotNullParameter(topTexture, "topTexture");
      Intrinsics.checkNotNullParameter(centerTexture, "centerTexture");
      Intrinsics.checkNotNullParameter(bottomTexture, "bottomTexture");
      int currentY = 0;
      TextureManager $this$iv = TextureManager.INSTANCE;
      boolean unbind$iv = false;
      int $i$f$useTexture = 0;
      $this$iv.bindTexture(topTexture);
      int var12 = 0;
      drawTexturedFullRect$default(topTexture, posX, posY, zLevel, (Tessellator)null, 16, (Object)null);
      currentY = posY + topTexture.getHeight();
      $this$iv = TextureManager.INSTANCE;
      unbind$iv = false;
      $i$f$useTexture = 0;
      $this$iv.bindTexture(centerTexture);
      var12 = 0;
      int centerHeight = height - topTexture.getHeight() - bottomTexture.getHeight();
      drawTexturedQuadFit(posX, currentY, posX + centerTexture.getWidth(), currentY + centerHeight, zLevel);
      currentY += centerHeight;
      $this$iv = TextureManager.INSTANCE;
      unbind$iv = false;
      $i$f$useTexture = 0;
      $this$iv.bindTexture(bottomTexture);
      var12 = 0;
      drawTexturedFullRect$default(bottomTexture, posX, currentY, zLevel, (Tessellator)null, 16, (Object)null);
   }

   // $FF: synthetic method
   public static void drawSizeableTextureVertical$default(int var0, int var1, int var2, Texture var3, Texture var4, Texture var5, int var6, int var7, Object var8) {
      if ((var7 & 64) != 0) {
         var6 = 0;
      }

      drawSizeableTextureVertical(var0, var1, var2, var3, var4, var5, var6);
   }

   @JvmOverloads
   public static final void drawRectangle(double x1, double y1, double x2, double y2, @Nullable Integer argbLeftBottom, @Nullable Integer argbRightBottom, @Nullable Integer argbRightTop, @Nullable Integer argbLeftTop, double zLevel, @NotNull Tessellator tessellator) {
      Intrinsics.checkNotNullParameter(tessellator, "tessellator");
      int var16 = 0;
      double minX = Math.min(x1, x2);
      double minY = Math.min(y1, y2);
      double maxX = Math.max(x1, x2);
      double maxY = Math.max(y1, y2);
      GL11.glDisable(3553);
      GL11.glShadeModel(7425);
      tessellator.func_78382_b();
      TessellatorDebuggerUtils.onCall("loliland/graphics/util/GuiUtils/drawRectangle(DDDDLjava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;DLnet/minecraft/client/renderer/Tessellator;)V");
      drawRectangle$lambda$10$setColor(tessellator, argbLeftBottom);
      tessellator.func_78377_a(minX, maxY, zLevel);
      drawRectangle$lambda$10$setColor(tessellator, argbRightBottom);
      tessellator.func_78377_a(maxX, maxY, zLevel);
      drawRectangle$lambda$10$setColor(tessellator, argbRightTop);
      tessellator.func_78377_a(maxX, minY, zLevel);
      drawRectangle$lambda$10$setColor(tessellator, argbLeftTop);
      tessellator.func_78377_a(minX, minY, zLevel);
      tessellator.func_78381_a();
      GL11.glShadeModel(7424);
      GL11.glEnable(3553);
   }

   // $FF: synthetic method
   public static void drawRectangle$default(double var0, double var2, double var4, double var6, Integer var8, Integer var9, Integer var10, Integer var11, double var12, Tessellator var14, int var15, Object var16) {
      if ((var15 & 16) != 0) {
         var8 = null;
      }

      if ((var15 & 32) != 0) {
         var9 = null;
      }

      if ((var15 & 64) != 0) {
         var10 = null;
      }

      if ((var15 & 128) != 0) {
         var11 = null;
      }

      if ((var15 & 256) != 0) {
         var12 = (double)0.0F;
      }

      if ((var15 & 512) != 0) {
         Tessellator var10000 = Tessellator.field_78398_a;
         Intrinsics.checkNotNullExpressionValue(var10000, "instance");
         var14 = var10000;
      }

      drawRectangle(var0, var2, var4, var6, var8, var9, var10, var11, var12, var14);
   }

   @JvmOverloads
   public static final void drawPolygon(int color, @NotNull double[] data, int drawType, double zLevel) {
      Intrinsics.checkNotNullParameter(data, "data");
      Tessellator $this$drawPolygon_u24lambda_u2411 = Tessellator.field_78398_a;
      int var6 = 0;
      GL11.glDisable(3553);
      GL11.glShadeModel(7425);
      $this$drawPolygon_u24lambda_u2411.func_78371_b(drawType);
      TessellatorDebuggerUtils.onCall("loliland/graphics/util/GuiUtils/drawPolygon(I[DID)V");
      int $i$f$getArgbRed = 0;
      int var10001 = color >> 16 & 255;
      $i$f$getArgbRed = 0;
      int var10002 = color >> 8 & 255;
      $i$f$getArgbRed = 0;
      int var10003 = color >> 0 & 255;
      $i$f$getArgbRed = 0;
      $this$drawPolygon_u24lambda_u2411.func_78370_a(var10001, var10002, var10003, color >> 24 & 255);
      int $this$argbRed$iv = data.length + -1;
      $i$f$getArgbRed = 0;
      int var9 = ProgressionUtilKt.getProgressionLastElement(0, $this$argbRed$iv, 2);
      if ($i$f$getArgbRed <= var9) {
         while(true) {
            $this$drawPolygon_u24lambda_u2411.func_78377_a(data[$i$f$getArgbRed], data[$i$f$getArgbRed + 1], zLevel);
            if ($i$f$getArgbRed == var9) {
               break;
            }

            $i$f$getArgbRed += 2;
         }
      }

      $this$drawPolygon_u24lambda_u2411.func_78381_a();
      GL11.glShadeModel(7424);
      GL11.glEnable(3553);
   }

   // $FF: synthetic method
   public static void drawPolygon$default(int var0, double[] var1, int var2, double var3, int var5, Object var6) {
      if ((var5 & 4) != 0) {
         var2 = 9;
      }

      if ((var5 & 8) != 0) {
         var3 = (double)0.0F;
      }

      drawPolygon(var0, var1, var2, var3);
   }

   @JvmOverloads
   public static final void drawLine(double x1, double x2, double y1, double y2, int argb, double lineWidth, double zLevel) {
      Tessellator $this$drawLine_u24lambda_u2412 = Tessellator.field_78398_a;
      int var14 = 0;
      double minX = Math.min(x1, x2);
      double minY = Math.min(y1, y2);
      double maxX = Math.max(x1, x2);
      double maxY = Math.max(y1, y2);
      GL11.glDisable(3553);
      GL11.glDisable(2848);
      GL11.glLineWidth((float)lineWidth);
      $this$drawLine_u24lambda_u2412.func_78371_b(1);
      TessellatorDebuggerUtils.onCall("loliland/graphics/util/GuiUtils/drawLine(DDDDIDD)V");
      int $i$f$getArgbRed = 0;
      int var10001 = argb >> 16 & 255;
      $i$f$getArgbRed = 0;
      int var10002 = argb >> 8 & 255;
      $i$f$getArgbRed = 0;
      int var10003 = argb >> 0 & 255;
      $i$f$getArgbRed = 0;
      $this$drawLine_u24lambda_u2412.func_78370_a(var10001, var10002, var10003, argb >> 24 & 255);
      $this$drawLine_u24lambda_u2412.func_78377_a(minX, minY, zLevel);
      $this$drawLine_u24lambda_u2412.func_78377_a(maxX, maxY, zLevel);
      $this$drawLine_u24lambda_u2412.func_78381_a();
      GL11.glLineWidth(1.0F);
      GL11.glEnable(3553);
   }

   // $FF: synthetic method
   public static void drawLine$default(double var0, double var2, double var4, double var6, int var8, double var9, double var11, int var13, Object var14) {
      if ((var13 & 32) != 0) {
         var9 = (double)1.0F;
      }

      if ((var13 & 64) != 0) {
         var11 = (double)0.0F;
      }

      drawLine(var0, var2, var4, var6, var8, var9, var11);
   }

   @JvmOverloads
   public static final void drawVerticalLine(double x, double y1, double y2, int argb, double lineWidth, double zLevel) {
      drawLine(x, x, y1, y2, argb, lineWidth, zLevel);
   }

   // $FF: synthetic method
   public static void drawVerticalLine$default(double var0, double var2, double var4, int var6, double var7, double var9, int var11, Object var12) {
      if ((var11 & 16) != 0) {
         var7 = (double)1.0F;
      }

      if ((var11 & 32) != 0) {
         var9 = (double)0.0F;
      }

      drawVerticalLine(var0, var2, var4, var6, var7, var9);
   }

   @JvmOverloads
   public static final void drawHorizontalLine(double x1, double x2, double y, int argb, double lineWidth, double zLevel) {
      drawLine(x1, x2, y, y, argb, lineWidth, zLevel);
   }

   // $FF: synthetic method
   public static void drawHorizontalLine$default(double var0, double var2, double var4, int var6, double var7, double var9, int var11, Object var12) {
      if ((var11 & 16) != 0) {
         var7 = (double)1.0F;
      }

      if ((var11 & 32) != 0) {
         var9 = (double)0.0F;
      }

      drawHorizontalLine(var0, var2, var4, var6, var7, var9);
   }

   @JvmOverloads
   public static final void drawRectangleOutline(double x1, double y1, double x2, double y2, int argb, double borderWidth, double zLevel) {
      double halfBorder = borderWidth / (double)2.0F;
      double minX = Math.min(x1, x2) + halfBorder;
      double minY = Math.min(y1, y2) + halfBorder;
      double maxX = Math.max(x1, x2) - halfBorder;
      double maxY = Math.max(y1, y2) - halfBorder;
      GL11.glDisable(3553);
      GL11.glDisable(2848);
      GL11.glLineWidth((float)borderWidth);
      Tessellator $this$drawRectangleOutline_u24lambda_u2413 = Tessellator.field_78398_a;
      int var24 = 0;
      $this$drawRectangleOutline_u24lambda_u2413.func_78371_b(2);
      TessellatorDebuggerUtils.onCall("loliland/graphics/util/GuiUtils/drawRectangleOutline(DDDDIDD)V");
      int $i$f$getArgbRed = 0;
      int var10001 = argb >> 16 & 255;
      $i$f$getArgbRed = 0;
      int var10002 = argb >> 8 & 255;
      $i$f$getArgbRed = 0;
      int var10003 = argb >> 0 & 255;
      $i$f$getArgbRed = 0;
      $this$drawRectangleOutline_u24lambda_u2413.func_78370_a(var10001, var10002, var10003, argb >> 24 & 255);
      $this$drawRectangleOutline_u24lambda_u2413.func_78377_a(minX, maxY, zLevel);
      $this$drawRectangleOutline_u24lambda_u2413.func_78377_a(maxX, maxY, zLevel);
      $this$drawRectangleOutline_u24lambda_u2413.func_78377_a(maxX, minY, zLevel);
      $this$drawRectangleOutline_u24lambda_u2413.func_78377_a(minX, minY, zLevel);
      $this$drawRectangleOutline_u24lambda_u2413.func_78381_a();
      GL11.glLineWidth(1.0F);
      GL11.glEnable(3553);
   }

   // $FF: synthetic method
   public static void drawRectangleOutline$default(double var0, double var2, double var4, double var6, int var8, double var9, double var11, int var13, Object var14) {
      if ((var13 & 32) != 0) {
         var9 = (double)1.0F;
      }

      if ((var13 & 64) != 0) {
         var11 = (double)0.0F;
      }

      drawRectangleOutline(var0, var2, var4, var6, var8, var9, var11);
   }

   public static final void drawTextWithShadow(@NotNull FontText text, @NotNull TextShadow shadow, @NotNull Function1<? super FontText, Unit> drawCall) {
      Intrinsics.checkNotNullParameter(text, "text");
      Intrinsics.checkNotNullParameter(shadow, "shadow");
      Intrinsics.checkNotNullParameter(drawCall, "drawCall");
      int $i$f$drawTextWithShadow = 0;
      shadow.getOriginalColor().set((Vector4fc)text.getColor());
      text.getPosition().add(shadow.getOffset().x(), shadow.getOffset().y(), 0.0F);
      text.getColor().set(shadow.getColor());
      int $i$f$getColorAlpha = 0;
      text.setColorAlpha(text.getColor().w * shadow.getColor().w());
      text.setWidth(text.getWidth() + 0.15F);
      drawCall.invoke(text);
      text.getColor().set((Vector4fc)shadow.getOriginalColor());
      text.getPosition().sub(shadow.getOffset().x(), shadow.getOffset().y(), 0.0F);
      text.setWidth(text.getWidth() - 0.15F);
      drawCall.invoke(text);
   }

   @JvmOverloads
   public static final void drawCorneredRectangle(double x1, double y1, double x2, double y2, int argb, double corner, int drawType, double zLevel) {
      double[] data = new double[]{x1, y2 - corner, x1 + corner, y2, x2 - corner, y2, x2, y2 - corner, x2, y1 + corner, x2 - corner, y1, x1 + corner, y1, x1, y1 + corner};
      drawPolygon(argb, data, drawType, zLevel);
   }

   // $FF: synthetic method
   public static void drawCorneredRectangle$default(double var0, double var2, double var4, double var6, int var8, double var9, int var11, double var12, int var14, Object var15) {
      if ((var14 & 64) != 0) {
         var11 = 9;
      }

      if ((var14 & 128) != 0) {
         var12 = (double)0.0F;
      }

      drawCorneredRectangle(var0, var2, var4, var6, var8, var9, var11, var12);
   }

   public static final void drawTexture(@NotNull Framebuffer $this$drawTexture, double width, double height) {
      Intrinsics.checkNotNullParameter($this$drawTexture, "<this>");
      double maxX = (double)$this$drawTexture.field_147621_c / (double)$this$drawTexture.field_147622_a;
      double maxY = (double)$this$drawTexture.field_147618_d / (double)$this$drawTexture.field_147620_b;
      Tessellator $this$drawTexture_u24lambda_u2414 = Tessellator.field_78398_a;
      int var10 = 0;
      $this$drawTexture_u24lambda_u2414.func_78382_b();
      TessellatorDebuggerUtils.onCall("loliland/graphics/util/GuiUtils/drawTexture(Lnet/minecraft/client/shader/Framebuffer;DD)V");
      $this$drawTexture_u24lambda_u2414.func_78374_a((double)0.0F, height, (double)0.0F, (double)0.0F, (double)0.0F);
      $this$drawTexture_u24lambda_u2414.func_78374_a(width, height, (double)0.0F, maxX, (double)0.0F);
      $this$drawTexture_u24lambda_u2414.func_78374_a(width, (double)0.0F, (double)0.0F, maxX, maxY);
      $this$drawTexture_u24lambda_u2414.func_78374_a((double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F, maxY);
      $this$drawTexture_u24lambda_u2414.func_78381_a();
   }

   public static final void withMatrixStack(@NotNull Function0<Unit> block) {
      Intrinsics.checkNotNullParameter(block, "block");
      int $i$f$withMatrixStack = 0;
      GL11.glPushMatrix();
      block.invoke();
      GL11.glPopMatrix();
   }

   public static final void withColor(float r, float g, float b, float a, boolean where, @NotNull Function0<Unit> block) {
      Intrinsics.checkNotNullParameter(block, "block");
      int $i$f$withColor = 0;
      if (!where) {
         block.invoke();
      } else {
         GL11.glColor4f(r, g, b, a);
         block.invoke();
         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      }
   }

   // $FF: synthetic method
   public static void withColor$default(float r, float g, float b, float a, boolean where, Function0 block, int $i$f$withColor, Object var7) {
      if (($i$f$withColor & 16) != 0) {
         where = true;
      }

      Intrinsics.checkNotNullParameter(block, "block");
      $i$f$withColor = 0;
      if (!where) {
         block.invoke();
      } else {
         GL11.glColor4f(r, g, b, a);
         block.invoke();
         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      }
   }

   public static final void withColor(@NotNull Vector4f color, boolean where, @NotNull Function0<Unit> block) {
      Intrinsics.checkNotNullParameter(color, "color");
      Intrinsics.checkNotNullParameter(block, "block");
      int $i$f$withColor = 0;
      float r$iv = color.x;
      float g$iv = color.y;
      float b$iv = color.z;
      float a$iv = color.w;
      int $i$f$withColor = 0;
      if (!where) {
         block.invoke();
      } else {
         GL11.glColor4f(r$iv, g$iv, b$iv, a$iv);
         block.invoke();
         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      }

   }

   // $FF: synthetic method
   public static void withColor$default(Vector4f color, boolean where, Function0 block, int $i$f$withColor, Object r$iv) {
      if (($i$f$withColor & 2) != 0) {
         where = true;
      }

      Intrinsics.checkNotNullParameter(color, "color");
      Intrinsics.checkNotNullParameter(block, "block");
      $i$f$withColor = 0;
      float var10 = color.x;
      float g$iv = color.y;
      float b$iv = color.z;
      float a$iv = color.w;
      int $i$f$withColor = 0;
      if (!where) {
         block.invoke();
      } else {
         GL11.glColor4f(var10, g$iv, b$iv, a$iv);
         block.invoke();
         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      }

   }

   public static final void withColor(int color, boolean where, @NotNull Function0<Unit> block) {
      Intrinsics.checkNotNullParameter(block, "block");
      int $i$f$withColor = 0;
      int $i$f$getArgbRed = 0;
      int $this$argbRed$iv = color >> 16 & 255;
      $i$f$getArgbRed = 0;
      float $this$normalizeColor$iv = (float)$this$argbRed$iv / 255.0F;
      int $i$f$getArgbGreen = 0;
      $i$f$getArgbRed = color >> 8 & 255;
      $i$f$getArgbGreen = 0;
      float $this$normalizeColor$iv = (float)$i$f$getArgbRed / 255.0F;
      int $i$f$getArgbBlue = 0;
      $i$f$getArgbGreen = color >> 0 & 255;
      $i$f$getArgbBlue = 0;
      float $this$normalizeColor$iv = (float)$i$f$getArgbGreen / 255.0F;
      int $i$f$getArgbAlpha = 0;
      $i$f$getArgbBlue = color >> 24 & 255;
      $i$f$getArgbAlpha = 0;
      float $this$normalizeColor$iv = (float)$i$f$getArgbBlue / 255.0F;
      $i$f$getArgbAlpha = 0;
      if (!where) {
         block.invoke();
      } else {
         GL11.glColor4f($this$normalizeColor$iv, $this$normalizeColor$iv, $this$normalizeColor$iv, $this$normalizeColor$iv);
         block.invoke();
         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      }

   }

   // $FF: synthetic method
   public static void withColor$default(int color, boolean where, Function0 block, int $i$f$withColor, Object $this$argbRed$iv) {
      if (($i$f$withColor & 2) != 0) {
         where = true;
      }

      Intrinsics.checkNotNullParameter(block, "block");
      $i$f$withColor = 0;
      int $i$f$getArgbRed = 0;
      int var10 = color >> 16 & 255;
      $i$f$getArgbRed = 0;
      float var11 = (float)var10 / 255.0F;
      int $i$f$getArgbGreen = 0;
      $i$f$getArgbRed = color >> 8 & 255;
      $i$f$getArgbGreen = 0;
      float $this$normalizeColor$iv = (float)$i$f$getArgbRed / 255.0F;
      int $i$f$getArgbBlue = 0;
      $i$f$getArgbGreen = color >> 0 & 255;
      $i$f$getArgbBlue = 0;
      float $this$normalizeColor$iv = (float)$i$f$getArgbGreen / 255.0F;
      int $i$f$getArgbAlpha = 0;
      $i$f$getArgbBlue = color >> 24 & 255;
      $i$f$getArgbAlpha = 0;
      float $this$normalizeColor$iv = (float)$i$f$getArgbBlue / 255.0F;
      $i$f$getArgbAlpha = 0;
      if (!where) {
         block.invoke();
      } else {
         GL11.glColor4f(var11, $this$normalizeColor$iv, $this$normalizeColor$iv, $this$normalizeColor$iv);
         block.invoke();
         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      }

   }

   public static final int getArgb(@NotNull Vector4f $this$argb) {
      Intrinsics.checkNotNullParameter($this$argb, "<this>");
      int $i$f$getArgb = 0;
      float alpha$iv = $this$argb.w;
      float red$iv = $this$argb.x;
      float green$iv = $this$argb.y;
      float blue$iv = $this$argb.z;
      int $i$f$argb = 0;
      int $i$f$denormalizeColor = 0;
      int $this$denormalizeColor$iv$iv = (int)(alpha$iv * 255.0F + 0.5F);
      int $i$f$denormalizeColor = 0;
      $i$f$denormalizeColor = (int)(red$iv * 255.0F + 0.5F);
      int $i$f$denormalizeColor = 0;
      $i$f$denormalizeColor = (int)(green$iv * 255.0F + 0.5F);
      int $i$f$denormalizeColor = 0;
      $i$f$denormalizeColor = (int)(blue$iv * 255.0F + 0.5F);
      $i$f$denormalizeColor = 0;
      return $this$denormalizeColor$iv$iv << 24 | $i$f$denormalizeColor << 16 | $i$f$denormalizeColor << 8 | $i$f$denormalizeColor << 0;
   }

   public static final int getRgba(@NotNull Vector4f $this$rgba) {
      Intrinsics.checkNotNullParameter($this$rgba, "<this>");
      int $i$f$getRgba = 0;
      float red$iv = $this$rgba.x;
      float green$iv = $this$rgba.y;
      float blue$iv = $this$rgba.z;
      float alpha$iv = $this$rgba.w;
      int $i$f$rgba = 0;
      int $i$f$denormalizeColor = 0;
      int $this$denormalizeColor$iv$iv = (int)(red$iv * 255.0F + 0.5F);
      int $i$f$denormalizeColor = 0;
      $i$f$denormalizeColor = (int)(green$iv * 255.0F + 0.5F);
      int $i$f$denormalizeColor = 0;
      $i$f$denormalizeColor = (int)(blue$iv * 255.0F + 0.5F);
      int $i$f$denormalizeColor = 0;
      $i$f$denormalizeColor = (int)(alpha$iv * 255.0F + 0.5F);
      $i$f$denormalizeColor = 0;
      return $this$denormalizeColor$iv$iv << 24 | $i$f$denormalizeColor << 16 | $i$f$denormalizeColor << 8 | $i$f$denormalizeColor << 0;
   }

   public static final boolean getEmpty(@NotNull Texture $this$empty) {
      Intrinsics.checkNotNullParameter($this$empty, "<this>");
      int $i$f$getEmpty = 0;
      return Intrinsics.areEqual($this$empty, EmptyTexture.INSTANCE) || $this$empty.getLocation() == ResourceExtensionsKt.getNULL_LOCATION();
   }

   @JvmOverloads
   public static final void drawTexturedQuadFit(double x1, double y1, double x2, double y2) {
      drawTexturedQuadFit$default(x1, y1, x2, y2, 0, 16, (Object)null);
   }

   @JvmOverloads
   public static final void drawTexturedQuadFit(int x1, int y1, int x2, int y2) {
      drawTexturedQuadFit$default(x1, y1, x2, y2, 0, 16, (Object)null);
   }

   @JvmOverloads
   public static final void drawTexturedRect(int x1, int x2, int y1, int y2, int u1, int u2, int v1, int v2, int textureWidth, int textureHeight) {
      drawTexturedRect$default(x1, x2, y1, y2, u1, u2, v1, v2, textureWidth, textureHeight, 0, 1024, (Object)null);
   }

   @JvmOverloads
   public static final void drawTexturedRect(int posX, int posY, int u, int v, int width, int height, int textureWidth, int textureHeight, int zLevel) {
      drawTexturedRect$default(posX, posY, u, v, width, height, textureWidth, textureHeight, zLevel, (Tessellator)null, 512, (Object)null);
   }

   @JvmOverloads
   public static final void drawTexturedRect(int posX, int posY, int u, int v, int width, int height, int textureWidth, int textureHeight) {
      drawTexturedRect$default(posX, posY, u, v, width, height, textureWidth, textureHeight, 0, (Tessellator)null, 768, (Object)null);
   }

   @JvmOverloads
   public static final void drawTexturedRect(float posX, float posY, float u, float v, float width, float height, float textureWidth, float textureHeight, int zLevel) {
      drawTexturedRect$default(posX, posY, u, v, width, height, textureWidth, textureHeight, zLevel, (Tessellator)null, 512, (Object)null);
   }

   @JvmOverloads
   public static final void drawTexturedRect(float posX, float posY, float u, float v, float width, float height, float textureWidth, float textureHeight) {
      drawTexturedRect$default(posX, posY, u, v, width, height, textureWidth, textureHeight, 0, (Tessellator)null, 768, (Object)null);
   }

   @JvmOverloads
   public static final void drawTexturedFullRect(@NotNull Texture texture, int posX, int posY, int zLevel) {
      Intrinsics.checkNotNullParameter(texture, "texture");
      drawTexturedFullRect$default(texture, posX, posY, zLevel, (Tessellator)null, 16, (Object)null);
   }

   @JvmOverloads
   public static final void drawTexturedFullRect(@NotNull Texture texture, int posX, int posY) {
      Intrinsics.checkNotNullParameter(texture, "texture");
      drawTexturedFullRect$default(texture, posX, posY, 0, (Tessellator)null, 24, (Object)null);
   }

   @JvmOverloads
   public static final void drawSizeableTextureHorizontal(int posX, int posY, int width, @NotNull Texture leftTexture, @Nullable Texture centerTexture, @NotNull Texture rightTexture) {
      Intrinsics.checkNotNullParameter(leftTexture, "leftTexture");
      Intrinsics.checkNotNullParameter(rightTexture, "rightTexture");
      drawSizeableTextureHorizontal$default(posX, posY, width, leftTexture, centerTexture, rightTexture, 0, 64, (Object)null);
   }

   @JvmOverloads
   public static final void drawSizeableTextureVertical(int posX, int posY, int height, @NotNull Texture topTexture, @NotNull Texture centerTexture, @NotNull Texture bottomTexture) {
      Intrinsics.checkNotNullParameter(topTexture, "topTexture");
      Intrinsics.checkNotNullParameter(centerTexture, "centerTexture");
      Intrinsics.checkNotNullParameter(bottomTexture, "bottomTexture");
      drawSizeableTextureVertical$default(posX, posY, height, topTexture, centerTexture, bottomTexture, 0, 64, (Object)null);
   }

   @JvmOverloads
   public static final void drawRectangle(double x1, double y1, double x2, double y2, @Nullable Integer argbLeftBottom, @Nullable Integer argbRightBottom, @Nullable Integer argbRightTop, @Nullable Integer argbLeftTop, double zLevel) {
      drawRectangle$default(x1, y1, x2, y2, argbLeftBottom, argbRightBottom, argbRightTop, argbLeftTop, zLevel, (Tessellator)null, 512, (Object)null);
   }

   @JvmOverloads
   public static final void drawRectangle(double x1, double y1, double x2, double y2, @Nullable Integer argbLeftBottom, @Nullable Integer argbRightBottom, @Nullable Integer argbRightTop, @Nullable Integer argbLeftTop) {
      drawRectangle$default(x1, y1, x2, y2, argbLeftBottom, argbRightBottom, argbRightTop, argbLeftTop, (double)0.0F, (Tessellator)null, 768, (Object)null);
   }

   @JvmOverloads
   public static final void drawRectangle(double x1, double y1, double x2, double y2, @Nullable Integer argbLeftBottom, @Nullable Integer argbRightBottom, @Nullable Integer argbRightTop) {
      drawRectangle$default(x1, y1, x2, y2, argbLeftBottom, argbRightBottom, argbRightTop, (Integer)null, (double)0.0F, (Tessellator)null, 896, (Object)null);
   }

   @JvmOverloads
   public static final void drawRectangle(double x1, double y1, double x2, double y2, @Nullable Integer argbLeftBottom, @Nullable Integer argbRightBottom) {
      drawRectangle$default(x1, y1, x2, y2, argbLeftBottom, argbRightBottom, (Integer)null, (Integer)null, (double)0.0F, (Tessellator)null, 960, (Object)null);
   }

   @JvmOverloads
   public static final void drawRectangle(double x1, double y1, double x2, double y2, @Nullable Integer argbLeftBottom) {
      drawRectangle$default(x1, y1, x2, y2, argbLeftBottom, (Integer)null, (Integer)null, (Integer)null, (double)0.0F, (Tessellator)null, 992, (Object)null);
   }

   @JvmOverloads
   public static final void drawRectangle(double x1, double y1, double x2, double y2) {
      drawRectangle$default(x1, y1, x2, y2, (Integer)null, (Integer)null, (Integer)null, (Integer)null, (double)0.0F, (Tessellator)null, 1008, (Object)null);
   }

   @JvmOverloads
   public static final void drawPolygon(int color, @NotNull double[] data, int drawType) {
      Intrinsics.checkNotNullParameter(data, "data");
      drawPolygon$default(color, data, drawType, (double)0.0F, 8, (Object)null);
   }

   @JvmOverloads
   public static final void drawPolygon(int color, @NotNull double[] data) {
      Intrinsics.checkNotNullParameter(data, "data");
      drawPolygon$default(color, data, 0, (double)0.0F, 12, (Object)null);
   }

   @JvmOverloads
   public static final void drawLine(double x1, double x2, double y1, double y2, int argb, double lineWidth) {
      drawLine$default(x1, x2, y1, y2, argb, lineWidth, (double)0.0F, 64, (Object)null);
   }

   @JvmOverloads
   public static final void drawLine(double x1, double x2, double y1, double y2, int argb) {
      drawLine$default(x1, x2, y1, y2, argb, (double)0.0F, (double)0.0F, 96, (Object)null);
   }

   @JvmOverloads
   public static final void drawVerticalLine(double x, double y1, double y2, int argb, double lineWidth) {
      drawVerticalLine$default(x, y1, y2, argb, lineWidth, (double)0.0F, 32, (Object)null);
   }

   @JvmOverloads
   public static final void drawVerticalLine(double x, double y1, double y2, int argb) {
      drawVerticalLine$default(x, y1, y2, argb, (double)0.0F, (double)0.0F, 48, (Object)null);
   }

   @JvmOverloads
   public static final void drawHorizontalLine(double x1, double x2, double y, int argb, double lineWidth) {
      drawHorizontalLine$default(x1, x2, y, argb, lineWidth, (double)0.0F, 32, (Object)null);
   }

   @JvmOverloads
   public static final void drawHorizontalLine(double x1, double x2, double y, int argb) {
      drawHorizontalLine$default(x1, x2, y, argb, (double)0.0F, (double)0.0F, 48, (Object)null);
   }

   @JvmOverloads
   public static final void drawRectangleOutline(double x1, double y1, double x2, double y2, int argb, double borderWidth) {
      drawRectangleOutline$default(x1, y1, x2, y2, argb, borderWidth, (double)0.0F, 64, (Object)null);
   }

   @JvmOverloads
   public static final void drawRectangleOutline(double x1, double y1, double x2, double y2, int argb) {
      drawRectangleOutline$default(x1, y1, x2, y2, argb, (double)0.0F, (double)0.0F, 96, (Object)null);
   }

   @JvmOverloads
   public static final void drawCorneredRectangle(double x1, double y1, double x2, double y2, int argb, double corner, int drawType) {
      drawCorneredRectangle$default(x1, y1, x2, y2, argb, corner, drawType, (double)0.0F, 128, (Object)null);
   }

   @JvmOverloads
   public static final void drawCorneredRectangle(double x1, double y1, double x2, double y2, int argb, double corner) {
      drawCorneredRectangle$default(x1, y1, x2, y2, argb, corner, 0, (double)0.0F, 192, (Object)null);
   }

   private static final Integer drawRectangle$lambda$10$setColor(Tessellator $this_with, Integer color) {
      Integer var10000;
      if (color != null) {
         int it = ((Number)color).intValue();
         int var4 = 0;
         int $i$f$getArgbRed = 0;
         int var10001 = it >> 16 & 255;
         $i$f$getArgbRed = 0;
         int var10002 = it >> 8 & 255;
         $i$f$getArgbRed = 0;
         int var10003 = it >> 0 & 255;
         $i$f$getArgbRed = 0;
         $this_with.func_78370_a(var10001, var10002, var10003, it >> 24 & 255);
         var10000 = color;
      } else {
         var10000 = null;
      }

      return var10000;
   }
}

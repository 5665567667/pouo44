package loliland.graphics.renderer.font;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector2f;

@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\u0018\u00002\u00020\u0001B-\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0005\u0012\u0006\u0010\b\u001a\u00020\u0003¢\u0006\u0002\u0010\tJ\u0013\u0010\u0011\u001a\u00020\u00122\b\u0010\u0013\u001a\u0004\u0018\u00010\u0001H\u0096\u0002J\b\u0010\u0014\u001a\u00020\u0003H\u0016J\b\u0010\u0015\u001a\u00020\u0016H\u0016R\u0011\u0010\b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\u000bR\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u000eR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u000e¨\u0006\u0017"},
   d2 = {"Lloliland/graphics/renderer/font/FontGlyph;", "", "code", "", "position", "Lorg/joml/Vector2f;", "size", "offset", "advance", "(ILorg/joml/Vector2f;Lorg/joml/Vector2f;Lorg/joml/Vector2f;I)V", "getAdvance", "()I", "getCode", "getOffset", "()Lorg/joml/Vector2f;", "getPosition", "getSize", "equals", "", "other", "hashCode", "toString", "", "loligraphics-1.7.10"}
)
public final class FontGlyph {
   private final int code;
   @NotNull
   private final Vector2f position;
   @NotNull
   private final Vector2f size;
   @NotNull
   private final Vector2f offset;
   private final int advance;

   public FontGlyph(int code, @NotNull Vector2f position, @NotNull Vector2f size, @NotNull Vector2f offset, int advance) {
      Intrinsics.checkNotNullParameter(position, "position");
      Intrinsics.checkNotNullParameter(size, "size");
      Intrinsics.checkNotNullParameter(offset, "offset");
      super();
      this.code = code;
      this.position = position;
      this.size = size;
      this.offset = offset;
      this.advance = advance;
   }

   public final int getCode() {
      return this.code;
   }

   @NotNull
   public final Vector2f getPosition() {
      return this.position;
   }

   @NotNull
   public final Vector2f getSize() {
      return this.size;
   }

   @NotNull
   public final Vector2f getOffset() {
      return this.offset;
   }

   public final int getAdvance() {
      return this.advance;
   }

   public boolean equals(@Nullable Object other) {
      return other instanceof FontGlyph && this.code == ((FontGlyph)other).code;
   }

   public int hashCode() {
      return this.code;
   }

   @NotNull
   public String toString() {
      return "FontGlyph(code=" + this.code + ", position=" + this.position + ", size=" + this.size + ", offset=" + this.offset + ", advance=" + this.advance + ')';
   }
}

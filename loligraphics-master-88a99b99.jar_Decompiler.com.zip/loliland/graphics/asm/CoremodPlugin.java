package loliland.graphics.asm;

import cpw.mods.fml.relauncher.IFMLLoadingPlugin;
import cpw.mods.fml.relauncher.IFMLLoadingPlugin.MCVersion;
import cpw.mods.fml.relauncher.IFMLLoadingPlugin.Name;
import io.github.tox1cozz.mixinbooterlegacy.IEarlyMixinLoader;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Name("loligraphics")
@MCVersion("1.7.10")
@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0001\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010%\n\u0002\u0010\u0000\n\u0000\b\u0007\u0018\u00002\u00020\u00012\u00020\u0002B\u0005¢\u0006\u0002\u0010\u0003J\n\u0010\u0004\u001a\u0004\u0018\u00010\u0005H\u0016J\n\u0010\u0006\u001a\u0004\u0018\u00010\u0005H\u0016J\u000e\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\t0\bH\u0017J\n\u0010\n\u001a\u0004\u0018\u00010\u0005H\u0016J\n\u0010\u000b\u001a\u0004\u0018\u00010\u0005H\u0016J\u001c\u0010\f\u001a\u00020\r2\u0012\u0010\u000e\u001a\u000e\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020\u00100\u000fH\u0016¨\u0006\u0011"},
   d2 = {"Lloliland/graphics/asm/CoremodPlugin;", "Lcpw/mods/fml/relauncher/IFMLLoadingPlugin;", "Lio/github/tox1cozz/mixinbooterlegacy/IEarlyMixinLoader;", "()V", "getASMTransformerClass", "", "getAccessTransformerClass", "getMixinConfigs", "", "", "getModContainerClass", "getSetupClass", "injectData", "", "data", "", "", "loligraphics-1.7.10"}
)
public final class CoremodPlugin implements IFMLLoadingPlugin, IEarlyMixinLoader {
   @Nullable
   public Void getASMTransformerClass() {
      return null;
   }

   @Nullable
   public Void getModContainerClass() {
      return null;
   }

   @Nullable
   public Void getSetupClass() {
      return null;
   }

   @Nullable
   public Void getAccessTransformerClass() {
      return null;
   }

   public void injectData(@NotNull Map<String, Object> data) {
      Intrinsics.checkNotNullParameter(data, "data");
   }

   @NotNull
   public List<String> getMixinConfigs() {
      return null;
   }
}

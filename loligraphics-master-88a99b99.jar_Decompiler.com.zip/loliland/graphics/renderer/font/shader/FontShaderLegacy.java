package loliland.graphics.renderer.font.shader;

import java.util.Set;
import kotlin.Metadata;
import kotlin.collections.SetsKt;
import kotlin.jvm.internal.SourceDebugExtension;
import loliland.graphics.renderer.GLCompatible;
import loliland.graphics.renderer.shader.Shader;
import loliland.graphics.renderer.shader.uniform.UniformFloat;
import loliland.graphics.renderer.shader.uniform.UniformVec2f;
import loliland.graphics.renderer.shader.uniform.UniformVec3f;
import loliland.graphics.renderer.shader.uniform.UniformVec4f;
import net.minecraft.util.ResourceLocation;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\"\n\u0002\u0010\b\n\u0002\b\u0005\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u0011\u0010\u0003\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R\u0011\u0010\u0007\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\u0006R\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\r\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u0006R\u0011\u0010\u000f\u001a\u00020\u0010¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0013\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0006R\u0011\u0010\u0015\u001a\u00020\u0016¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u0011\u0010\u0019\u001a\u00020\u0016¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0018R\u001a\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u001d0\u001cX\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u001fR\u0011\u0010 \u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b!\u0010\u0006¨\u0006\""},
   d2 = {"Lloliland/graphics/renderer/font/shader/FontShaderLegacy;", "Lloliland/graphics/renderer/shader/Shader;", "()V", "borderEdge", "Lloliland/graphics/renderer/shader/uniform/UniformFloat;", "getBorderEdge", "()Lloliland/graphics/renderer/shader/uniform/UniformFloat;", "borderWidth", "getBorderWidth", "color", "Lloliland/graphics/renderer/shader/uniform/UniformVec4f;", "getColor", "()Lloliland/graphics/renderer/shader/uniform/UniformVec4f;", "edge", "getEdge", "offset", "Lloliland/graphics/renderer/shader/uniform/UniformVec2f;", "getOffset", "()Lloliland/graphics/renderer/shader/uniform/UniformVec2f;", "opacity", "getOpacity", "outlineColor", "Lloliland/graphics/renderer/shader/uniform/UniformVec3f;", "getOutlineColor", "()Lloliland/graphics/renderer/shader/uniform/UniformVec3f;", "position", "getPosition", "types", "", "", "getTypes", "()Ljava/util/Set;", "width", "getWidth", "loligraphics-1.7.10"}
)
@SourceDebugExtension({"SMAP\nFontShaderLegacy.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FontShaderLegacy.kt\nloliland/graphics/renderer/font/shader/FontShaderLegacy\n+ 2 Shader.kt\nloliland/graphics/renderer/shader/Shader\n*L\n1#1,30:1\n25#2:31\n25#2:32\n25#2:33\n25#2:34\n25#2:35\n25#2:36\n25#2:37\n25#2:38\n25#2:39\n*S KotlinDebug\n*F\n+ 1 FontShaderLegacy.kt\nloliland/graphics/renderer/font/shader/FontShaderLegacy\n*L\n21#1:31\n22#1:32\n23#1:33\n24#1:34\n25#1:35\n26#1:36\n27#1:37\n28#1:38\n29#1:39\n*E\n"})
public final class FontShaderLegacy extends Shader {
   @NotNull
   public static final FontShaderLegacy INSTANCE = new FontShaderLegacy();
   @NotNull
   private static final Set<Integer> types;
   @NotNull
   private static final UniformVec4f color;
   @NotNull
   private static final UniformVec3f outlineColor;
   @NotNull
   private static final UniformVec3f position;
   @NotNull
   private static final UniformFloat width;
   @NotNull
   private static final UniformFloat edge;
   @NotNull
   private static final UniformFloat borderWidth;
   @NotNull
   private static final UniformFloat borderEdge;
   @NotNull
   private static final UniformVec2f offset;
   @NotNull
   private static final UniformFloat opacity;

   private FontShaderLegacy() {
      super(new ResourceLocation("shaders/font/legacy"));
   }

   @NotNull
   public Set<Integer> getTypes() {
      return types;
   }

   @NotNull
   public final UniformVec4f getColor() {
      return color;
   }

   @NotNull
   public final UniformVec3f getOutlineColor() {
      return outlineColor;
   }

   @NotNull
   public final UniformVec3f getPosition() {
      return position;
   }

   @NotNull
   public final UniformFloat getWidth() {
      return width;
   }

   @NotNull
   public final UniformFloat getEdge() {
      return edge;
   }

   @NotNull
   public final UniformFloat getBorderWidth() {
      return borderWidth;
   }

   @NotNull
   public final UniformFloat getBorderEdge() {
      return borderEdge;
   }

   @NotNull
   public final UniformVec2f getOffset() {
      return offset;
   }

   @NotNull
   public final UniformFloat getOpacity() {
      return opacity;
   }

   static {
      Integer[] var0 = new Integer[]{GLCompatible.GL_VERTEX_SHADER, GLCompatible.GL_FRAGMENT_SHADER};
      types = SetsKt.setOf(var0);
      INSTANCE.createAttribute("position");
      INSTANCE.createAttribute("textureCoords");
      Shader this_$iv = INSTANCE;
      String name$iv = "color";
      int $i$f$createUniform = 0;
      color = (UniformVec4f)this_$iv.createUniform(UniformVec4f.class, name$iv);
      this_$iv = INSTANCE;
      name$iv = "outlineColor";
      $i$f$createUniform = 0;
      outlineColor = (UniformVec3f)this_$iv.createUniform(UniformVec3f.class, name$iv);
      this_$iv = INSTANCE;
      name$iv = "position";
      $i$f$createUniform = 0;
      position = (UniformVec3f)this_$iv.createUniform(UniformVec3f.class, name$iv);
      this_$iv = INSTANCE;
      name$iv = "width";
      $i$f$createUniform = 0;
      width = (UniformFloat)this_$iv.createUniform(UniformFloat.class, name$iv);
      this_$iv = INSTANCE;
      name$iv = "edge";
      $i$f$createUniform = 0;
      edge = (UniformFloat)this_$iv.createUniform(UniformFloat.class, name$iv);
      this_$iv = INSTANCE;
      name$iv = "borderWidth";
      $i$f$createUniform = 0;
      borderWidth = (UniformFloat)this_$iv.createUniform(UniformFloat.class, name$iv);
      this_$iv = INSTANCE;
      name$iv = "borderEdge";
      $i$f$createUniform = 0;
      borderEdge = (UniformFloat)this_$iv.createUniform(UniformFloat.class, name$iv);
      this_$iv = INSTANCE;
      name$iv = "offset";
      $i$f$createUniform = 0;
      offset = (UniformVec2f)this_$iv.createUniform(UniformVec2f.class, name$iv);
      this_$iv = INSTANCE;
      name$iv = "opacity";
      $i$f$createUniform = 0;
      opacity = (UniformFloat)this_$iv.createUniform(UniformFloat.class, name$iv);
   }
}

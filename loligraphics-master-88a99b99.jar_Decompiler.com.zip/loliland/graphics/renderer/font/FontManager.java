package loliland.graphics.renderer.font;

import cpw.mods.fml.common.ProgressManager;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import loliland.graphics.LoliGraphics;
import loliland.graphics.renderer.GLCompatible;
import loliland.graphics.renderer.font.shader.FontShaderActual;
import loliland.graphics.renderer.font.shader.FontShaderLegacy;
import loliland.graphics.renderer.font.shader.FontShaderSuperLegacy;
import loliland.graphics.renderer.shader.Shader;
import loliland.graphics.renderer.shader.ShaderManager;
import loliland.graphics.renderer.texture.TextureManager;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.client.resources.IResourceManagerReloadListener;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.util.ReportedException;
import net.minecraft.util.ResourceLocation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.lwjglx.LWJGLUtil;
import org.lwjglx.opengl.GL11;

@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000]\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010%\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0004*\u0001\u000f\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0006\u0010\u0018\u001a\u00020\u0019J\u000e\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u001dJ\u0014\u0010\u001e\u001a\u00020\u001b2\f\u0010\u001f\u001a\b\u0012\u0004\u0012\u00020\u001d0 J\b\u0010!\u001a\u00020\u001bH\u0002J\u000e\u0010\"\u001a\u00020\u00062\u0006\u0010#\u001a\u00020\u0006J\u000e\u0010$\u001a\u00020\u00192\u0006\u0010#\u001a\u00020\u0006J\u000e\u0010%\u001a\u00020\u001b2\u0006\u0010#\u001a\u00020\u0006J\u0010\u0010&\u001a\u00020\u001b2\u0006\u0010'\u001a\u00020(H\u0016J\b\u0010)\u001a\u00020\u001bH\u0002J\u0010\u0010*\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u001dH\u0002J\u000e\u0010+\u001a\u00020\u001b2\u0006\u0010#\u001a\u00020\u0006R\u001d\u0010\u0003\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00060\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0010\u0010\t\u001a\u0004\u0018\u00010\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u000b\u001a\n \r*\u0004\u0018\u00010\f0\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u000e\u001a\u00020\u000fX\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0010R\u0011\u0010\u0011\u001a\u00020\n8F¢\u0006\u0006\u001a\u0004\b\u0012\u0010\u0013R\u0011\u0010\u0014\u001a\u00020\u00158F¢\u0006\u0006\u001a\u0004\b\u0016\u0010\u0017¨\u0006,"},
   d2 = {"Lloliland/graphics/renderer/font/FontManager;", "Lnet/minecraft/client/resources/IResourceManagerReloadListener;", "()V", "fonts", "", "Lnet/minecraft/util/ResourceLocation;", "Lloliland/graphics/renderer/font/Font;", "getFonts", "()Ljava/util/Map;", "forcedRenderMode", "Lloliland/graphics/renderer/font/FontRenderMode;", "log", "Lorg/apache/logging/log4j/Logger;", "kotlin.jvm.PlatformType", "openglState", "loliland/graphics/renderer/font/FontManager$openglState$1", "Lloliland/graphics/renderer/font/FontManager$openglState$1;", "renderMode", "getRenderMode", "()Lloliland/graphics/renderer/font/FontRenderMode;", "shader", "Lloliland/graphics/renderer/shader/Shader;", "getShader", "()Lloliland/graphics/renderer/shader/Shader;", "dispose", "", "drawText", "", "text", "Lloliland/graphics/renderer/font/FontText;", "drawTextsBatch", "texts", "", "endText", "getOrLoadFont", "font", "isFontLoaded", "loadFont", "onResourceManagerReload", "resourceManager", "Lnet/minecraft/client/resources/IResourceManager;", "prepareText", "renderText", "schedulePreload", "loligraphics-1.7.10"}
)
@SourceDebugExtension({"SMAP\nFontManager.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FontManager.kt\nloliland/graphics/renderer/font/FontManager\n+ 2 ShaderManager.kt\nloliland/graphics/renderer/shader/ShaderManager\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 _Maps.kt\nkotlin/collections/MapsKt___MapsKt\n*L\n1#1,181:1\n158#2,8:182\n158#2,8:193\n1726#3,3:190\n1855#3,2:203\n215#4,2:201\n*S KotlinDebug\n*F\n+ 1 FontManager.kt\nloliland/graphics/renderer/font/FontManager\n*L\n105#1:182,8\n117#1:193,8\n112#1:190,3\n152#1:203,2\n137#1:201,2\n*E\n"})
public final class FontManager implements IResourceManagerReloadListener {
   @NotNull
   public static final FontManager INSTANCE = new FontManager();
   private static final Logger log = LogManager.getLogger("Font Manager");
   @NotNull
   private static final Map<ResourceLocation, Font> fonts = (Map)(new LinkedHashMap());
   @Nullable
   private static final FontRenderMode forcedRenderMode;
   @NotNull
   private static final <undefinedtype> openglState;

   private FontManager() {
   }

   @NotNull
   public final Map<ResourceLocation, Font> getFonts() {
      return fonts;
   }

   @NotNull
   public final FontRenderMode getRenderMode() {
      FontRenderMode var10000 = forcedRenderMode;
      if (var10000 == null) {
         var10000 = LWJGLUtil.getPlatform() == 2 ? FontRenderMode.SUPER_LEGACY : (GLCompatible.supportedOpenGL33 ? (GLCompatible.isVertexArraysSupported() ? FontRenderMode.ACTUAL_VAO : FontRenderMode.ACTUAL_VBO) : (GLCompatible.isVertexArraysSupported() ? FontRenderMode.LEGACY_VAO : FontRenderMode.LEGACY_VBO));
      }

      return var10000;
   }

   @NotNull
   public final Shader getShader() {
      Shader var10000;
      switch (FontManager.WhenMappings.$EnumSwitchMapping$0[this.getRenderMode().getShader().ordinal()]) {
         case 1:
            var10000 = FontShaderActual.INSTANCE;
            break;
         case 2:
            var10000 = FontShaderLegacy.INSTANCE;
            break;
         case 3:
            var10000 = FontShaderSuperLegacy.INSTANCE;
            break;
         default:
            throw new NoWhenBranchMatchedException();
      }

      return var10000;
   }

   public final void loadFont(@NotNull Font font) {
      Intrinsics.checkNotNullParameter(font, "font");
      font.dispose();
      fonts.put(font.getLocation(), font);

      try {
         font.load(TextureManager.INSTANCE);
         Logger var10000 = log;
         Object[] var2 = new Object[]{font.getLocation()};
         var10000.debug("Loaded font: {}", var2);
      } catch (Throwable e) {
         CrashReport report = CrashReport.func_85055_a(e, "Registering font");
         CrashReportCategory category = report.func_85058_a("Resource location being registered");
         category.func_71507_a("Resource location", font.getLocation());
         category.func_71507_a("Metadata location", font.getMetadataLocation());
         category.func_71507_a("Texture location", font.getTextureLocation());
         category.func_71500_a("Font object class", FontManager::loadFont$lambda$1);
         throw new ReportedException(report);
      }
   }

   public final void schedulePreload(@NotNull Font font) {
      Intrinsics.checkNotNullParameter(font, "font");
      fonts.putIfAbsent(font.getLocation(), font);
   }

   @NotNull
   public final Font getOrLoadFont(@NotNull Font font) {
      Intrinsics.checkNotNullParameter(font, "font");
      Font var10000 = (Font)fonts.get(font.getLocation());
      if (var10000 == null) {
         var10000 = font;
      }

      Font managed = var10000;
      if (!this.isFontLoaded(managed)) {
         this.loadFont(managed);
      }

      return managed;
   }

   private final void prepareText() {
      openglState.capture();
      GL11.glEnable(3042);
      GLCompatible.glBlendFunc(770, 771, 1, 0);
      GL11.glDisable(3008);
      GLCompatible.activeTexture(GLCompatible.GL_TEXTURE0);
   }

   private final void renderText(FontText text) {
      if (!text.getEmpty() || text.getRenderEmpty()) {
         text.getFont().getTexture().bind();
         switch (FontManager.WhenMappings.$EnumSwitchMapping$0[this.getRenderMode().getShader().ordinal()]) {
            case 1:
               text.renderActual();
               break;
            case 2:
               text.renderLegacy();
               break;
            case 3:
               text.renderSuperLegacy();
         }

      }
   }

   public final void drawText(@NotNull FontText text) {
      Intrinsics.checkNotNullParameter(text, "text");
      this.prepareText();
      ShaderManager this_$iv = ShaderManager.INSTANCE;
      Shader shader$iv = this.getShader();
      int $i$f$useShader = 0;
      this_$iv.bindShader(shader$iv);
      int var6 = 0;
      INSTANCE.renderText(text);
      this_$iv.unbindShader(shader$iv);
      this.endText();
   }

   public final void drawTextsBatch(@NotNull List<FontText> texts) {
      Intrinsics.checkNotNullParameter(texts, "texts");
      Iterable $this$all$iv = (Iterable)texts;
      int $i$f$all = 0;
      boolean var10000;
      if ($this$all$iv instanceof Collection && ((Collection)$this$all$iv).isEmpty()) {
         var10000 = true;
      } else {
         Iterator var4 = $this$all$iv.iterator();

         while(true) {
            if (!var4.hasNext()) {
               var10000 = true;
               break;
            }

            Object element$iv = var4.next();
            FontText it = (FontText)element$iv;
            int var7 = 0;
            if (!it.getEmpty() || it.getRenderEmpty()) {
               var10000 = false;
               break;
            }
         }
      }

      if (!var10000) {
         this.prepareText();
         ShaderManager this_$iv = ShaderManager.INSTANCE;
         Shader shader$iv = this.getShader();
         int $i$f$useShader = 0;
         this_$iv.bindShader(shader$iv);
         int var14 = 0;
         int var15 = texts.size();

         for(int it = 0; it < var15; ++it) {
            int var10 = 0;
            INSTANCE.renderText((FontText)texts.get(it));
         }

         this_$iv.unbindShader(shader$iv);
         this.endText();
      }
   }

   private final void endText() {
      openglState.restore();
   }

   public void func_110549_a(@NotNull IResourceManager resourceManager) {
      Intrinsics.checkNotNullParameter(resourceManager, "resourceManager");
      if (!LoliGraphics.INSTANCE.getLoadingScreenActive()) {
         HashMap reloaded = new HashMap(fonts);
         fonts.clear();
         ProgressManager.ProgressBar bar = ProgressManager.push("Reloading Font Manager", reloaded.size(), true);
         Map $this$forEach$iv = (Map)reloaded;
         int $i$f$forEach = 0;

         for(Map.Entry element$iv : $this$forEach$iv.entrySet()) {
            int var9 = 0;
            ResourceLocation location = (ResourceLocation)element$iv.getKey();
            Font font = (Font)element$iv.getValue();
            bar.step(location.toString());
            FontManager var10000 = INSTANCE;
            Intrinsics.checkNotNull(font);
            var10000.loadFont(font);
         }

         ProgressManager.pop(bar);
      }
   }

   public final boolean isFontLoaded(@NotNull Font font) {
      Intrinsics.checkNotNullParameter(font, "font");
      return fonts.get(font.getLocation()) == font && font.getLoaded() && font.getTexture().getId() > 0 && GL11.glIsTexture(font.getTexture().getId());
   }

   public final boolean dispose() {
      Iterable $this$forEach$iv = (Iterable)fonts.values();
      int $i$f$forEach = 0;

      for(Object element$iv : $this$forEach$iv) {
         Font it = (Font)element$iv;
         int var6 = 0;
         it.dispose();
      }

      fonts.clear();
      return true;
   }

   private static final Object loadFont$lambda$1(Font $font) {
      Intrinsics.checkNotNullParameter($font, "$font");
      return $font.getClass().getName();
   }

   static {
      String var10000 = System.getProperty("loligraphics.font.renderMode");
      FontRenderMode var5;
      if (var10000 != null) {
         String it = var10000;
         int var1 = 0;
         Locale var3 = Locale.ENGLISH;
         Intrinsics.checkNotNullExpressionValue(var3, "ENGLISH");
         String var4 = it.toUpperCase(var3);
         Intrinsics.checkNotNullExpressionValue(var4, "toUpperCase(...)");
         var5 = FontRenderMode.valueOf(var4);
      } else {
         var5 = null;
      }

      forcedRenderMode = var5;
      openglState = (<undefinedtype>)(new Object() {
         private boolean blend;
         private boolean alphaTest;

         public final boolean getBlend() {
            return this.blend;
         }

         public final void setBlend(boolean var1) {
            this.blend = var1;
         }

         public final boolean getAlphaTest() {
            return this.alphaTest;
         }

         public final void setAlphaTest(boolean var1) {
            this.alphaTest = var1;
         }

         public final void capture() {
            this.blend = GL11.glGetBoolean(3042);
            this.alphaTest = GL11.glGetBoolean(3008);
         }

         public final void restore() {
            restore$setBoolean(3042, this.blend);
            restore$setBoolean(3008, this.alphaTest);
         }

         private static final void restore$setBoolean(int cap, boolean value) {
            if (value) {
               GL11.glEnable(cap);
            } else {
               GL11.glDisable(cap);
            }

         }
      });
   }

   // $FF: synthetic class
   @Metadata(
      mv = {1, 9, 0},
      k = 3,
      xi = 48
   )
   public class WhenMappings {
      // $FF: synthetic field
      public static final int[] $EnumSwitchMapping$0;

      static {
         int[] var0 = new int[FontRenderMode.Shader.values().length];

         try {
            var0[FontRenderMode.Shader.ACTUAL.ordinal()] = 1;
         } catch (NoSuchFieldError var4) {
         }

         try {
            var0[FontRenderMode.Shader.LEGACY.ordinal()] = 2;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[FontRenderMode.Shader.SUPER_LEGACY.ordinal()] = 3;
         } catch (NoSuchFieldError var2) {
         }

         $EnumSwitchMapping$0 = var0;
      }
   }
}

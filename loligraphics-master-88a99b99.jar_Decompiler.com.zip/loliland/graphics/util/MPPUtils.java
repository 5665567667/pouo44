package loliland.graphics.util;

import com.gamerforea.mpp.api.client.INativeImage;
import com.gamerforea.mpp.api.client.NativeImageUtils;
import java.io.IOException;
import java.io.InputStream;
import loliland.graphics.renderer.texture.TextureManager;

public final class MPPUtils {
   public static final boolean LOADED = System.getProperty("loligraphics.useMPP", "true").equalsIgnoreCase("true");

   public static TextureManager.TextureData loadTexture(InputStream in) throws IOException {
      INativeImage image = NativeImageUtils.load(in);
      Throwable var2 = null;

      TextureManager.TextureData var3;
      try {
         var3 = new TextureManager.TextureData(image.getWidth(), image.getHeight(), image.getDirectARGB());
      } catch (Throwable var12) {
         var2 = var12;
         throw var12;
      } finally {
         if (image != null) {
            if (var2 != null) {
               try {
                  image.close();
               } catch (Throwable var11) {
                  var2.addSuppressed(var11);
               }
            } else {
               image.close();
            }
         }

      }

      return var3;
   }
}

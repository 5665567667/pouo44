package loliland.graphics.renderer.texture.png;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.util.Arrays;
import java.util.zip.CRC32;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

public class PNGDecoder {
   private static final byte[] SIGNATURE = new byte[]{-119, 80, 78, 71, 13, 10, 26, 10};
   private static final int IHDR = 1229472850;
   private static final int PLTE = 1347179589;
   private static final int tRNS = 1951551059;
   private static final int IDAT = 1229209940;
   private static final int IEND = 1229278788;
   public static final byte COLOR_GREYSCALE = 0;
   public static final byte COLOR_TRUECOLOR = 2;
   public static final byte COLOR_INDEXED = 3;
   public static final byte COLOR_GREYALPHA = 4;
   public static final byte COLOR_TRUEALPHA = 6;
   private final InputStream input;
   private final CRC32 crc;
   private final byte[] buffer;
   private int chunkLength;
   private int chunkType;
   private int chunkRemaining;
   private int width;
   private int height;
   private int bitDepth;
   private int colorType;
   private int colorComponents;
   private byte[] palette;
   private byte[] paletteA;
   private byte[] transPixel;

   public PNGDecoder(InputStream input) throws IOException {
      this(input, 8192);
   }

   public PNGDecoder(InputStream input, int bufferSize) throws IOException {
      this.input = input;
      this.crc = new CRC32();
      this.buffer = new byte[bufferSize];
      this.readFully(this.buffer, 0, SIGNATURE.length);

      for(int i = 0; i < SIGNATURE.length; ++i) {
         if (this.buffer[i] != SIGNATURE[i]) {
            throw new IOException("Not a valid PNG file");
         }
      }

      this.openChunk(1229472850);
      this.readIHDR();
      this.closeChunk();

      while(true) {
         this.openChunk();
         switch (this.chunkType) {
            case 1229209940:
               if (this.colorType == 3 && this.palette == null) {
                  throw new IOException("Missing PLTE chunk");
               }

               return;
            case 1347179589:
               this.readPLTE();
               break;
            case 1951551059:
               this.readtRNS();
         }

         this.closeChunk();
      }
   }

   public boolean hasAlphaChannel() {
      return this.colorType == 6 || this.colorType == 4;
   }

   public boolean hasAlpha() {
      return this.hasAlphaChannel() || this.paletteA != null || this.transPixel != null;
   }

   public boolean isRGB() {
      return this.colorType == 6 || this.colorType == 2 || this.colorType == 3;
   }

   public void overwriteTRNS(byte r, byte g, byte b) {
      if (this.hasAlphaChannel()) {
         throw new UnsupportedOperationException("image has an alpha channel");
      } else {
         byte[] pal = this.palette;
         if (pal == null) {
            this.transPixel = new byte[]{0, r, 0, g, 0, b};
         } else {
            this.paletteA = new byte[pal.length / 3];
            int i = 0;

            for(int j = 0; i < pal.length; ++j) {
               if (pal[i] != r || pal[i + 1] != g || pal[i + 2] != b) {
                  this.paletteA[j] = -1;
               }

               i += 3;
            }
         }

      }
   }

   public Format decideTextureFormat(Format fmt) {
      switch (this.colorType) {
         case 0:
            switch (fmt) {
               case LUMINANCE:
               case ALPHA:
                  return fmt;
               default:
                  return PNGDecoder.Format.LUMINANCE;
            }
         case 1:
         case 5:
         default:
            throw new UnsupportedOperationException("Not yet implemented");
         case 2:
            switch (fmt) {
               case ABGR:
               case RGBA:
               case ARGB:
               case BGRA:
               case RGB:
                  return fmt;
               default:
                  return PNGDecoder.Format.RGB;
            }
         case 3:
            switch (fmt) {
               case ABGR:
               case RGBA:
               case ARGB:
               case BGRA:
                  return fmt;
               default:
                  return PNGDecoder.Format.RGBA;
            }
         case 4:
            return PNGDecoder.Format.LUMINANCE_ALPHA;
         case 6:
            switch (fmt) {
               case ABGR:
               case RGBA:
               case ARGB:
               case BGRA:
               case RGB:
                  return fmt;
               default:
                  return PNGDecoder.Format.RGBA;
            }
      }
   }

   public void decode(ByteBuffer buffer, int stride, Format format) throws IOException {
      int offset = buffer.position();
      int lineSize = (this.width * this.bitDepth + 7) / 8 * this.colorComponents;
      byte[] curLine = new byte[lineSize + 1];
      byte[] prevLine = new byte[lineSize + 1];
      byte[] palLine = this.bitDepth < 8 ? new byte[this.width + 1] : null;
      Inflater inflater = new Inflater();

      try {
         for(int y = 0; y < this.height; ++y) {
            this.readChunkUnzip(inflater, curLine, 0, curLine.length);
            this.unfilter(curLine, prevLine);
            buffer.position(offset + y * stride);
            label109:
            switch (this.colorType) {
               case 0:
                  switch (format) {
                     case LUMINANCE:
                     case ALPHA:
                        this.copyToByteBuffer(buffer, curLine);
                        break label109;
                     default:
                        throw new UnsupportedOperationException("Unsupported format for this image");
                  }
               case 1:
               case 5:
               default:
                  throw new UnsupportedOperationException("Not yet implemented");
               case 2:
                  switch (format) {
                     case ABGR:
                     case RGBA:
                     case ARGB:
                     case BGRA:
                        this.copyRGBtoFormatByte(buffer, curLine, format);
                        break label109;
                     case RGB:
                        this.copyToByteBuffer(buffer, curLine);
                        break label109;
                     default:
                        throw new UnsupportedOperationException("Unsupported format for this image");
                  }
               case 3:
                  switch (this.bitDepth) {
                     case 1:
                        this.expand1(curLine, palLine);
                        break;
                     case 2:
                        this.expand2(curLine, palLine);
                        break;
                     case 3:
                     case 5:
                     case 6:
                     case 7:
                     default:
                        throw new UnsupportedOperationException("Unsupported bitdepth for this image");
                     case 4:
                        this.expand4(curLine, palLine);
                        break;
                     case 8:
                        palLine = curLine;
                  }

                  switch (format) {
                     case ABGR:
                     case RGBA:
                     case ARGB:
                     case BGRA:
                        this.copyPALtoFormatByte(buffer, palLine, format);
                        break label109;
                     default:
                        throw new UnsupportedOperationException("Unsupported format for this image");
                  }
               case 4:
                  if (format != PNGDecoder.Format.LUMINANCE_ALPHA) {
                     throw new UnsupportedOperationException("Unsupported format for this image");
                  }

                  this.copyToByteBuffer(buffer, curLine);
                  break;
               case 6:
                  switch (format) {
                     case ABGR:
                     case ARGB:
                     case BGRA:
                     case RGB:
                        this.copyRGBAtoFormatByte(buffer, curLine, format);
                        break;
                     case RGBA:
                        this.copyToByteBuffer(buffer, curLine);
                        break;
                     default:
                        throw new UnsupportedOperationException("Unsupported format for this image");
                  }
            }

            byte[] tmp = curLine;
            curLine = prevLine;
            prevLine = tmp;
         }
      } finally {
         inflater.end();
      }

   }

   public void decode(IntBuffer buffer, int stride, Format format) throws IOException {
      int offset = buffer.position();
      int lineSize = (this.width * this.bitDepth + 7) / 8 * this.colorComponents;
      byte[] curLine = new byte[lineSize + 1];
      byte[] prevLine = new byte[lineSize + 1];
      byte[] palLine = this.bitDepth < 8 ? new byte[this.width + 1] : null;
      Inflater inflater = new Inflater();

      try {
         for(int y = 0; y < this.height; ++y) {
            this.readChunkUnzip(inflater, curLine, 0, curLine.length);
            this.unfilter(curLine, prevLine);
            buffer.position(offset + y * stride);
            label109:
            switch (this.colorType) {
               case 0:
                  switch (format) {
                     case LUMINANCE:
                     case ALPHA:
                        this.copyToIntBuffer(buffer, curLine, format);
                        break label109;
                     default:
                        throw new UnsupportedOperationException("Unsupported format for this image");
                  }
               case 1:
               case 5:
               default:
                  throw new UnsupportedOperationException("Not yet implemented");
               case 2:
                  switch (format) {
                     case ABGR:
                     case RGBA:
                     case ARGB:
                     case BGRA:
                        this.copyRGBtoFormatInt(buffer, curLine, format);
                        break label109;
                     case RGB:
                        this.copyToIntBuffer(buffer, curLine, format);
                        break label109;
                     default:
                        throw new UnsupportedOperationException("Unsupported format for this image");
                  }
               case 3:
                  switch (this.bitDepth) {
                     case 1:
                        this.expand1(curLine, palLine);
                        break;
                     case 2:
                        this.expand2(curLine, palLine);
                        break;
                     case 3:
                     case 5:
                     case 6:
                     case 7:
                     default:
                        throw new UnsupportedOperationException("Unsupported bitdepth for this image");
                     case 4:
                        this.expand4(curLine, palLine);
                        break;
                     case 8:
                        palLine = curLine;
                  }

                  switch (format) {
                     case ABGR:
                     case RGBA:
                     case ARGB:
                     case BGRA:
                        this.copyPALtoFormatInt(buffer, palLine, format);
                        break label109;
                     default:
                        throw new UnsupportedOperationException("Unsupported format for this image");
                  }
               case 4:
                  if (format != PNGDecoder.Format.LUMINANCE_ALPHA) {
                     throw new UnsupportedOperationException("Unsupported format for this image");
                  }

                  this.copyToIntBuffer(buffer, curLine, format);
                  break;
               case 6:
                  switch (format) {
                     case ABGR:
                     case ARGB:
                     case BGRA:
                     case RGB:
                        this.copyRGBAtoFormatInt(buffer, curLine, format);
                        break;
                     case RGBA:
                        this.copyToIntBuffer(buffer, curLine, format);
                        break;
                     default:
                        throw new UnsupportedOperationException("Unsupported format for this image");
                  }
            }

            byte[] tmp = curLine;
            curLine = prevLine;
            prevLine = tmp;
         }
      } finally {
         inflater.end();
      }

   }

   private int packColor(byte r, byte g, byte b, byte a) {
      return (r & 255) << 24 | (g & 255) << 16 | (b & 255) << 8 | a & 255;
   }

   private void copyToIntBuffer(IntBuffer buffer, byte[] curLine, Format format) {
      switch (format) {
         case ABGR:
         case RGBA:
         case ARGB:
         case BGRA:
            int i = 1;

            for(int n = curLine.length; i < n; i += 4) {
               buffer.put(this.packColor(curLine[i], curLine[i + 1], curLine[i + 2], curLine[i + 3]));
            }
            break;
         case RGB:
            int i = 1;

            for(int n = curLine.length; i < n; i += 3) {
               buffer.put(this.packColor(curLine[i], curLine[i + 1], curLine[i + 2], (byte)-1));
            }
            break;
         case LUMINANCE:
            int i = 1;

            for(int n = curLine.length; i < n; ++i) {
               buffer.put(this.packColor(curLine[i], curLine[i], curLine[i], (byte)-1));
            }
            break;
         case ALPHA:
            int i = 1;

            for(int n = curLine.length; i < n; ++i) {
               buffer.put(this.packColor((byte)-1, (byte)-1, (byte)-1, curLine[i]));
            }
            break;
         case LUMINANCE_ALPHA:
            int i = 1;

            for(int n = curLine.length; i < n; i += 2) {
               buffer.put(this.packColor(curLine[i], curLine[i], curLine[i], curLine[i + 1]));
            }
      }

   }

   private void putColorToIntBuffer(IntBuffer buffer, Format format, byte r, byte g, byte b, byte a) {
      switch (format) {
         case ABGR:
            buffer.put(this.packColor(a, b, g, r));
            break;
         case RGBA:
            buffer.put(this.packColor(r, g, b, a));
            break;
         case ARGB:
            buffer.put(this.packColor(a, r, g, b));
            break;
         case BGRA:
            buffer.put(this.packColor(b, g, r, a));
      }

   }

   private void copyRGBtoFormatInt(IntBuffer buffer, byte[] curLine, Format format) {
      if (this.transPixel != null) {
         byte tr = this.transPixel[1];
         byte tg = this.transPixel[3];
         byte tb = this.transPixel[5];
         int i = 1;

         for(int n = curLine.length; i < n; i += 3) {
            byte r = curLine[i];
            byte g = curLine[i + 1];
            byte b = curLine[i + 2];
            byte a = -1;
            if (r == tr && g == tg && b == tb) {
               a = 0;
            }

            this.putColorToIntBuffer(buffer, format, r, g, b, a);
         }
      } else {
         int i = 1;

         for(int n = curLine.length; i < n; i += 3) {
            this.putColorToIntBuffer(buffer, format, curLine[i], curLine[i + 1], curLine[i + 2], (byte)-1);
         }
      }

   }

   private void copyRGBAtoFormatInt(IntBuffer buffer, byte[] curLine, Format format) {
      int i = 1;

      for(int n = curLine.length; i < n; i += 4) {
         if (format == PNGDecoder.Format.RGB) {
            buffer.put(this.packColor(curLine[i], curLine[i + 1], curLine[i + 2], (byte)-1));
         } else if (format != PNGDecoder.Format.RGBA) {
            this.putColorToIntBuffer(buffer, format, curLine[i], curLine[i + 1], curLine[i + 2], curLine[i + 3]);
         }
      }

   }

   private void copyPALtoFormatInt(IntBuffer buffer, byte[] curLine, Format format) {
      int i = 1;

      for(int n = curLine.length; i < n; ++i) {
         int idx = curLine[i] & 255;
         byte r = this.palette[idx * 3];
         byte g = this.palette[idx * 3 + 1];
         byte b = this.palette[idx * 3 + 2];
         byte a = this.paletteA != null ? this.paletteA[idx] : -1;
         this.putColorToIntBuffer(buffer, format, r, g, b, a);
      }

   }

   private void copyToByteBuffer(ByteBuffer buffer, byte[] curLine) {
      buffer.put(curLine, 1, curLine.length - 1);
   }

   private void putColorToByteBuffer(ByteBuffer buffer, Format format, byte r, byte g, byte b, byte a) {
      switch (format) {
         case ABGR:
            buffer.put(a).put(b).put(g).put(r);
            break;
         case RGBA:
            buffer.put(r).put(g).put(b).put(a);
            break;
         case ARGB:
            buffer.put(a).put(r).put(g).put(b);
            break;
         case BGRA:
            buffer.put(b).put(g).put(r).put(a);
      }

   }

   private void copyRGBtoFormatByte(ByteBuffer buffer, byte[] curLine, Format format) {
      if (this.transPixel != null) {
         byte tr = this.transPixel[1];
         byte tg = this.transPixel[3];
         byte tb = this.transPixel[5];
         int i = 1;

         for(int n = curLine.length; i < n; i += 3) {
            byte r = curLine[i];
            byte g = curLine[i + 1];
            byte b = curLine[i + 2];
            byte a = -1;
            if (r == tr && g == tg && b == tb) {
               a = 0;
            }

            this.putColorToByteBuffer(buffer, format, r, g, b, a);
         }
      } else {
         int i = 1;

         for(int n = curLine.length; i < n; i += 3) {
            this.putColorToByteBuffer(buffer, format, curLine[i], curLine[i + 1], curLine[i + 2], (byte)-1);
         }
      }

   }

   private void copyRGBAtoFormatByte(ByteBuffer buffer, byte[] curLine, Format format) {
      int i = 1;

      for(int n = curLine.length; i < n; i += 4) {
         if (format == PNGDecoder.Format.RGB) {
            buffer.put(curLine[i]).put(curLine[i + 1]).put(curLine[i + 2]);
         } else if (format != PNGDecoder.Format.RGBA) {
            this.putColorToByteBuffer(buffer, format, curLine[i], curLine[i + 1], curLine[i + 2], curLine[i + 3]);
         }
      }

   }

   private void copyPALtoFormatByte(ByteBuffer buffer, byte[] curLine, Format format) {
      int i = 1;

      for(int n = curLine.length; i < n; ++i) {
         int idx = curLine[i] & 255;
         byte r = this.palette[idx * 3];
         byte g = this.palette[idx * 3 + 1];
         byte b = this.palette[idx * 3 + 2];
         byte a = this.paletteA != null ? this.paletteA[idx] : -1;
         this.putColorToByteBuffer(buffer, format, r, g, b, a);
      }

   }

   private void expand4(byte[] src, byte[] dst) {
      int i = 1;

      for(int n = dst.length; i < n; i += 2) {
         int val = src[1 + (i >> 1)] & 255;
         if (n - i == 1) {
            dst[i] = (byte)(val >> 4);
         } else {
            dst[i + 1] = (byte)(val & 15);
         }
      }

   }

   private void expand2(byte[] src, byte[] dst) {
      int i = 1;

      for(int n = dst.length; i < n; i += 4) {
         int val = src[1 + (i >> 2)] & 255;
         switch (n - i) {
            default:
               dst[i + 3] = (byte)(val & 3);
            case 3:
               dst[i + 2] = (byte)(val >> 2 & 3);
            case 2:
               dst[i + 1] = (byte)(val >> 4 & 3);
            case 1:
               dst[i] = (byte)(val >> 6);
         }
      }

   }

   private void expand1(byte[] src, byte[] dst) {
      int i = 1;

      for(int n = dst.length; i < n; i += 8) {
         int val = src[1 + (i >> 3)] & 255;
         switch (n - i) {
            default:
               dst[i + 7] = (byte)(val & 1);
            case 7:
               dst[i + 6] = (byte)(val >> 1 & 1);
            case 6:
               dst[i + 5] = (byte)(val >> 2 & 1);
            case 5:
               dst[i + 4] = (byte)(val >> 3 & 1);
            case 4:
               dst[i + 3] = (byte)(val >> 4 & 1);
            case 3:
               dst[i + 2] = (byte)(val >> 5 & 1);
            case 2:
               dst[i + 1] = (byte)(val >> 6 & 1);
            case 1:
               dst[i] = (byte)(val >> 7);
         }
      }

   }

   private void unfilter(byte[] curLine, byte[] prevLine) throws IOException {
      switch (curLine[0]) {
         case 0:
            break;
         case 1:
            this.unfilterSub(curLine);
            break;
         case 2:
            this.unfilterUp(curLine, prevLine);
            break;
         case 3:
            this.unfilterAverage(curLine, prevLine);
            break;
         case 4:
            this.unfilterPaeth(curLine, prevLine);
            break;
         default:
            throw new IOException("invalide filter type in scanline: " + curLine[0]);
      }

   }

   private void unfilterSub(byte[] curLine) {
      int bpp = this.colorComponents;
      int i = bpp + 1;

      for(int n = curLine.length; i < n; ++i) {
         curLine[i] += curLine[i - bpp];
      }

   }

   private void unfilterUp(byte[] curLine, byte[] prevLine) {
      int bpp = this.colorComponents;
      int i = 1;

      for(int n = curLine.length; i < n; ++i) {
         curLine[i] += prevLine[i];
      }

   }

   private void unfilterAverage(byte[] curLine, byte[] prevLine) {
      int bpp = this.colorComponents;

      int i;
      for(i = 1; i <= bpp; ++i) {
         curLine[i] += (byte)((prevLine[i] & 255) >>> 1);
      }

      for(int n = curLine.length; i < n; ++i) {
         curLine[i] += (byte)((prevLine[i] & 255) + (curLine[i - bpp] & 255) >>> 1);
      }

   }

   private void unfilterPaeth(byte[] curLine, byte[] prevLine) {
      int bpp = this.colorComponents;

      int i;
      for(i = 1; i <= bpp; ++i) {
         curLine[i] += prevLine[i];
      }

      for(int n = curLine.length; i < n; ++i) {
         int a = curLine[i - bpp] & 255;
         int b = prevLine[i] & 255;
         int c = prevLine[i - bpp] & 255;
         int p = a + b - c;
         int pa = p - a;
         if (pa < 0) {
            pa = -pa;
         }

         int pb = p - b;
         if (pb < 0) {
            pb = -pb;
         }

         int pc = p - c;
         if (pc < 0) {
            pc = -pc;
         }

         if (pa <= pb && pa <= pc) {
            c = a;
         } else if (pb <= pc) {
            c = b;
         }

         curLine[i] += (byte)c;
      }

   }

   private void readIHDR() throws IOException {
      this.checkChunkLength(13);
      this.readChunk(this.buffer, 0, 13);
      this.width = this.readInt(this.buffer, 0);
      this.height = this.readInt(this.buffer, 4);
      this.bitDepth = this.buffer[8] & 255;
      this.colorType = this.buffer[9] & 255;
      label43:
      switch (this.colorType) {
         case 0:
            if (this.bitDepth != 8) {
               throw new IOException("Unsupported bit depth: " + this.bitDepth);
            }

            this.colorComponents = 1;
            break;
         case 1:
         case 5:
         default:
            throw new IOException("unsupported color format: " + this.colorType);
         case 2:
            if (this.bitDepth != 8) {
               throw new IOException("Unsupported bit depth: " + this.bitDepth);
            }

            this.colorComponents = 3;
            break;
         case 3:
            switch (this.bitDepth) {
               case 1:
               case 2:
               case 4:
               case 8:
                  this.colorComponents = 1;
                  break label43;
               case 3:
               case 5:
               case 6:
               case 7:
               default:
                  throw new IOException("Unsupported bit depth: " + this.bitDepth);
            }
         case 4:
            if (this.bitDepth != 8) {
               throw new IOException("Unsupported bit depth: " + this.bitDepth);
            }

            this.colorComponents = 2;
            break;
         case 6:
            if (this.bitDepth != 8) {
               throw new IOException("Unsupported bit depth: " + this.bitDepth);
            }

            this.colorComponents = 4;
      }

      if (this.buffer[10] != 0) {
         throw new IOException("unsupported compression method");
      } else if (this.buffer[11] != 0) {
         throw new IOException("unsupported filtering method");
      } else if (this.buffer[12] != 0) {
         throw new IOException("unsupported interlace method");
      }
   }

   private void readPLTE() throws IOException {
      int paletteEntries = this.chunkLength / 3;
      if (paletteEntries >= 1 && paletteEntries <= 256 && this.chunkLength % 3 == 0) {
         this.palette = new byte[paletteEntries * 3];
         this.readChunk(this.palette, 0, this.palette.length);
      } else {
         throw new IOException("PLTE chunk has wrong length");
      }
   }

   private void readtRNS() throws IOException {
      switch (this.colorType) {
         case 0:
            this.checkChunkLength(2);
            this.transPixel = new byte[2];
            this.readChunk(this.transPixel, 0, 2);
         case 1:
         default:
            break;
         case 2:
            this.checkChunkLength(6);
            this.transPixel = new byte[6];
            this.readChunk(this.transPixel, 0, 6);
            break;
         case 3:
            if (this.palette == null) {
               throw new IOException("tRNS chunk without PLTE chunk");
            }

            this.paletteA = new byte[this.palette.length / 3];
            Arrays.fill(this.paletteA, (byte)-1);
            this.readChunk(this.paletteA, 0, this.paletteA.length);
      }

   }

   private void closeChunk() throws IOException {
      if (this.chunkRemaining > 0) {
         this.skip((long)(this.chunkRemaining + 4));
      } else {
         this.readFully(this.buffer, 0, 4);
         int expectedCrc = this.readInt(this.buffer, 0);
         int computedCrc = (int)this.crc.getValue();
         if (computedCrc != expectedCrc) {
            throw new IOException("Invalid CRC");
         }
      }

      this.chunkRemaining = 0;
      this.chunkLength = 0;
      this.chunkType = 0;
   }

   private void openChunk() throws IOException {
      this.readFully(this.buffer, 0, 8);
      this.chunkLength = this.readInt(this.buffer, 0);
      this.chunkType = this.readInt(this.buffer, 4);
      this.chunkRemaining = this.chunkLength;
      this.crc.reset();
      this.crc.update(this.buffer, 4, 4);
   }

   private void openChunk(int expected) throws IOException {
      this.openChunk();
      if (this.chunkType != expected) {
         throw new IOException("Expected chunk: " + Integer.toHexString(expected));
      }
   }

   private void checkChunkLength(int expected) throws IOException {
      if (this.chunkLength != expected) {
         throw new IOException("Chunk has wrong size");
      }
   }

   private int readChunk(byte[] buffer, int offset, int length) throws IOException {
      if (length > this.chunkRemaining) {
         length = this.chunkRemaining;
      }

      this.readFully(buffer, offset, length);
      this.crc.update(buffer, offset, length);
      this.chunkRemaining -= length;
      return length;
   }

   private void refillInflater(Inflater inflater) throws IOException {
      while(this.chunkRemaining == 0) {
         this.closeChunk();
         this.openChunk(1229209940);
      }

      int read = this.readChunk(this.buffer, 0, this.buffer.length);
      inflater.setInput(this.buffer, 0, read);
   }

   private void readChunkUnzip(Inflater inflater, byte[] buffer, int offset, int length) throws IOException {
      assert buffer != this.buffer;

      try {
         do {
            int read = inflater.inflate(buffer, offset, length);
            if (read <= 0) {
               if (inflater.finished()) {
                  throw new EOFException();
               }

               if (!inflater.needsInput()) {
                  throw new IOException("Can't inflate " + length + " bytes");
               }

               this.refillInflater(inflater);
            } else {
               offset += read;
               length -= read;
            }
         } while(length > 0);

      } catch (DataFormatException ex) {
         throw new IOException("inflate error", ex);
      }
   }

   private void readFully(byte[] buffer, int offset, int length) throws IOException {
      do {
         int read = this.input.read(buffer, offset, length);
         if (read < 0) {
            throw new EOFException();
         }

         offset += read;
         length -= read;
      } while(length > 0);

   }

   private int readInt(byte[] buffer, int offset) {
      return buffer[offset] << 24 | (buffer[offset + 1] & 255) << 16 | (buffer[offset + 2] & 255) << 8 | buffer[offset + 3] & 255;
   }

   private void skip(long amount) throws IOException {
      while(amount > 0L) {
         long skipped = this.input.skip(amount);
         if (skipped < 0L) {
            throw new EOFException();
         }

         amount -= skipped;
      }

   }

   public int getWidth() {
      return this.width;
   }

   public int getHeight() {
      return this.height;
   }

   public int getColorType() {
      return this.colorType;
   }

   public int getColorComponents() {
      return this.colorComponents;
   }

   public static enum Format {
      ALPHA(1, true),
      LUMINANCE(1, false),
      LUMINANCE_ALPHA(2, true),
      RGB(3, false),
      RGBA(4, true),
      ARGB(4, true),
      BGRA(4, true),
      ABGR(4, true);

      private final int numComponents;
      private final boolean hasAlpha;

      private Format(int numComponents, boolean hasAlpha) {
         this.numComponents = numComponents;
         this.hasAlpha = hasAlpha;
      }

      public int getNumComponents() {
         return this.numComponents;
      }

      public boolean hasAlpha() {
         return this.hasAlpha;
      }
   }
}

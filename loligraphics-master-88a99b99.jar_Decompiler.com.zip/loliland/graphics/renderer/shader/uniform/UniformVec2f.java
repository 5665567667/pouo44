package loliland.graphics.renderer.shader.uniform;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import loliland.graphics.renderer.GLCompatible;
import loliland.graphics.renderer.shader.Shader;
import org.jetbrains.annotations.NotNull;
import org.joml.Vector2f;
import org.joml.Vector2fc;

@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\u0016\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u000eJ\u000e\u0010\u000b\u001a\u00020\f2\u0006\u0010\u0010\u001a\u00020\u0011R\u0011\u0010\u0007\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\u0012"},
   d2 = {"Lloliland/graphics/renderer/shader/uniform/UniformVec2f;", "Lloliland/graphics/renderer/shader/uniform/Uniform;", "shader", "Lloliland/graphics/renderer/shader/Shader;", "name", "", "(Lloliland/graphics/renderer/shader/Shader;Ljava/lang/String;)V", "currentValue", "Lorg/joml/Vector2fc;", "getCurrentValue", "()Lorg/joml/Vector2fc;", "set", "", "f1", "", "f2", "value", "Lorg/joml/Vector2f;", "loligraphics-1.7.10"}
)
public final class UniformVec2f extends Uniform {
   @NotNull
   private final Vector2fc currentValue;

   public UniformVec2f(@NotNull Shader shader, @NotNull String name) {
      Intrinsics.checkNotNullParameter(shader, "shader");
      Intrinsics.checkNotNullParameter(name, "name");
      super(shader, name);
      this.currentValue = (Vector2fc)(new Vector2f());
   }

   @NotNull
   public final Vector2fc getCurrentValue() {
      return this.currentValue;
   }

   public final void set(@NotNull Vector2f value) {
      Intrinsics.checkNotNullParameter(value, "value");
      this.set(value.x, value.y);
   }

   public final void set(float f1, float f2) {
      if (!this.currentValue.equals(f1, f2) || this.getFirstUpload()) {
         GLCompatible.uniform2f(this.getLocation(), f1, f2);
         Vector2fc var10000 = this.currentValue;
         Intrinsics.checkNotNull(var10000, "null cannot be cast to non-null type org.joml.Vector2f");
         ((Vector2f)var10000).set(f1, f2);
         this.setFirstUpload(false);
      }

   }
}

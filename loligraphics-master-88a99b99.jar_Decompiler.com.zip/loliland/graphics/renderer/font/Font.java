package loliland.graphics.renderer.font;

import java.io.BufferedInputStream;
import java.io.Closeable;
import java.io.DataInputStream;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.io.CloseableKt;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import loliland.graphics.renderer.texture.EmptyTexture;
import loliland.graphics.renderer.texture.Texture;
import loliland.graphics.renderer.texture.TextureManager;
import loliland.graphics.util.ResourceExtensionsKt;
import net.minecraft.util.ResourceLocation;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector2f;

@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\\\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\f\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\b&\u0018\u0000 02\u00020\u0001:\u000201B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\b\u0010\u001f\u001a\u00020 H\u0002J\b\u0010!\u001a\u00020\bH\u0016J\u0013\u0010\"\u001a\u00020\b2\b\u0010#\u001a\u0004\u0018\u00010\u0001H\u0096\u0002J\u000e\u0010$\u001a\u00020%2\u0006\u0010&\u001a\u00020'J\b\u0010(\u001a\u00020)H\u0016J\u0010\u0010*\u001a\u00020 2\u0006\u0010+\u001a\u00020,H\u0016J\b\u0010-\u001a\u00020\u0010H\u0014J\b\u0010.\u001a\u00020/H\u0016R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082.¢\u0006\u0002\n\u0000R\u001a\u0010\u0007\u001a\u00020\bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\t\u0010\n\"\u0004\b\u000b\u0010\fR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u001a\u0010\u000f\u001a\u00020\u0010X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014R\u0011\u0010\u0015\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u000eR\u001a\u0010\u0017\u001a\u00020\u0018X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0019\u0010\u001a\"\u0004\b\u001b\u0010\u001cR\u0011\u0010\u001d\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u000e¨\u00062"},
   d2 = {"Lloliland/graphics/renderer/font/Font;", "", "location", "Lnet/minecraft/util/ResourceLocation;", "(Lnet/minecraft/util/ResourceLocation;)V", "glyphTable", "Lloliland/graphics/renderer/font/Font$GlyphPagedTable;", "loaded", "", "getLoaded", "()Z", "setLoaded", "(Z)V", "getLocation", "()Lnet/minecraft/util/ResourceLocation;", "metadata", "Lloliland/graphics/renderer/font/FontMetadata;", "getMetadata", "()Lloliland/graphics/renderer/font/FontMetadata;", "setMetadata", "(Lloliland/graphics/renderer/font/FontMetadata;)V", "metadataLocation", "getMetadataLocation", "texture", "Lloliland/graphics/renderer/texture/Texture;", "getTexture", "()Lloliland/graphics/renderer/texture/Texture;", "setTexture", "(Lloliland/graphics/renderer/texture/Texture;)V", "textureLocation", "getTextureLocation", "buildGlyphTable", "", "dispose", "equals", "other", "getGlyph", "Lloliland/graphics/renderer/font/FontGlyph;", "char", "", "hashCode", "", "load", "textureManager", "Lloliland/graphics/renderer/texture/TextureManager;", "loadMetadata", "toString", "", "Companion", "GlyphPagedTable", "loligraphics-1.7.10"}
)
@SourceDebugExtension({"SMAP\nFont.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Font.kt\nloliland/graphics/renderer/font/Font\n+ 2 ResourceExtensions.kt\nloliland/graphics/util/ResourceExtensionsKt\n*L\n1#1,117:1\n30#2:118\n30#2:119\n*S KotlinDebug\n*F\n+ 1 Font.kt\nloliland/graphics/renderer/font/Font\n*L\n26#1:118\n27#1:119\n*E\n"})
public abstract class Font {
   @NotNull
   public static final Companion Companion = new Companion((DefaultConstructorMarker)null);
   @NotNull
   private final ResourceLocation location;
   @NotNull
   private Texture texture;
   public FontMetadata metadata;
   private boolean loaded;
   @NotNull
   private final ResourceLocation metadataLocation;
   @NotNull
   private final ResourceLocation textureLocation;
   private GlyphPagedTable glyphTable;
   public static final float ATLAS_SIZE = 96.0F;

   public Font(@NotNull ResourceLocation location) {
      Intrinsics.checkNotNullParameter(location, "location");
      super();
      this.location = location;
      this.texture = EmptyTexture.INSTANCE;
      ResourceLocation $this$addPath$iv = this.location;
      String path$iv = "/glyphs.dat";
      int $i$f$addPath = 0;
      this.metadataLocation = new ResourceLocation($this$addPath$iv.func_110624_b(), $this$addPath$iv.func_110623_a() + path$iv);
      $this$addPath$iv = this.location;
      path$iv = "/texture.png";
      $i$f$addPath = 0;
      this.textureLocation = new ResourceLocation($this$addPath$iv.func_110624_b(), $this$addPath$iv.func_110623_a() + path$iv);
   }

   @NotNull
   public final ResourceLocation getLocation() {
      return this.location;
   }

   @NotNull
   public final Texture getTexture() {
      return this.texture;
   }

   public final void setTexture(@NotNull Texture var1) {
      Intrinsics.checkNotNullParameter(var1, "<set-?>");
      this.texture = var1;
   }

   @NotNull
   public final FontMetadata getMetadata() {
      FontMetadata var10000 = this.metadata;
      if (var10000 != null) {
         return var10000;
      } else {
         Intrinsics.throwUninitializedPropertyAccessException("metadata");
         return null;
      }
   }

   public final void setMetadata(@NotNull FontMetadata var1) {
      Intrinsics.checkNotNullParameter(var1, "<set-?>");
      this.metadata = var1;
   }

   public final boolean getLoaded() {
      return this.loaded;
   }

   public final void setLoaded(boolean var1) {
      this.loaded = var1;
   }

   @NotNull
   public final ResourceLocation getMetadataLocation() {
      return this.metadataLocation;
   }

   @NotNull
   public final ResourceLocation getTextureLocation() {
      return this.textureLocation;
   }

   public void load(@NotNull TextureManager textureManager) {
      Intrinsics.checkNotNullParameter(textureManager, "textureManager");
      this.setMetadata(this.loadMetadata());
      this.buildGlyphTable();
      FontTexture it = new FontTexture(this.textureLocation, 0, 0.0F, 6, (DefaultConstructorMarker)null);
      int var4 = 0;
      this.texture = it;
      it.load();
      this.loaded = this.texture.getId() > 0;
   }

   @NotNull
   protected FontMetadata loadMetadata() {
      InputStream var1 = ResourceExtensionsKt.inputStream(this.metadataLocation);
      short var2 = 8192;
      Closeable var30 = (Closeable)(new DataInputStream((InputStream)(var1 instanceof BufferedInputStream ? (BufferedInputStream)var1 : new BufferedInputStream(var1, var2))));
      Throwable var31 = null;

      FontMetadata var32;
      try {
         DataInputStream reader = (DataInputStream)var30;
         int var4 = 0;
         Vector2f var10000 = new Vector2f(reader.readFloat(), reader.readFloat());
         int var10001 = reader.readInt();
         int var10002 = reader.readInt();
         boolean var10003 = reader.readBoolean();
         boolean var10004 = reader.readBoolean();
         Map var5 = (Map)(new LinkedHashMap());
         Map $this$loadMetadata_u24lambda_u243_u24lambda_u242 = var5;
         boolean var7 = var10004;
         boolean var8 = var10003;
         int var9 = var10002;
         int var10 = var10001;
         Vector2f var11 = var10000;
         int var12 = 0;
         int var13 = reader.readInt();

         for(int var14 = 0; var14 < var13; ++var14) {
            int var16 = 0;
            int code = reader.readInt();
            Integer var18 = code;
            $this$loadMetadata_u24lambda_u243_u24lambda_u242.put(var18, new FontGlyph(code, new Vector2f(reader.readFloat(), reader.readFloat()), new Vector2f(reader.readFloat(), reader.readFloat()), new Vector2f(reader.readFloat(), reader.readFloat()), reader.readInt()));
         }

         Unit var19 = Unit.INSTANCE;
         var32 = new FontMetadata(var11, var10, var9, var8, var7, var5);
      } catch (Throwable var28) {
         var31 = var28;
         throw var28;
      } finally {
         CloseableKt.closeFinally(var30, var31);
      }

      return var32;
   }

   @NotNull
   public final FontGlyph getGlyph(char var1) {
      GlyphPagedTable var10000 = this.glyphTable;
      if (var10000 == null) {
         Intrinsics.throwUninitializedPropertyAccessException("glyphTable");
         var10000 = null;
      }

      return var10000.get(var1);
   }

   private final void buildGlyphTable() {
      Map glyphs = this.getMetadata().getGlyphs();
      FontGlyph var10000 = (FontGlyph)glyphs.get(0);
      if (var10000 == null) {
         throw new IllegalStateException("Font must contain fallback glyph at code 0".toString());
      } else {
         FontGlyph fallback = var10000;
         this.glyphTable = new GlyphPagedTable(fallback);

         for(Map.Entry var4 : glyphs.entrySet()) {
            int code = ((Number)var4.getKey()).intValue();
            FontGlyph glyph = (FontGlyph)var4.getValue();
            GlyphPagedTable var7 = this.glyphTable;
            if (var7 == null) {
               Intrinsics.throwUninitializedPropertyAccessException("glyphTable");
               var7 = null;
            }

            var7.put(code, glyph);
         }

      }
   }

   public boolean dispose() {
      this.loaded = false;
      boolean disposed = this.texture.dispose();
      this.texture = EmptyTexture.INSTANCE;
      return disposed;
   }

   public boolean equals(@Nullable Object other) {
      return other instanceof Font && Intrinsics.areEqual(this.location, ((Font)other).location);
   }

   public int hashCode() {
      return this.location.hashCode();
   }

   @NotNull
   public String toString() {
      String var10000 = this.location.toString();
      Intrinsics.checkNotNullExpressionValue(var10000, "toString(...)");
      return var10000;
   }

   @JvmStatic
   public static final float fontSize(float pixels) {
      return Companion.fontSize(pixels);
   }

   @Metadata(
      mv = {1, 9, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u0004H\u0007R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0007"},
      d2 = {"Lloliland/graphics/renderer/font/Font$Companion;", "", "()V", "ATLAS_SIZE", "", "fontSize", "pixels", "loligraphics-1.7.10"}
   )
   public static final class Companion {
      private Companion() {
      }

      @JvmStatic
      public final float fontSize(float pixels) {
         return pixels / 96.0F;
      }

      // $FF: synthetic method
      public Companion(DefaultConstructorMarker $constructor_marker) {
         this();
      }
   }

   @Metadata(
      mv = {1, 9, 0},
      k = 1,
      xi = 48,
      d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0011\n\u0002\b\u0005\n\u0002\u0010\f\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0002\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u000e\u0010\f\u001a\u00020\u00032\u0006\u0010\r\u001a\u00020\u000eJ\u0016\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0003R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R#\u0010\u0007\u001a\u0012\u0012\u000e\u0012\f\u0012\u0006\u0012\u0004\u0018\u00010\u0003\u0018\u00010\b0\b¢\u0006\n\n\u0002\u0010\u000b\u001a\u0004\b\t\u0010\n¨\u0006\u0014"},
      d2 = {"Lloliland/graphics/renderer/font/Font$GlyphPagedTable;", "", "fallbackGlyph", "Lloliland/graphics/renderer/font/FontGlyph;", "(Lloliland/graphics/renderer/font/FontGlyph;)V", "getFallbackGlyph", "()Lloliland/graphics/renderer/font/FontGlyph;", "pages", "", "getPages", "()[[Lloliland/graphics/renderer/font/FontGlyph;", "[[Lloliland/graphics/renderer/font/FontGlyph;", "get", "char", "", "put", "", "codePoint", "", "glyph", "loligraphics-1.7.10"}
   )
   private static final class GlyphPagedTable {
      @NotNull
      private final FontGlyph fallbackGlyph;
      @NotNull
      private final FontGlyph[][] pages;

      public GlyphPagedTable(@NotNull FontGlyph fallbackGlyph) {
         Intrinsics.checkNotNullParameter(fallbackGlyph, "fallbackGlyph");
         super();
         this.fallbackGlyph = fallbackGlyph;
         this.pages = new FontGlyph[256][];
      }

      @NotNull
      public final FontGlyph getFallbackGlyph() {
         return this.fallbackGlyph;
      }

      @NotNull
      public final FontGlyph[][] getPages() {
         return this.pages;
      }

      public final void put(int codePoint, @NotNull FontGlyph glyph) {
         Intrinsics.checkNotNullParameter(glyph, "glyph");
         if (0 <= codePoint ? codePoint < 65536 : false) {
            int pageIndex = codePoint >>> 8;
            int inPage = codePoint & 255;
            FontGlyph[] page = this.pages[pageIndex];
            if (page == null) {
               page = new FontGlyph[256];
               this.pages[pageIndex] = page;
            }

            page[inPage] = glyph;
         }
      }

      @NotNull
      public final FontGlyph get(char var1) {
         FontGlyph var10000 = this.pages[var1 >>> 8];
         if (var10000 == null) {
            return this.fallbackGlyph;
         } else {
            FontGlyph[] page = var10000;
            var10000 = page[var1 & 255];
            if (page[var1 & 255] == null) {
               var10000 = this.fallbackGlyph;
            }

            return var10000;
         }
      }
   }
}

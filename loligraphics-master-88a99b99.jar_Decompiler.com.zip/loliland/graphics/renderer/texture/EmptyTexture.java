package loliland.graphics.renderer.texture;

import kotlin.Metadata;
import loliland.graphics.util.ResourceExtensionsKt;
import org.jetbrains.annotations.NotNull;

@Metadata(
   mv = {1, 9, 0},
   k = 1,
   xi = 48,
   d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0016¨\u0006\u0005"},
   d2 = {"Lloliland/graphics/renderer/texture/EmptyTexture;", "Lloliland/graphics/renderer/texture/Texture;", "()V", "load", "", "loligraphics-1.7.10"}
)
public final class EmptyTexture extends Texture {
   @NotNull
   public static final EmptyTexture INSTANCE = new EmptyTexture();

   private EmptyTexture() {
      super(ResourceExtensionsKt.getNULL_LOCATION());
   }

   public void load() {
      this.setId(0);
      this.setWidth(0);
      this.setHeight(0);
   }
}
